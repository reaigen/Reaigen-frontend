# Reaigen Floorplan Solver

Deterministic, fail-closed floorplan cleanup and furniture-layout solving for Apple RoomPlan / `CapturedStructure`, with a Next.js client worker, server API usage, dataset-mining utilities, and a copy-ready adapter for the existing Reaigen `floorplan-geometry.ts` model.

The package is designed to replace heuristic “snap, hug, then nudge” placement. It treats the scan as noisy observations and selects one legal candidate pose per object under hard architectural constraints.

## What it prevents

In strict mode, accepted output is validated against all of the following:

- object footprints remain inside an assigned room polygon;
- furniture does not intersect architectural walls;
- door thresholds, approaches, and configured swing sectors remain clear;
- unknown door hinge/swing is handled conservatively rather than guessed;
- tall furniture does not cover windows;
- storage units and other solid objects do not overlap;
- cabinetry and appliances retain usable front service clearance;
- parent/containment relations such as chair–table and sink–storage are handled explicitly;
- low-confidence or impossible observations are rejected instead of being moved outside the apartment;
- navigation connectivity is analyzed and repaired where an alternative candidate exists;
- the same input and options produce the same placement output.

A rejected uncertain box is intentional. It is preferable to rendering storage across a doorway or below the apartment.

## Architecture

```text
CapturedRoom / CapturedStructure JSON
                  │
                  ▼
       canonical scene extraction
       rooms · walls · openings · objects
                  │
                  ▼
      room polygon construction/assignment
                  │
                  ▼
      door/window keep-out construction
                  │
                  ▼
   observation conditioning and deduplication
                  │
                  ▼
       discrete candidate generation
 raw · rectified · wall · storage-run · relation · reject
                  │
                  ▼
 deterministic bounded-width constraint search
                  │
                  ▼
     navigation repair + final validation
                  │
                  ▼
 solved objects with status, reasons, diagnostics
```

The runtime has no mandatory third-party dependency. Geometry, oriented-box intersection, room-face extraction, keep-outs, candidate search, and validation are implemented in TypeScript.

## Package layout

```text
src/
  geometry/       polygon, OBB/SAT, wall-face extraction
  input/          RoomPlan JSON parser and legacy adapter
  priors/         bootstrap priors + override merging
  solver/         candidates, constraints, relations, beam search, validation
  worker/         browser worker protocol/client
  next/           React/Next.js client hook
scripts/
  mine_procthor.py
  mine_arkitscenes.py
  merge_priors.py
  extract_roomplan_usdz.py
  render_solution_svg.mjs
examples/
  ios/            JSON + USDZ + metadata export helper
  next/           client hook and route-handler examples
integration/      copy-ready Reaigen adapter
patches/          Viewer and Editor migration notes
fixtures/         regression/demo scenes
```

The exact verification performed for this delivery is recorded in `BUILD_REPORT.md`.

## Install in the Reaigen workspace

From a sibling directory:

```bash
npm install ../reaigen-floorplan-solver
```

Or use a local workspace dependency:

```json
{
  "dependencies": {
    "@reaigen/floorplan-solver": "file:../reaigen-floorplan-solver"
  }
}
```

Build the package itself with Node.js 20 or newer:

```bash
npm install
npm run check
```

## Preferred Apple input contract

Upload the complete export bundle:

```text
captured_structure.json
captured_structure.usdz
captured_structure_metadata.json
```

Use Codable `CapturedRoom` or `CapturedStructure` JSON as the authoritative solver input. JSON preserves dimensions, transforms, floor polygons, sections, object attributes, parent identifiers, and semantic IDs. USDZ is valuable for visual verification and detailed geometry, but depending on export mode it may not retain every semantic field required by the solver.

A Swift helper is included at:

```text
examples/ios/RoomPlanExportBundle.swift
```

## Solve Codable RoomPlan JSON

```ts
import { solveRoomPlanJSON } from "@reaigen/floorplan-solver";

const result = solveRoomPlanJSON(capturedStructureJSON, {
  strict: true,
  runNavigationRepair: true,
  roomPlan: {
    doorConfigurations,
  },
});

const renderableObjects = result.objects.filter(
  (object) => object.status !== "rejected" && object.status !== "merged",
);
```

The parser accepts either a single `CapturedRoom` or a multi-room `CapturedStructure`. When floor polygons are unavailable, the solver can polygonize a closed wall graph. A convex-hull fallback exists only as a final legacy recovery path and is reported in diagnostics.

## Solve the existing Reaigen geometry model

The package exports a direct legacy adapter:

```ts
import { solveLegacyFloorplan } from "@reaigen/floorplan-solver";

const result = solveLegacyFloorplan({
  walls: wallSegs,
  doors,
  windows,
  objects: roomPlanObjects,
  doorConfigs,
  // Optional. With no roomPolygons, closed wall loops are polygonized.
  roomPolygons,
});
```

A copy-ready wrapper that returns the exact `ObjectXZ`-style render list is in:

```text
integration/reaigen-floorplan-adapter.ts
```

Migration instructions for the uploaded components are in:

```text
patches/FloorplanViewer.integration.patch.md
patches/FloorplanEditor.integration.patch.md
MIGRATION.md
```

### Critical editor rule

Always solve from the current edited state:

```ts
walls: graphSegs(graph),
doors,
windows,
doorConfigs,
```

Do not solve from `base.initialGraph` or the original scan openings after the user edits the plan.

## Next.js client worker

```tsx
"use client";

import { useFloorplanSolver } from "@reaigen/floorplan-solver/next";

export function SolvedPlan({ input }: { input: SolverInput }) {
  const { result, loading, error } = useFloorplanSolver(input, {
    strict: true,
    runNavigationRepair: true,
  });

  if (loading) return <p>Solving…</p>;
  if (error) return <p role="alert">{error.message}</p>;
  if (!result) return null;

  return <Floorplan objects={result.objects.filter(isRenderable)} />;
}
```

The hook uses deterministic content fingerprints. Freshly-created JSON objects do not restart the worker merely because their JavaScript identity changed. Memoizing very large inputs is still useful to avoid repeated serialization.

A server route-handler example is included under `examples/next/app/api/floorplan/solve/route.ts`.

## CLI

Canonical `SolverInput`:

```bash
npx reaigen-floorplan-solve input.json output.json
```

Codable RoomPlan JSON:

```bash
npx reaigen-floorplan-solve captured_structure.json output.json --roomplan
```

Non-strict diagnostic mode:

```bash
npx reaigen-floorplan-solve input.json output.json --non-strict
```

Strict mode is the production default.

## Output contract

Every original observation is represented in the output:

```ts
interface SolvedFurniture {
  status: "unchanged" | "rectified" | "relocated" | "merged" | "rejected";
  roomId: string | null;
  sourcePose: FurniturePose;
  candidateSource:
    | "raw"
    | "yaw-rectified"
    | "wall"
    | "storage-wall-run"
    | "table-seat"
    | "satellite-table"
    | "tv-sofa"
    | "reject"
    | null;
  displacement: number;
  yawDeltaDeg: number;
  reasons: string[];
}
```

Examples of explanations:

```text
Packed into a legal wall interval that excludes doors and windows.
Duplicate/fragment footprint contained by storage-door-a.
Placed chair in a legal table-facing seat slot around dining-table.
Rejected because no room could be assigned.
Rejected by the final hard-constraint validator because no legal alternative remained.
```

The complete result also contains:

- room polygons and their source;
- opening keep-out polygons;
- validation issues and navigation metrics;
- candidate and search counts;
- repair count and runtime;
- warnings when geometry required a fallback.

## Placement model

### Hard constraints

Hard failures never become soft penalties:

```text
room containment
wall collision
opening threshold collision
door approach collision
door swing / sliding travel collision
window obstruction by tall objects
illegal object overlap
cabinet/appliance operational-front obstruction
```

### Candidate generation

The solver does not move boxes by arbitrary world-axis pushes. It constructs meaningful alternatives:

- preserve measured pose;
- rectify a small category-specific yaw residual;
- align to a legal room wall;
- pack storage into a free one-dimensional wall interval;
- seat a chair at a table edge;
- compose a coffee/side table around a sofa or bed;
- orient a television toward a selected sofa;
- reject an observation.

### Storage wall runs

Storage candidates are generated in wall coordinates. Door and window intervals, side reserves, and wall-end clearances are subtracted before any candidate center is created. Storage-storage conflict is then checked as oriented geometry during global candidate selection.

### Door reserves

A swinging door can contribute:

- threshold rectangle;
- approach rectangle on every adjacent room side;
- quarter-sector swept area;
- conservative left- and right-hinge sectors if configuration is unknown.

A moving/sliding door contributes its opening threshold, approach areas, and leaf/track travel reserve.

### Navigation

The selected scene is rasterized per room using a configurable grid. The solver measures the largest connected free-space component and whether each door approach is connected to it. A bounded repair phase tries legal alternatives for lower-priority objects before strict validation rejects an implicated observation.

## Priors and dataset mining

The codebase separates solver mechanics from coefficients. `DEFAULT_KIND_PRIORS` are conservative bootstrap values intended to run immediately; they are not represented as the result of a complete local download and re-analysis of every third-party scene.

The package includes reproducible mining scripts:

```bash
python scripts/mine_procthor.py \
  /datasets/procthor-10k/train.jsonl.gz \
  data/generated/procthor.json

python scripts/mine_arkitscenes.py \
  /datasets/ARKitScenes \
  data/generated/arkitscenes.json

python scripts/merge_priors.py \
  data/generated/procthor.json \
  data/generated/arkitscenes.json \
  data/generated/runtime-priors.json
```

ProcTHOR contributes synthetic semantic-layout statistics such as room occupancy, wall affinity, and selected relation distances. ARKitScenes contributes real-world oriented-box size and yaw distributions plus overlap diagnostics. Your consented RoomPlan scans and user corrections should become the decisive paired dataset for learning RoomPlan-specific correction probabilities.

No ProcTHOR or ARKitScenes data is bundled. Review each upstream license before downloading, redistributing, or using derived data commercially. See `RESEARCH.md` and `THIRD_PARTY_DATASETS.md`.

## Custom priors

Pass an override without rebuilding the engine:

```ts
const result = solveFloorplan(input, {
  priors: {
    kinds: {
      storage: {
        yawSnapDeg: 9,
        maxMove: 1.0,
        frontClearance: 0.7,
      },
    },
    beamWidth: 96,
  },
});
```

The merge is field-wise; unspecified values remain at package defaults.

## USDZ-only fallback

When JSON is unavailable:

```bash
python scripts/extract_roomplan_usdz.py \
  captured_structure.usdz \
  extracted_solver_input.json \
  --pretty
```

This requires Pixar USD Python bindings, commonly provided by a compatible `usd-core` wheel. The script groups RoomPlan-like prim names, projects meshes to XZ, and estimates oriented boxes. Its output has reduced confidence and is explicitly marked approximate. Prefer changing the iOS upload contract to include Codable JSON.

## Debug visualization

Generate an SVG showing raw dashed observations, solved boxes, walls, and keep-out regions:

```bash
node scripts/render_solution_svg.mjs \
  examples/output/apartment-chaos.solved.json \
  examples/output/apartment-chaos.svg
```

The existing Viewer `?fpdebug=1` overlay can remain enabled: red dashed boxes show the source observations, while the normal icons show solved output.

## Validation and tests

```bash
npm run check
```

The regression suite covers:

- wall-face room polygonization;
- door-storage conflict repair;
- unknown-door conservative swing handling;
- storage overlap prevention;
- duplicate-fragment merge;
- chair–table relation correction;
- concave room containment;
- outside-object fail-closed behavior;
- operational cabinet-front conflicts;
- CapturedRoom/CapturedStructure parsing and section mapping;
- deterministic output.

Use real production captures as fixtures. Every previously broken scene should be saved with anonymized geometry and added to `test/fixtures` or `fixtures`.

## Production acceptance criteria

A solve is acceptable only when:

```text
validation.valid === true
0 wall intersections
0 opening/door keep-out intersections
0 illegal object overlaps
0 storage overlaps
0 accepted objects outside assigned rooms
all moved/rejected/merged observations have reasons
identical input produces identical non-timing output
```

When the underlying room polygon itself is malformed, surface the validation error in the editor and require wall repair instead of inventing a layout.

## Limits of version 0.1.0

- It is a deterministic geometric/semantic solver, not a learned end-to-end scene generator.
- It does not infer missing furniture that RoomPlan never observed.
- Multi-floor vertical connectivity is not solved as one navigation graph.
- USDZ-only semantic recovery is approximate.
- Full-data coefficients must be generated in your own licensed dataset environment.
- Very large structures should solve in a Worker or server route rather than the browser UI thread.

These limits preserve the central contract: clean up observed geometry without hallucinating an unrelated apartment.
