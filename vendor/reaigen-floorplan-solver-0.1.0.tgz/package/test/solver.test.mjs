import test from "node:test";
import assert from "node:assert/strict";
import { readFileSync } from "node:fs";
import {
  extractWallFaces,
  obbIntersectionArea,
  parseRoomPlanJSON,
  solveFloorplan,
} from "../dist/index.js";

function rectangleScene(width = 5, depth = 4) {
  const room = {
    id: "room-1",
    polygon: [[0, 0], [width, 0], [width, depth], [0, depth]],
    type: "unknown",
    source: "manual",
  };
  const walls = [
    { id: "wall-bottom", p1: [0, 0], p2: [width, 0] },
    { id: "wall-right", p1: [width, 0], p2: [width, depth] },
    { id: "wall-top", p1: [width, depth], p2: [0, depth] },
    { id: "wall-left", p1: [0, depth], p2: [0, 0] },
  ];
  return { room, walls };
}

test("extracts a bounded room face from a wall graph", () => {
  const { walls } = rectangleScene();
  const result = extractWallFaces(walls, { minArea: 1 });
  assert.equal(result.faces.length, 1);
  assert.equal(result.faces[0].length, 4);
});

test("moves storage away from a door swing and keeps the plan valid", () => {
  const { room, walls } = rectangleScene();
  const input = {
    rooms: [room],
    walls,
    openings: [{
      id: "door-1",
      kind: "door",
      p1: [5, 1.2],
      p2: [5, 2.1],
      configuration: { doorType: "Swinging", hingeSide: "Left", swingDirection: "In", primaryRoomId: "room-1" },
    }],
    objects: [{
      id: "storage-1",
      category: "storage",
      kind: "storage",
      center: [4.68, 1.65],
      axisW: [0, 1],
      axisD: [-1, 0],
      halfW: 0.8,
      halfD: 0.3,
      height: 2,
      confidence: 0.9,
    }],
    source: "canonical",
  };
  const result = solveFloorplan(input);
  const storage = result.objects.find((object) => object.id === "storage-1");
  assert.ok(storage);
  assert.notEqual(storage.status, "unchanged");
  assert.equal(result.validation.valid, true);
  assert.equal(result.validation.issues.some((issue) => issue.code === "OPENING_BLOCKED"), false);
});

test("accepted storages never overlap", () => {
  const { room, walls } = rectangleScene(7, 5);
  const input = {
    rooms: [{ ...room, type: "bedroom" }],
    walls,
    openings: [{ id: "door-1", kind: "door", p1: [7, 1.4], p2: [7, 2.3] }],
    objects: [
      { id: "s1", category: "storage", kind: "storage", center: [3, 0.35], axisW: [1, 0], axisD: [0, 1], halfW: 1, halfD: 0.3, height: 2 },
      { id: "s2", category: "storage", kind: "storage", center: [3.7, 0.35], axisW: [1, 0], axisD: [0, 1], halfW: 0.9, halfD: 0.3, height: 2 },
      { id: "s3", category: "storage", kind: "storage", center: [6.7, 1.8], axisW: [0, 1], axisD: [-1, 0], halfW: 0.7, halfD: 0.28, height: 2 },
    ],
    source: "canonical",
  };
  const result = solveFloorplan(input);
  const accepted = result.objects.filter((object) => object.kind === "storage" && !["rejected", "merged"].includes(object.status));
  for (let i = 0; i < accepted.length; i++) {
    for (let j = i + 1; j < accepted.length; j++) {
      assert.ok(obbIntersectionArea(accepted[i], accepted[j]) <= 0.0004);
    }
  }
  assert.equal(result.validation.issues.some((issue) => issue.code === "STORAGE_OVERLAP"), false);
});

test("tall storage fails closed instead of teleporting to a distant wall", () => {
  const { room, walls } = rectangleScene(5, 4);
  const input = {
    rooms: [room],
    walls,
    objects: [{
      id: "wardrobe",
      category: "storage",
      kind: "storage",
      center: [2.5, 2],
      axisW: [1, 0],
      axisD: [0, 1],
      halfW: 0.8,
      halfD: 0.3,
      height: 2.2,
      confidence: 0.9,
    }],
    source: "canonical",
  };
  const result = solveFloorplan(input);
  const wardrobe = result.objects.find((object) => object.id === "wardrobe");
  assert.equal(wardrobe?.status, "rejected");
  assert.match(wardrobe?.reasons.join(" ") ?? "", /relocation limit/i);
  assert.equal(result.validation.valid, true);
});

test("a chair detected inside its parent table is moved into a table-facing slot", () => {
  const { room, walls } = rectangleScene(5, 5);
  const result = solveFloorplan({
    rooms: [{ ...room, type: "diningRoom" }],
    walls,
    objects: [
      { id: "table-1", category: "table", kind: "table", center: [2.5, 2.5], axisW: [1, 0], axisD: [0, 1], halfW: 0.75, halfD: 0.45, height: 0.75 },
      { id: "chair-1", category: "chair", kind: "chair", center: [2.5, 2.5], axisW: [1, 0], axisD: [0, 1], halfW: 0.25, halfD: 0.25, height: 0.9, parentId: "table-1" },
    ],
    source: "canonical",
  });
  const chair = result.objects.find((object) => object.id === "chair-1");
  assert.ok(chair);
  assert.equal(chair.candidateSource, "table-seat");
  assert.ok(Math.hypot(chair.center[0] - 2.5, chair.center[1] - 2.5) > 0.45);
  assert.equal(result.validation.valid, true);
});

test("RoomPlan Codable JSON parser keeps categories, floor polygon and parent relation", () => {
  const identity = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
  const translated = (x, y, z) => {
    const m = [...identity]; m[12] = x; m[13] = y; m[14] = z; return m;
  };
  const parsed = parseRoomPlanJSON({
    identifier: "room-a",
    floors: [{ identifier: "floor-a", dimensions: [4, 0.1, 3], transform: translated(2, 0, 1.5) }],
    walls: [], doors: [], windows: [],
    objects: [
      { identifier: "table-a", category: { table: {} }, dimensions: [1.2, 0.75, 0.7], transform: translated(2, 0.4, 1.5) },
      { identifier: "chair-a", category: { chair: {} }, dimensions: [0.5, 0.9, 0.5], transform: translated(2, 0.45, 2.1), parentIdentifier: "table-a" },
    ],
  });
  assert.equal(parsed.rooms?.length, 1);
  assert.equal(parsed.objects.length, 2);
  assert.equal(parsed.objects.find((object) => object.id === "chair-a")?.parentId, "table-a");
});

test("solver output is deterministic", () => {
  const { room, walls } = rectangleScene(6, 4);
  const input = {
    rooms: [room], walls,
    openings: [{ id: "door", kind: "door", p1: [6, 1], p2: [6, 1.9] }],
    objects: [
      { id: "bed", category: "bed", kind: "bed", center: [3, 2], axisW: [0.99, 0.05], axisD: [-0.05, 0.99], halfW: 0.8, halfD: 1, height: 0.6 },
      { id: "storage", category: "storage", kind: "storage", center: [5.7, 1.4], axisW: [0, 1], axisD: [-1, 0], halfW: 0.7, halfD: 0.3, height: 2 },
    ], source: "canonical",
  };
  const a = solveFloorplan(input);
  const b = solveFloorplan(input);
  const stripTiming = (value) => ({ ...value, diagnostics: { ...value.diagnostics, elapsedMs: 0 } });
  assert.deepEqual(stripTiming(a), stripTiming(b));
});

test("wall-only input polygonizes a room instead of using a wall connected component as a room", () => {
  const { walls } = rectangleScene(4, 3);
  const result = solveFloorplan({
    walls,
    objects: [{
      id: "bed-1", category: "bed", kind: "bed",
      center: [2, 1.5], axisW: [1, 0], axisD: [0, 1], halfW: 0.75, halfD: 1, height: 0.55,
    }],
    source: "canonical",
  });
  assert.equal(result.rooms.length, 1);
  assert.equal(result.diagnostics.roomSource, "wall-faces");
  assert.equal(result.validation.valid, true);
});

test("measured door gaps are sealed only for room polygonization", () => {
  const result = solveFloorplan({
    walls: [
      { id: "bottom-left", p1: [0, 0], p2: [2, 0] },
      { id: "bottom-right", p1: [3, 0], p2: [5, 0] },
      { id: "right", p1: [5, 0], p2: [5, 4] },
      { id: "top", p1: [5, 4], p2: [0, 4] },
      { id: "left", p1: [0, 4], p2: [0, 0] },
    ],
    openings: [{ id: "door", kind: "door", p1: [2, 0], p2: [3, 0] }],
    objects: [],
    source: "canonical",
  });
  assert.equal(result.diagnostics.roomSource, "wall-faces");
  assert.equal(result.rooms.length, 1);
  assert.equal(result.keepOuts.some((zone) => zone.openingId === "door"), true);
});

test("disconnected wall fragments use a containment-only hull and reject unsupported cabinetry", () => {
  const result = solveFloorplan({
    walls: [
      { id: "a", p1: [0, 0], p2: [3, 0] },
      { id: "b", p1: [3, 0], p2: [3, 2] },
      { id: "c", p1: [7, 5], p2: [9, 5] },
    ],
    objects: [{
      id: "cabinet", category: "storage", kind: "storage",
      center: [1, 1], axisW: [1, 0], axisD: [0, 1], halfW: 0.5, halfD: 0.3, height: 2,
    }],
    source: "canonical",
  });
  assert.equal(result.diagnostics.roomSource, "fallback-hull");
  assert.equal(result.rooms.length, 1);
  assert.equal(result.objects[0].status, "rejected");
  assert.match(result.objects[0].reasons.join(" "), /partial room topology/i);
});

test("partial topology preserves semantic anchors without inferred-wall relocation", () => {
  const result = solveFloorplan({
    walls: [
      { id: "bottom", p1: [0, 0], p2: [5, 0] },
      { id: "right", p1: [5, 0], p2: [5, 4] },
      { id: "top", p1: [5, 4], p2: [1, 4] },
    ],
    objects: [
      { id: "sofa", category: "sofa", kind: "sofa", center: [3.5, 1], axisW: [1, 0], axisD: [0, 1], halfW: 1, halfD: 0.45, height: 0.8 },
      { id: "table", category: "table", kind: "table", center: [2.5, 2.2], axisW: [1, 0], axisD: [0, 1], halfW: 0.6, halfD: 0.4, height: 0.75 },
      { id: "chair", category: "chair", kind: "chair", center: [2.5, 2.8], axisW: [1, 0], axisD: [0, 1], halfW: 0.25, halfD: 0.25, height: 0.9, parentId: "table" },
    ],
    source: "canonical",
  });
  assert.equal(result.diagnostics.roomSource, "fallback-hull");
  const sofa = result.objects.find((object) => object.id === "sofa");
  assert.notEqual(sofa?.status, "rejected");
  assert.ok((sofa?.displacement ?? Infinity) < 0.02);
  assert.ok(sofa?.candidateSource === "raw" || sofa?.candidateSource === "yaw-rectified");
  assert.equal(
    result.objects.some((object) => object.candidateSource === "wall" || object.candidateSource === "storage-wall-run"),
    false,
  );
});

test("partial topology minimally clears a semantic anchor from a measured wall band", () => {
  const result = solveFloorplan({
    walls: [
      { id: "bottom", p1: [0, 0], p2: [5, 0] },
      { id: "right", p1: [5, 0], p2: [5, 4] },
      { id: "top", p1: [5, 4], p2: [1, 4] },
    ],
    objects: [{
      id: "sofa", category: "sofa", kind: "sofa",
      center: [3, 3.54], axisW: [1, 0], axisD: [0, 1], halfW: 1, halfD: 0.45, height: 0.8,
    }],
    source: "canonical",
  });
  const sofa = result.objects.find((object) => object.id === "sofa");
  assert.equal(result.diagnostics.roomSource, "fallback-hull");
  assert.equal(result.validation.valid, true);
  assert.equal(sofa?.candidateSource, "measured-wall-clearance");
  assert.equal(sofa?.status, "relocated");
  assert.ok((sofa?.displacement ?? 0) > 0.04 && (sofa?.displacement ?? Infinity) <= 0.12);
  assert.ok(Math.abs((sofa?.yawDeltaDeg ?? Infinity)) < 0.01);
});

test("partial topology rectifies an explicit dining group to measured room axes", () => {
  const angle = (19 * Math.PI) / 180;
  const axisW = [Math.cos(angle), Math.sin(angle)];
  const axisD = [-Math.sin(angle), Math.cos(angle)];
  const result = solveFloorplan({
    walls: [
      { id: "bottom", p1: [0, 0], p2: [5, 0] },
      { id: "right", p1: [5, 0], p2: [5, 4] },
      { id: "top", p1: [5, 4], p2: [1, 4] },
    ],
    objects: [
      { id: "table", category: "table", kind: "table", center: [2.5, 2], axisW, axisD, halfW: 0.7, halfD: 0.5, height: 0.75 },
      { id: "chair", category: "chair", kind: "chair", center: [3.35, 2.3], axisW: [0, 1], axisD: [-1, 0], halfW: 0.25, halfD: 0.25, height: 0.9, parentId: "table" },
    ],
    source: "canonical",
  });
  const table = result.objects.find((object) => object.id === "table");
  const chair = result.objects.find((object) => object.id === "chair");
  assert.equal(result.diagnostics.roomSource, "fallback-hull");
  assert.equal(result.validation.valid, true);
  assert.equal(table?.candidateSource, "yaw-rectified");
  assert.ok((table?.yawDeltaDeg ?? 0) > 18 && (table?.yawDeltaDeg ?? Infinity) < 20);
  assert.ok(Math.abs(table?.axisW[1] ?? Infinity) < 1e-6);
  assert.equal(chair?.candidateSource, "table-seat");
  assert.equal(chair?.parentId, "table");
});

test("an object crossing an L-shaped room concavity is rejected rather than projected through a wall", () => {
  const room = {
    id: "l-room",
    type: "unknown",
    source: "manual",
    polygon: [[0, 0], [4, 0], [4, 1.5], [1.5, 1.5], [1.5, 4], [0, 4]],
  };
  const result = solveFloorplan({
    rooms: [room],
    walls: [
      { id: "w0", p1: [0, 0], p2: [4, 0] },
      { id: "w1", p1: [4, 0], p2: [4, 1.5] },
      { id: "w2", p1: [4, 1.5], p2: [1.5, 1.5] },
      { id: "w3", p1: [1.5, 1.5], p2: [1.5, 4] },
      { id: "w4", p1: [1.5, 4], p2: [0, 4] },
      { id: "w5", p1: [0, 4], p2: [0, 0] },
    ],
    objects: [{
      id: "bad-box", category: "generic", kind: "generic",
      center: [1.65, 1.65], axisW: [1, 0], axisD: [0, 1], halfW: 0.45, halfD: 0.45, height: 1,
    }],
    source: "canonical",
  });
  assert.equal(result.objects.find((object) => object.id === "bad-box")?.status, "rejected");
  assert.equal(result.validation.valid, true);
});

test("unknown door hinge and swing are treated conservatively", () => {
  const { room, walls } = rectangleScene(5, 4);
  const result = solveFloorplan({
    rooms: [room],
    walls,
    openings: [{ id: "door-unknown", kind: "door", p1: [5, 1.2], p2: [5, 2.1] }],
    objects: [{
      id: "cabinet", category: "storage", kind: "storage",
      center: [4.65, 1.65], axisW: [0, 1], axisD: [-1, 0], halfW: 0.75, halfD: 0.3, height: 2,
    }],
    source: "canonical",
  });
  const cabinet = result.objects.find((object) => object.id === "cabinet");
  assert.ok(cabinet);
  assert.notEqual(cabinet.status, "unchanged");
  assert.equal(result.keepOuts.filter((zone) => zone.kind === "door-swing").length, 2);
  assert.equal(result.validation.valid, true);
});

test("low-confidence furniture outside every room fails closed", () => {
  const { room, walls } = rectangleScene(5, 4);
  const result = solveFloorplan({
    rooms: [room], walls,
    objects: [{
      id: "outside", category: "table", kind: "table",
      center: [6.2, 2], axisW: [1, 0], axisD: [0, 1], halfW: 0.6, halfD: 0.4, height: 0.75, confidence: 0.2,
    }],
    source: "canonical",
  });
  const object = result.objects.find((entry) => entry.id === "outside");
  assert.equal(object?.status, "rejected");
  assert.match(object?.reasons.join(" ") ?? "", /no room/i);
  assert.equal(result.validation.valid, true);
});

test("duplicate storage fragments are merged with an explanation", () => {
  const { room, walls } = rectangleScene(6, 4);
  const result = solveFloorplan({
    rooms: [room], walls,
    objects: [
      { id: "large", category: "storage", kind: "storage", center: [2, 0.4], axisW: [1, 0], axisD: [0, 1], halfW: 1, halfD: 0.3, height: 2, confidence: 0.9 },
      { id: "fragment", category: "storage", kind: "storage", center: [2.05, 0.42], axisW: [1, 0], axisD: [0, 1], halfW: 0.6, halfD: 0.28, height: 2, confidence: 0.5 },
    ],
    source: "canonical",
  });
  const fragment = result.objects.find((entry) => entry.id === "fragment");
  assert.equal(fragment?.status, "merged");
  assert.equal(fragment?.mergedIntoId, "large");
  assert.match(fragment?.reasons.join(" ") ?? "", /duplicate|fragment/i);
  assert.equal(result.validation.valid, true);
});

test("children follow a surviving cabinet after parent-fragment deduplication", () => {
  const { room, walls } = rectangleScene(5, 4);
  const result = solveFloorplan({
    rooms: [{ ...room, type: "kitchen" }],
    walls,
    objects: [
      { id: "cabinet-large", category: "storage", kind: "storage", center: [2.5, 3.68], axisW: [1, 0], axisD: [0, 1], halfW: 1.05, halfD: 0.25, height: 0.9 },
      { id: "cabinet-fragment", category: "storage", kind: "storage", center: [2.5, 3.68], axisW: [1, 0], axisD: [0, 1], halfW: 0.48, halfD: 0.25, height: 0.9 },
      { id: "stove", category: "stove", kind: "stove", center: [2.5, 3.68], axisW: [1, 0], axisD: [0, 1], halfW: 0.32, halfD: 0.25, height: 0.9, parentId: "cabinet-fragment" },
    ],
    source: "canonical",
  });
  const stove = result.objects.find((object) => object.id === "stove");
  assert.equal(result.objects.find((object) => object.id === "cabinet-fragment")?.status, "merged");
  assert.equal(stove?.parentId, "cabinet-large");
  assert.notEqual(stove?.status, "rejected");
});

test("nested kitchen appliances do not create duplicate clearances that delete a dining group", () => {
  const { room, walls } = rectangleScene(5, 4);
  const result = solveFloorplan({
    rooms: [{ ...room, type: "kitchen" }],
    walls,
    objects: [
      { id: "cabinet", category: "storage", kind: "storage", center: [2.5, 3.68], axisW: [1, 0], axisD: [0, 1], halfW: 1.05, halfD: 0.25, height: 0.9 },
      { id: "oven", category: "oven", kind: "oven", center: [2.5, 3.68], axisW: [1, 0], axisD: [0, 1], halfW: 0.32, halfD: 0.25, height: 0.85, parentId: "cabinet" },
      { id: "table", category: "table", kind: "table", center: [2.5, 2.25], axisW: [1, 0], axisD: [0, 1], halfW: 0.7, halfD: 0.45, height: 0.75 },
      { id: "chair", category: "chair", kind: "chair", center: [3.42, 2.25], axisW: [0, 1], axisD: [-1, 0], halfW: 0.25, halfD: 0.25, height: 0.88, parentId: "table" },
    ],
    source: "canonical",
  });
  assert.equal(result.validation.valid, true);
  for (const id of ["cabinet", "oven", "table", "chair"]) {
    assert.notEqual(result.objects.find((object) => object.id === id)?.status, "rejected", `${id} remains in the composed layout`);
  }
  assert.equal(result.objects.find((object) => object.id === "chair")?.candidateSource, "table-seat");
});

test("CapturedStructure sections label the matching floor room", () => {
  const identity = [1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1];
  const translated = (x, y, z) => {
    const m = [...identity]; m[12] = x; m[13] = y; m[14] = z; return m;
  };
  const parsed = parseRoomPlanJSON({
    rooms: [{
      identifier: "room-a",
      floors: [{ identifier: "floor-a", dimensions: [4, 0.1, 3], transform: translated(2, 0, 1.5) }],
      walls: [], doors: [], windows: [], openings: [], objects: [],
    }],
    walls: [], doors: [], windows: [], openings: [], objects: [],
    sections: [{ label: { livingRoom: {} }, center: [2, 0, 1.5], floorIdentifier: "floor-a" }],
  });
  assert.equal(parsed.source, "captured-structure");
  assert.equal(parsed.rooms?.[0]?.type, "livingRoom");
  assert.equal(parsed.rooms?.[0]?.source, "roomplan-section");
});

test("cabinet operational fronts cannot occupy each other", () => {
  const { room, walls } = rectangleScene(5, 4);
  const result = solveFloorplan({
    rooms: [{ ...room, type: "kitchen" }], walls,
    objects: [
      { id: "a", category: "storage", kind: "storage", center: [2.5, 0.38], axisW: [1, 0], axisD: [0, 1], halfW: 0.8, halfD: 0.3, height: 2 },
      { id: "b", category: "storage", kind: "storage", center: [2.5, 1.2], axisW: [1, 0], axisD: [0, -1], halfW: 0.8, halfD: 0.3, height: 2 },
    ],
    source: "canonical",
  });
  assert.equal(result.validation.valid, true);
  assert.equal(result.validation.issues.some((issue) => issue.code === "OBJECT_OVERLAP"), false);
  const accepted = result.objects.filter((object) => !["rejected", "merged"].includes(object.status));
  assert.ok(accepted.length <= 2);
});

test("strict navigation repair may relocate or reject a fixture that disconnects a door approach", () => {
  const width = 7.55392200127244;
  const depth = 3.575694701168686;
  const room = { id: "r", polygon: [[0, 0], [width, 0], [width, depth], [0, depth]], type: "unknown", source: "manual" };
  const walls = [
    { id: "b", p1: [0, 0], p2: [width, 0] },
    { id: "r", p1: [width, 0], p2: [width, depth] },
    { id: "t", p1: [width, depth], p2: [0, depth] },
    { id: "l", p1: [0, depth], p2: [0, 0] },
  ];
  const result = solveFloorplan({
    rooms: [room], walls,
    openings: [{ id: "door", kind: "door", p1: [width, 2.5447434969], p2: [width, 3.4447434969] }],
    objects: [
      { id: "fridge-a", category: "refrigerator", kind: "refrigerator", center: [5.56, 2.97], axisW: [1, 0], axisD: [0, 1], halfW: 0.675, halfD: 0.505, height: 1.8 },
      { id: "fridge-b", category: "refrigerator", kind: "refrigerator", center: [6.90, 1.62], axisW: [0, 1], axisD: [-1, 0], halfW: 0.61, halfD: 0.55, height: 1.8 },
    ],
    source: "canonical",
  });
  assert.equal(result.validation.valid, true);
  assert.equal(result.validation.issues.some((issue) => issue.code === "DOOR_APPROACH_UNREACHABLE"), false);
});

test("an observed dining chair is solved only as a seat tied to the selected table pose", () => {
  const { room, walls } = rectangleScene(6, 5);
  const result = solveFloorplan({
    rooms: [{ ...room, type: "diningRoom" }],
    walls,
    objects: [
      { id: "dining", category: "table", kind: "table", center: [3, 2.5], axisW: [1, 0], axisD: [0, 1], halfW: 0.72, halfD: 0.48, height: 0.76 },
      { id: "seat", category: "chair", kind: "chair", center: [3.25, 2.55], axisW: [0.94, 0.34], axisD: [-0.34, 0.94], halfW: 0.25, halfD: 0.25, height: 0.88 },
    ],
    source: "canonical",
  });
  const table = result.objects.find((object) => object.id === "dining");
  const chair = result.objects.find((object) => object.id === "seat");
  assert.ok(table?.selectedCandidateId);
  assert.equal(chair?.candidateSource, "table-seat");
  assert.match(chair?.reasons.join(" ") ?? "", /dining|table-facing|seat slot/i);
  assert.equal(result.validation.valid, true);
});

test("a chair cannot disappear beneath an unrelated small table", () => {
  const { room, walls } = rectangleScene(5, 4);
  const result = solveFloorplan({
    rooms: [{ ...room, type: "livingRoom" }],
    walls,
    objects: [
      { id: "side-table", category: "table", kind: "table", center: [2.5, 2], axisW: [1, 0], axisD: [0, 1], halfW: 0.42, halfD: 0.34, height: 0.55 },
      { id: "loose-chair", category: "chair", kind: "chair", center: [2.5, 2], axisW: [1, 0], axisD: [0, 1], halfW: 0.26, halfD: 0.26, height: 0.9 },
    ],
    source: "canonical",
  });
  const accepted = result.objects.filter((object) => !["rejected", "merged"].includes(object.status));
  assert.ok(accepted.length < 2 || obbIntersectionArea(accepted[0], accepted[1]) <= 0.0004);
  assert.equal(result.validation.valid, true);
});

test("dining-group constraints hold on seven real MLStructFP CAD envelopes", () => {
  const fixture = JSON.parse(readFileSync(new URL("./fixtures/mlstructfp-sample.json", import.meta.url), "utf8"));
  assert.equal(fixture.provenance.license, "MIT");
  assert.equal(fixture.scenes.length, 7);
  for (const scene of fixture.scenes) {
    assert.ok(scene.probe?.clearance > 2.9, `${scene.id} has a usable regression probe`);
    const [x, z] = scene.probe.center;
    const result = solveFloorplan({
      rooms: scene.rooms,
      walls: scene.walls,
      openings: [],
      objects: [
        { id: `${scene.id}-table`, category: "dining table", attributes: ["dining"], kind: "table", center: [x, z], axisW: [1, 0], axisD: [0, 1], halfW: 0.72, halfD: 0.48, height: 0.76 },
        { id: `${scene.id}-chair`, category: "chair", kind: "chair", center: [x + 0.94, z], axisW: [0, 1], axisD: [-1, 0], halfW: 0.25, halfD: 0.25, height: 0.88, parentId: `${scene.id}-table` },
      ],
      source: "canonical",
    }, { runNavigationRepair: false });
    const chair = result.objects.find((object) => object.kind === "chair");
    assert.equal(chair?.candidateSource, "table-seat", `${scene.id} keeps the chair in an anchored seat slot`);
    assert.equal(result.validation.issues.some((issue) => issue.code === "WALL_COLLISION"), false, `${scene.id} has no furniture-wall penetration`);
    assert.equal(result.validation.issues.some((issue) => issue.code === "OBJECT_OVERLAP"), false, `${scene.id} has no illegal overlap`);
  }
});

test("multi-room furniture groups solve independently without cross-room drift", () => {
  const roomA = rectangleScene(5, 4);
  const roomB = {
    room: { id: "room-2", polygon: [[6, 0], [11, 0], [11, 4], [6, 4]], type: "diningRoom", source: "manual" },
    walls: [
      { id: "b2", p1: [6, 0], p2: [11, 0] },
      { id: "r2", p1: [11, 0], p2: [11, 4] },
      { id: "t2", p1: [11, 4], p2: [6, 4] },
      { id: "l2", p1: [6, 4], p2: [6, 0] },
    ],
  };
  const input = {
    rooms: [{ ...roomA.room, type: "diningRoom" }, roomB.room],
    walls: [...roomA.walls, ...roomB.walls],
    objects: [
      { id: "table-a", category: "dining table", attributes: ["dining"], kind: "table", center: [2.5, 2], axisW: [1, 0], axisD: [0, 1], halfW: 0.7, halfD: 0.45, height: 0.75 },
      { id: "chair-a", category: "chair", kind: "chair", center: [3.42, 2], axisW: [0, 1], axisD: [-1, 0], halfW: 0.25, halfD: 0.25, parentId: "table-a" },
      { id: "table-b", category: "dining table", attributes: ["dining"], kind: "table", center: [8.5, 2], axisW: [1, 0], axisD: [0, 1], halfW: 0.7, halfD: 0.45, height: 0.75 },
      { id: "chair-b", category: "chair", kind: "chair", center: [9.42, 2], axisW: [0, 1], axisD: [-1, 0], halfW: 0.25, halfD: 0.25, parentId: "table-b" },
    ],
    source: "canonical",
  };
  const result = solveFloorplan(input);
  assert.equal(result.validation.valid, true);
  assert.equal(result.objects.find((object) => object.id === "chair-a")?.candidateSource, "table-seat");
  assert.equal(result.objects.find((object) => object.id === "chair-b")?.candidateSource, "table-seat");
  assert.equal(result.objects.find((object) => object.id === "table-a")?.roomId, "room-1");
  assert.equal(result.objects.find((object) => object.id === "table-b")?.roomId, "room-2");
});
