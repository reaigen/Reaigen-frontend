# Priors data directory

`bootstrap-priors.json` mirrors the package's immediate runtime defaults. It is labeled bootstrap because the full third-party datasets are not bundled or automatically downloaded.

Place locally generated files under `data/generated/`:

```text
data/generated/procthor.json
data/generated/arkitscenes.json
data/generated/runtime-priors.json
```

Do not commit licensed raw datasets to this package.
