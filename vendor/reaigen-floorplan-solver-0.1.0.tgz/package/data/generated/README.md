# Generated layout evidence

These files are reproducible solver evidence, not opaque model weights.

- `procthor-10k-semantics.json` mines 10,000 ProcTHOR houses for room-conditioned table roles, nearest dining-seat distances, group counts, doors, and room polygons. The source archive hash is embedded. Public house JSON does not contain asset bounds, so this artifact explicitly does not claim physical size statistics.
- `replicacad-layout-priors.json` mines 84 artist-authored ReplicaCAD arrangements for large-object yaw and nearest-pair evidence. ReplicaCAD covers one apartment family, so it informs composition and conservative rectification rather than population frequency.
- `procthor-10k.json` is the legacy broad-category miner output retained for audit compatibility. Its missing-size fields must not be used as geometry priors.

Physical size and RoomPlan observation-error priors must come from a licensed ARKitScenes export and consented Reaigen before/after editor corrections. The runtime fails closed when those inputs are unavailable.

Regenerate:

```bash
python3 scripts/mine_procthor_semantics.py train.jsonl.gz data/generated/procthor-10k-semantics.json
python3 scripts/mine_replicacad.py /path/to/scene-json data/generated/replicacad-layout-priors.json
python3 scripts/build_runtime_priors.py data/generated/procthor-10k-semantics.json data/generated/replicacad-layout-priors.json src/priors/mined.ts
```
