# Migration from the current Reaigen floorplan solver

## Existing failure mechanism

The current pipeline conditions RoomPlan boxes, assigns them to the nearest connected wall component, wall-hugs selected categories, creates a rectangular door phantom, and performs several AABB overlap pushes. This can leave fixed storage colliding with a fixed door reserve, push objects along unrelated world axes, assign objects to the wrong side of an opening, and solve against stale editor geometry.

The replacement package uses room polygons, oriented geometry, explicit keep-outs, discrete candidates, and final fail-closed validation.

## Migration order

1. Add the package as a local workspace dependency.
2. Copy `integration/reaigen-floorplan-adapter.ts` into the app.
3. Migrate `FloorplanViewer` using `patches/FloorplanViewer.integration.patch.md`.
4. Migrate `FloorplanEditor` using `patches/FloorplanEditor.integration.patch.md`.
5. Preserve RoomPlan floor polygons in the JSON parser when present.
6. Upload Codable `CapturedRoom`/`CapturedStructure` JSON alongside USDZ.
7. Add broken production captures as regression fixtures.
8. Remove the old furniture nudge solver only after visual parity is confirmed.

## Viewer replacement

Old:

```ts
const solvedObjects = solveFurnitureLayout(
  prepareObjects(rawObjects, preBounds),
  wallSegs,
  geom?.interiorCentroid ?? pivot,
  doors,
);
```

New:

```ts
const solved = solveReaigenFloorplan({
  walls: wallSegs,
  doors,
  windows,
  objects: rawObjects,
  doorConfigs: parseDoorConfigs(textData),
  options: { strict: true, runNavigationRepair: true },
});

const objectsR = solved.objects.map(rotObj);
```

Keep the solve in the pre-display-rotation coordinate frame. Apply `floorplan_rotation_degrees` only after solving, exactly as walls and openings are rotated for rendering.

## Editor replacement

Old furniture memo:

```ts
solveFurnitureLayout(
  prepareObjects(base.geom?.objects ?? [], computeBounds(base.initialGraph.vertices)),
  graphSegs(base.initialGraph),
  base.geom?.interiorCentroid ?? [0, 0],
  base.geom?.doors ?? [],
)
```

New furniture memo:

```ts
solveReaigenFloorplan({
  walls: segs,        // graphSegs(graph)
  doors,              // current source + custom, minus deleted
  windows,            // current source + custom, minus deleted
  objects: base.geom?.objects ?? [],
  doorConfigs,
  options: { strict: true, runNavigationRepair: true },
})
```

This change is mandatory. Otherwise a user can move a wall or delete/add a door while furniture continues to solve against the initial scan.

## Room polygons

Best source order:

1. `CapturedStructure.rooms[].floors[].polygonCorners`;
2. individual `CapturedRoom.floors[].polygonCorners`;
3. closed edited wall graph face extraction;
4. fallback hull only for diagnostic recovery.

Do not model one connected wall graph as one room. A wall graph is topology; a room is a bounded face/polygon.

## Persisting solved output

Initially, do not overwrite raw RoomPlan observations. Keep:

```text
captured_room_json          immutable scan observation
wall_graph_json             user-edited architecture
floorplan_opening_edits_json
floorplan_solver_result_json optional cached solved result
floorplan_solver_version    "0.1.0"
```

Caching is optional because the solver is deterministic. Persisting raw and solved data separately makes future coefficient changes and audit/debug views possible.

Recommended cache invalidation signature:

```text
SHA-256(
  captured_room_json +
  wall_graph_json +
  floorplan_opening_edits_json +
  door_N_camera fields +
  solver version +
  priors version
)
```

## UI behavior

- Render `unchanged`, `rectified`, and `relocated` objects.
- Omit `rejected` and `merged` objects from the plan.
- In editor/debug mode, allow selecting an omitted raw observation and reading its `reasons`.
- Show a geometry-repair alert when `validation.valid === false`.
- Never silently reintroduce raw objects after strict rejection.

## Compatibility with the existing icon renderer

Solved objects retain:

```ts
center
axisW
axisD
halfW
halfD
category
height
```

The existing `FurnitureSymbol` and `iconForKind` renderer can consume them directly. The solver normalizes axes and category width/depth semantics before placement, reducing crossed or mirrored icon line work caused by malformed transform bases.

## Performance

For the Viewer, solve once in `useMemo` from the draft signature. For the full editor, use the Worker hook or a debounced solve when scenes become large. The included worker is cancelable; the latest edit should supersede prior pending work.

## Rollout

Use a feature flag:

```ts
const useConstraintSolver = flags.floorplanConstraintSolver;
```

For every scene compare:

```text
raw observation overlay
old solver output
new solver output
new validation report
```

Promote the new path when the production fixture suite meets the acceptance criteria in `README.md`.
