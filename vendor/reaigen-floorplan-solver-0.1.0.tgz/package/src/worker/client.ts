import type { SolveResult, SolverInput, SolverOptions } from "../types.js";
import type { SolverWorkerRequest, SolverWorkerResponse } from "./protocol.js";

interface Pending {
  resolve: (result: SolveResult) => void;
  reject: (error: Error) => void;
  cleanup?: () => void;
}

export interface FloorplanSolverWorkerClient {
  solve(input: SolverInput, options?: SolverOptions, signal?: AbortSignal): Promise<SolveResult>;
  terminate(): void;
}

export function createFloorplanSolverWorker(
  workerFactory: () => Worker = () => new Worker(new URL("./worker.js", import.meta.url), { type: "module" }),
): FloorplanSolverWorkerClient {
  const worker = workerFactory();
  const pending = new Map<number, Pending>();
  let nextId = 1;
  let terminated = false;

  worker.onmessage = (event: MessageEvent<SolverWorkerResponse>) => {
    const response = event.data;
    const item = pending.get(response.id);
    if (!item) return;
    pending.delete(response.id);
    item.cleanup?.();
    if (response.ok) item.resolve(response.result);
    else {
      const error = new Error(response.error.message);
      error.name = response.error.name;
      if (response.error.stack) error.stack = response.error.stack;
      item.reject(error);
    }
  };

  worker.onerror = (event) => {
    const error = new Error(event.message || "Floorplan solver worker failed.");
    for (const [id, item] of pending) {
      pending.delete(id);
      item.cleanup?.();
      item.reject(error);
    }
  };

  return {
    solve(input, options, signal) {
      if (terminated) return Promise.reject(new Error("Floorplan solver worker has been terminated."));
      if (signal?.aborted) return Promise.reject(new DOMException("Aborted", "AbortError"));
      const id = nextId++;
      return new Promise<SolveResult>((resolve, reject) => {
        const onAbort = () => {
          const item = pending.get(id);
          if (!item) return;
          pending.delete(id);
          reject(new DOMException("Aborted", "AbortError"));
        };
        if (signal) signal.addEventListener("abort", onAbort, { once: true });
        pending.set(id, {
          resolve,
          reject,
          cleanup: signal ? () => signal.removeEventListener("abort", onAbort) : undefined,
        });
        const request: SolverWorkerRequest = { id, input, options };
        worker.postMessage(request);
      });
    },
    terminate() {
      terminated = true;
      worker.terminate();
      for (const [id, item] of pending) {
        pending.delete(id);
        item.cleanup?.();
        item.reject(new Error("Floorplan solver worker terminated."));
      }
    },
  };
}

let sharedClient: FloorplanSolverWorkerClient | null = null;

/** Shared browser worker suitable for React/Next.js client components. */
export function solveFloorplanInWorker(
  input: SolverInput,
  options?: SolverOptions,
  signal?: AbortSignal,
): Promise<SolveResult> {
  sharedClient ??= createFloorplanSolverWorker();
  return sharedClient.solve(input, options, signal);
}
