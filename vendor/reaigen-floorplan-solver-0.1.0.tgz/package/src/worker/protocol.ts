import type { SolveResult, SolverInput, SolverOptions } from "../types.js";

export interface SolverWorkerRequest {
  id: number;
  input: SolverInput;
  options?: SolverOptions;
}

export interface SolverWorkerSuccess {
  id: number;
  ok: true;
  result: SolveResult;
}

export interface SolverWorkerFailure {
  id: number;
  ok: false;
  error: { name: string; message: string; stack?: string };
}

export type SolverWorkerResponse = SolverWorkerSuccess | SolverWorkerFailure;
