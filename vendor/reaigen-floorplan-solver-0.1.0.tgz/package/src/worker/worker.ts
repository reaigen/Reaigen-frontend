/// <reference lib="webworker" />

import { solveFloorplan } from "../solver/solve.js";
import type { SolverWorkerRequest, SolverWorkerResponse } from "./protocol.js";

const scope: DedicatedWorkerGlobalScope = self as unknown as DedicatedWorkerGlobalScope;

scope.onmessage = (event: MessageEvent<SolverWorkerRequest>) => {
  const request = event.data;
  let response: SolverWorkerResponse;
  try {
    response = { id: request.id, ok: true, result: solveFloorplan(request.input, request.options) };
  } catch (error) {
    const value = error instanceof Error ? error : new Error(String(error));
    response = {
      id: request.id,
      ok: false,
      error: { name: value.name, message: value.message, stack: value.stack },
    };
  }
  scope.postMessage(response);
};
