export * from "./types.js";
export * from "./input/index.js";
export * from "./priors/index.js";
export * from "./solver/solve.js";
export * from "./solver/validate.js";
export * from "./solver/rooms.js";
export * from "./solver/keepouts.js";
export * from "./geometry/vector.js";
export * from "./geometry/polygon.js";
export * from "./geometry/obb.js";
export * from "./geometry/planar-graph.js";

import type { RoomPlanParseOptions } from "./input/roomplan-json.js";
import { parseRoomPlanJSON } from "./input/roomplan-json.js";
import type { LegacyFloorplanInput } from "./input/legacy-adapter.js";
import { legacyFloorplanToSolverInput } from "./input/legacy-adapter.js";
import type { SolveResult, SolverOptions } from "./types.js";
import { solveFloorplan } from "./solver/solve.js";

/** Convenience API for Codable CapturedRoom/CapturedStructure JSON. */
export function solveRoomPlanJSON(
  json: unknown,
  options: SolverOptions & { roomPlan?: RoomPlanParseOptions } = {},
): SolveResult {
  const { roomPlan, ...solverOptions } = options;
  return solveFloorplan(parseRoomPlanJSON(json, roomPlan), solverOptions);
}

/** Drop-in adapter for the current Reaigen `ObjectXZ`/wall/opening model. */
export function solveLegacyFloorplan(
  input: LegacyFloorplanInput,
  options: SolverOptions = {},
): SolveResult {
  return solveFloorplan(legacyFloorplanToSolverInput(input), options);
}
