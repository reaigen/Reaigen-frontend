"use client";

import { useEffect, useRef, useState } from "react";
import type { SolveResult, SolverInput, SolverOptions } from "../types.js";
import { createFloorplanSolverWorker, type FloorplanSolverWorkerClient } from "../worker/client.js";

export interface UseFloorplanSolverState {
  result: SolveResult | null;
  loading: boolean;
  error: Error | null;
}

const EMPTY_OPTIONS: SolverOptions = Object.freeze({});

/** Deterministic JSON fingerprint for plain solver inputs/options.
 *
 * React state updates re-render the calling component. An inline object such as
 * `{ strict: true }` would otherwise have a new identity on every render and
 * repeatedly restart the worker effect. Solver data is JSON-compatible, so a
 * canonical key is both predictable and safer than identity-only dependencies.
 */
function stableKey(value: unknown): string {
  const seen = new WeakSet<object>();
  const normalize = (input: unknown): unknown => {
    if (input == null || typeof input !== "object") return input;
    if (seen.has(input)) throw new TypeError("Floorplan solver input must not contain circular references.");
    seen.add(input);
    if (Array.isArray(input)) {
      const result = input.map(normalize);
      seen.delete(input);
      return result;
    }
    const record = input as Record<string, unknown>;
    const result: Record<string, unknown> = {};
    for (const key of Object.keys(record).sort()) {
      const entry = record[key];
      if (entry !== undefined) result[key] = normalize(entry);
    }
    seen.delete(input);
    return result;
  };
  return JSON.stringify(normalize(value));
}

/**
 * Next.js client hook backed by a Web Worker.
 *
 * The hook uses content fingerprints, so callers may pass freshly-created
 * JSON-compatible input/options without causing a solve loop. For very large
 * structures, memoizing the input still avoids repeated serialization work.
 */
export function useFloorplanSolver(
  input: SolverInput | null,
  options: SolverOptions = EMPTY_OPTIONS,
): UseFloorplanSolverState {
  const client = useRef<FloorplanSolverWorkerClient | null>(null);
  const inputRef = useRef<SolverInput | null>(input);
  const optionsRef = useRef<SolverOptions>(options);
  inputRef.current = input;
  optionsRef.current = options;

  const inputKey = input ? stableKey(input) : "";
  const optionsKey = stableKey(options);
  const [state, setState] = useState<UseFloorplanSolverState>({ result: null, loading: !!input, error: null });

  useEffect(() => {
    client.current ??= createFloorplanSolverWorker();
    return () => {
      client.current?.terminate();
      client.current = null;
    };
  }, []);

  useEffect(() => {
    const currentInput = inputRef.current;
    if (!currentInput) {
      setState({ result: null, loading: false, error: null });
      return;
    }
    const controller = new AbortController();
    setState((previous) => ({ ...previous, loading: true, error: null }));
    client.current!
      .solve(currentInput, optionsRef.current, controller.signal)
      .then((result) => setState({ result, loading: false, error: null }))
      .catch((error: unknown) => {
        if (controller.signal.aborted) return;
        setState({ result: null, loading: false, error: error instanceof Error ? error : new Error(String(error)) });
      });
    return () => controller.abort();
  }, [inputKey, optionsKey]);

  return state;
}
