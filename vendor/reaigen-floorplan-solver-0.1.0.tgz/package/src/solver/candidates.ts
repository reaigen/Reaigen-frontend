import type {
  FurnitureObservation,
  FurniturePose,
  LayoutPriors,
  OpeningObservation,
  PlacementCandidate,
  RoomObservation,
  Vec2,
} from "../types.js";
import { closestPointOnSegment, distancePointToSegment, ensureCCW, pointInPolygon, polygonEdges } from "../geometry/polygon.js";
import { poseDisplacement, poseYawDelta } from "../geometry/obb.js";
import { add, clamp, cross, distance, dot, leftNormal, normalize, scale, sub } from "../geometry/vector.js";
import type { ConstraintContext } from "./constraints.js";
import { validateCandidate } from "./constraints.js";
import { classifyTableRole } from "./semantics.js";

interface CandidateBuildContext {
  roomsById: Map<string, RoomObservation>;
  openings: OpeningObservation[];
  constraints: ConstraintContext;
  priors: LayoutPriors;
  objects: FurnitureObservation[];
}

interface EdgeFrame {
  roomId: string;
  edgeIndex: number;
  p1: Vec2;
  p2: Vec2;
  u: Vec2;
  inward: Vec2;
  length: number;
  wallId: string;
}

function roomEdges(room: RoomObservation): EdgeFrame[] {
  const polygon = ensureCCW(room.polygon);
  return polygonEdges(polygon).map(([p1, p2], edgeIndex) => {
    const delta = sub(p2, p1);
    const length = Math.max(Math.hypot(delta[0], delta[1]), 1e-6);
    const u = [delta[0] / length, delta[1] / length] as Vec2;
    return {
      roomId: room.id,
      edgeIndex,
      p1,
      p2,
      u,
      inward: leftNormal(u),
      length,
      wallId: `${room.id}:edge:${edgeIndex}`,
    };
  });
}

function poseClone(object: FurnitureObservation): FurniturePose {
  return {
    center: [object.center[0], object.center[1]],
    axisW: [object.axisW[0], object.axisW[1]],
    axisD: [object.axisD[0], object.axisD[1]],
    halfW: object.halfW,
    halfD: object.halfD,
  };
}

function orientationCost(source: FurniturePose, target: FurniturePose): number {
  return poseYawDelta(source, target) * 1.6 + poseDisplacement(source, target) * 0.1;
}

function roomCompatibilityCost(object: FurnitureObservation, room: RoomObservation, priors: LayoutPriors): number {
  return priors.kinds[object.kind].roomWeights?.[room.type ?? "unknown"] ?? 1;
}

function dimensionAssignment(object: FurnitureObservation, preference: "width-long" | "depth-long" | "preserve"): { halfW: number; halfD: number; swapped: boolean } {
  const long = Math.max(object.halfW, object.halfD);
  const short = Math.min(object.halfW, object.halfD);
  if (preference === "width-long") return { halfW: long, halfD: short, swapped: object.halfW < object.halfD };
  if (preference === "depth-long") return { halfW: short, halfD: long, swapped: object.halfD < object.halfW };
  return { halfW: object.halfW, halfD: object.halfD, swapped: false };
}

function wallPose(object: FurnitureObservation, edge: EdgeFrame, t: number, priors: LayoutPriors): FurniturePose {
  const prior = priors.kinds[object.kind];
  const dims = dimensionAssignment(object, prior.widthDepthPreference);
  const axisW = dot(edge.u, object.axisW) >= 0 ? edge.u : scale(edge.u, -1);
  const axisD = edge.inward;
  const targetDepth = priors.wallThickness / 2 + prior.backGap + dims.halfD;
  return {
    center: add(add(edge.p1, scale(edge.u, t)), scale(edge.inward, targetDepth)),
    axisW,
    axisD,
    halfW: dims.halfW,
    halfD: dims.halfD,
  };
}

function wallRelationCost(
  object: FurnitureObservation,
  pose: FurniturePose,
  room: RoomObservation,
  priors: LayoutPriors,
): number {
  const prior = priors.kinds[object.kind];
  if (prior.placement === "free") return 0;
  let best = Number.POSITIVE_INFINITY;
  for (const edge of roomEdges(room)) {
    const inwardDistance = dot(sub(pose.center, edge.p1), edge.inward);
    const halfNormal =
      Math.abs(dot(pose.axisW, edge.inward)) * pose.halfW
      + Math.abs(dot(pose.axisD, edge.inward)) * pose.halfD;
    const edgeGap = inwardDistance - halfNormal;
    const gapError = Math.abs(edgeGap - (priors.wallThickness / 2 + prior.backGap));
    const depthAlignment = 1 - Math.abs(dot(pose.axisD, edge.inward));
    const alongAlignment = 1 - Math.abs(dot(pose.axisW, edge.u));
    const alignment = Math.min(depthAlignment, alongAlignment + 0.25);
    best = Math.min(best, gapError + alignment * 0.45);
  }
  if (!Number.isFinite(best)) return 0;
  const strength = prior.placement === "fixture" ? 7 : prior.placement === "wall-required" ? 5 : 1.2;
  // Wall-preferred furniture is only encouraged when it was already near a
  // wall; freestanding sofas must remain legal.
  if (prior.placement === "wall-preferred" && best > 0.75) return 0.2;
  return strength * prior.wallAffinity * (best / 0.35) ** 2;
}

function placementCost(
  object: FurnitureObservation,
  pose: FurniturePose,
  room: RoomObservation,
  priors: LayoutPriors,
  source: PlacementCandidate["source"],
): number {
  const prior = priors.kinds[object.kind];
  const displacement = poseDisplacement(object, pose);
  const yaw = poseYawDelta(object, pose);
  const moveScale = Math.max(prior.maxMove, 0.15);
  const relocationSource = source === "wall" || source === "storage-wall-run" || source === "measured-wall-clearance";
  const relationSource = source === "table-seat" || source === "dining-group" || source === "satellite-table" || source === "tv-sofa";
  const moveWeight = source === "storage-wall-run" ? 1.1 : source === "wall" ? 1.7 : source === "measured-wall-clearance" ? 2.5 : relationSource ? 2.2 : 5;
  const displacementCost = moveWeight * (displacement / moveScale) ** 2;
  const yawScale = relationSource
    ? Math.PI / 2
    : Math.max((prior.yawSnapDeg * Math.PI) / 180, 0.05);
  // Rotating an object onto another legal wall is a deliberate layout move,
  // not a 90-degree sensor error. Preserve strong yaw trust only for raw and
  // small rectification candidates.
  const yawWeight = relocationSource ? 0.08 : relationSource ? 0.18 : 1.7;
  const yawCost = yawWeight * (yaw / yawScale) ** 2;
  const sourceCost = source === "raw" ? 0 : source === "measured-wall-clearance" ? 0.08 : source === "yaw-rectified" ? 0.15 : source === "storage-wall-run" ? 0.1 : relationSource ? 0.05 : 0.35;
  return displacementCost
    + yawCost
    + sourceCost
    + roomCompatibilityCost(object, room, priors)
    + (room.source === "fallback-hull" ? 0 : wallRelationCost(object, pose, room, priors));
}

function chooseRectifiedPose(
  object: FurnitureObservation,
  room: RoomObservation,
  priors: LayoutPriors,
  maxAngleDeg?: number,
): FurniturePose | null {
  const prior = priors.kinds[object.kind];
  const maxAngle = ((maxAngleDeg ?? prior.yawSnapDeg) * Math.PI) / 180;
  let best: FurniturePose | null = null;
  let bestCost = Number.POSITIVE_INFINITY;
  const handedness = cross(object.axisW, object.axisD) >= 0 ? 1 : -1;
  for (const edge of roomEdges(room)) {
    for (const base of [edge.u, edge.inward]) {
      for (const sign of [1, -1]) {
        const axisW = scale(base, sign);
        const axisD = handedness >= 0 ? leftNormal(axisW) : scale(leftNormal(axisW), -1);
        const pose: FurniturePose = { ...poseClone(object), axisW, axisD };
        const delta = poseYawDelta(object, pose);
        if (delta > maxAngle) continue;
        const c = orientationCost(object, pose);
        if (c < bestCost) {
          best = pose;
          bestCost = c;
        }
      }
    }
  }
  return best;
}

function chooseRectifiedPoseFromMeasuredWalls(
  object: FurnitureObservation,
  room: RoomObservation,
  context: CandidateBuildContext,
  maxAngleDeg: number,
): FurniturePose | null {
  const wallDirections = context.constraints.walls
    .filter((wall) => !wall.roomIds?.length || wall.roomIds.includes(room.id))
    .map((wall) => normalize(sub(wall.p2, wall.p1)))
    .filter((axis) => Math.hypot(axis[0], axis[1]) > 0.5);
  if (!wallDirections.length) {
    return chooseRectifiedPose(object, room, context.priors, maxAngleDeg);
  }
  const maxAngle = (maxAngleDeg * Math.PI) / 180;
  const handedness = cross(object.axisW, object.axisD) >= 0 ? 1 : -1;
  let best: FurniturePose | null = null;
  let bestCost = Number.POSITIVE_INFINITY;
  for (const wallAxis of wallDirections) {
    for (const base of [wallAxis, leftNormal(wallAxis)]) {
      for (const sign of [1, -1]) {
        const axisW = scale(base, sign);
        const axisD = handedness >= 0 ? leftNormal(axisW) : scale(leftNormal(axisW), -1);
        const pose: FurniturePose = { ...poseClone(object), axisW, axisD };
        const delta = poseYawDelta(object, pose);
        if (delta > maxAngle) continue;
        const cost = orientationCost(object, pose);
        if (cost < bestCost) {
          best = pose;
          bestCost = cost;
        }
      }
    }
  }
  return best;
}

function projectedParameter(point: Vec2, edge: EdgeFrame): number {
  return dot(sub(point, edge.p1), edge.u);
}

interface Interval { start: number; end: number }

function mergeIntervals(intervals: Interval[], low: number, high: number): Interval[] {
  const sorted = intervals
    .map((i) => ({ start: clamp(Math.min(i.start, i.end), low, high), end: clamp(Math.max(i.start, i.end), low, high) }))
    .filter((i) => i.end > i.start)
    .sort((a, b) => a.start - b.start || a.end - b.end);
  const out: Interval[] = [];
  for (const interval of sorted) {
    const last = out[out.length - 1];
    if (!last || interval.start > last.end + 1e-6) out.push({ ...interval });
    else last.end = Math.max(last.end, interval.end);
  }
  return out;
}

function freeIntervals(blocked: Interval[], low: number, high: number): Interval[] {
  const merged = mergeIntervals(blocked, low, high);
  const free: Interval[] = [];
  let cursor = low;
  for (const interval of merged) {
    if (interval.start > cursor) free.push({ start: cursor, end: interval.start });
    cursor = Math.max(cursor, interval.end);
  }
  if (cursor < high) free.push({ start: cursor, end: high });
  return free;
}

function openingsBlockingEdge(edge: EdgeFrame, openings: OpeningObservation[], priors: LayoutPriors): Interval[] {
  const blocked: Interval[] = [];
  for (const opening of openings) {
    if (opening.roomIds?.length && !opening.roomIds.includes(edge.roomId)) continue;
    const mid: Vec2 = [(opening.p1[0] + opening.p2[0]) / 2, (opening.p1[1] + opening.p2[1]) / 2];
    if (distancePointToSegment(mid, edge.p1, edge.p2) > 0.32) continue;
    const dir = normalize(sub(opening.p2, opening.p1));
    if (Math.abs(dot(dir, edge.u)) < 0.8) continue;
    const t1 = projectedParameter(opening.p1, edge);
    const t2 = projectedParameter(opening.p2, edge);
    const side = opening.kind === "window" ? priors.windowTallSideClearance : priors.doorSideClearance;
    blocked.push({ start: Math.min(t1, t2) - side, end: Math.max(t1, t2) + side });
  }
  return blocked;
}

function makeCandidate(
  object: FurnitureObservation,
  room: RoomObservation,
  pose: FurniturePose,
  source: PlacementCandidate["source"],
  index: number,
  context: CandidateBuildContext,
  extras: Partial<PlacementCandidate> = {},
): PlacementCandidate {
  const candidate: PlacementCandidate = {
    id: `${object.id}:${source}:${index}`,
    objectId: object.id,
    roomId: room.id,
    pose,
    source,
    baseCost: placementCost(object, pose, room, context.priors, source),
    reasons: [],
    hardValid: true,
    hardInvalidReasons: [],
    ...extras,
  };
  return validateCandidate(candidate, object, context.constraints);
}

function wallCandidates(
  object: FurnitureObservation,
  room: RoomObservation,
  context: CandidateBuildContext,
): PlacementCandidate[] {
  const prior = context.priors.kinds[object.kind];
  if (prior.placement === "free") return [];
  const dims = dimensionAssignment(object, prior.widthDepthPreference);
  const candidates: PlacementCandidate[] = [];
  let index = 0;
  for (const edge of roomEdges(room)) {
    if (edge.length < 2 * dims.halfW + context.priors.storageEndClearance * 2) continue;
    const minT = dims.halfW + context.priors.storageEndClearance;
    const maxT = edge.length - dims.halfW - context.priors.storageEndClearance;
    const rawT = clamp(projectedParameter(object.center, edge), minT, maxT);
    const ts = [rawT, minT, maxT, (minT + maxT) / 2];
    for (const t of ts) {
      const pose = wallPose(object, edge, t, context.priors);
      const displacement = poseDisplacement(object, pose);
      if (displacement > prior.maxMove) continue;
      candidates.push(makeCandidate(object, room, pose, "wall", index++, context, {
        wallId: edge.wallId,
        wallParameter: t,
        reasons: [`Aligned ${object.kind} to room wall.`],
      }));
    }
  }
  return candidates;
}

/** Discrete local recovery poses for freestanding observations. A valid table
 * should not be dropped only because its measured footprint clips a cabinet
 * service zone or another movable object. These remain bounded candidates in
 * the object's measured frame; the beam search still decides whether moving
 * or rejecting the observation produces the best globally valid scene. */
function freeSpaceCandidates(
  object: FurnitureObservation,
  room: RoomObservation,
  context: CandidateBuildContext,
): PlacementCandidate[] {
  const prior = context.priors.kinds[object.kind];
  // Blind translations create the random-looking layouts this solver is
  // intended to prevent. The only free-space recovery here is a bounded move
  // of a dining anchor; chairs and satellite tables are handled as dependent
  // semantic candidates in relations.ts.
  if (
    object.kind !== "table"
    || classifyTableRole(object, context.objects, context.priors) !== "dining"
    || prior.maxMove < 0.12
  ) return [];
  const directions: Vec2[] = [
    object.axisW,
    scale(object.axisW, -1),
    object.axisD,
    scale(object.axisD, -1),
  ];
  const steps = [...new Set([
    Math.min(0.24, prior.maxMove * 0.45),
    Math.min(0.48, prior.maxMove * 0.8),
  ].filter((step) => step >= 0.1).map((step) => Math.round(step * 1000) / 1000))];
  const candidates: PlacementCandidate[] = [];
  const axialPose = chooseRectifiedPoseFromMeasuredWalls(
    object,
    room,
    context,
    context.priors.semantic.relocatedDiningAxialMaxDeg,
  );
  let index = 0;
  for (const step of steps) {
    for (const direction of directions) {
      const pose = poseClone(object);
      pose.center = add(object.center, scale(direction, step));
      candidates.push(makeCandidate(object, room, pose, "fallback", index++, context, {
        reasons: ["Relocated within the measured room to clear a hard layout conflict."],
      }));
      if (axialPose) {
        const groupedPose: FurniturePose = {
          ...axialPose,
          center: [pose.center[0], pose.center[1]],
        };
        candidates.push(makeCandidate(object, room, groupedPose, "dining-group", index++, context, {
          reasons: ["Relocated and aligned the dining group to the room frame after a hard conflict."],
        }));
      }
    }
  }
  return candidates;
}

function storageRelocationLimit(object: FurnitureObservation, priors: LayoutPriors): number {
  const priorLimit = priors.kinds[object.kind].maxMove;
  // Tall cabinets are strong architectural observations. Moving a wardrobe to
  // another side of a room produces a plausible-looking but false plan, so a
  // legal interval must remain local to the measured wall. Low casework gets
  // a little more tolerance for fragmented RoomPlan runs, but never a room-
  // scale relocation.
  return Math.min(priorLimit, (object.height ?? 0) >= 1.6 ? 0.45 : 0.75);
}

function storageCandidates(
  object: FurnitureObservation,
  room: RoomObservation,
  context: CandidateBuildContext,
): PlacementCandidate[] {
  const dims = dimensionAssignment(object, "width-long");
  const relocationLimit = storageRelocationLimit(object, context.priors);
  const candidates: PlacementCandidate[] = [];
  let index = 0;
  for (const edge of roomEdges(room)) {
    const minCenter = dims.halfW + context.priors.storageEndClearance;
    const maxCenter = edge.length - dims.halfW - context.priors.storageEndClearance;
    if (maxCenter < minCenter) continue;
    const blocked = openingsBlockingEdge(edge, context.openings, context.priors).map((interval) => ({
      start: interval.start - dims.halfW,
      end: interval.end + dims.halfW,
    }));
    const free = freeIntervals(blocked, minCenter, maxCenter);
    for (const interval of free) {
      if (interval.end < interval.start) continue;
      const rawT = clamp(projectedParameter(object.center, edge), interval.start, interval.end);
      const ts = [rawT, interval.start, interval.end, (interval.start + interval.end) / 2];
      for (const t of ts) {
        const pose = wallPose(object, edge, t, context.priors);
        if (poseDisplacement(object, pose) > relocationLimit) continue;
        candidates.push(makeCandidate(object, room, pose, "storage-wall-run", index++, context, {
          wallId: edge.wallId,
          wallParameter: t,
          reasons: ["Packed into a legal wall interval that excludes doors and windows."],
        }));
      }
    }
  }
  return candidates;
}

function candidateKey(candidate: PlacementCandidate): string {
  if (!candidate.pose) return "reject";
  const p = candidate.pose;
  return [
    Math.round(p.center[0] * 100),
    Math.round(p.center[1] * 100),
    Math.round(Math.atan2(p.axisW[1], p.axisW[0]) * 100),
    Math.round(p.halfW * 100),
    Math.round(p.halfD * 100),
  ].join(":");
}

function hasFallbackSemanticEvidence(objects: FurnitureObservation[]): boolean {
  const hasStrongAnchor = objects.some((object) =>
    object.kind === "sofa"
    || object.kind === "bed"
    || object.kind === "bathtub"
    || object.kind === "toilet"
  );
  const hasTable = objects.some((object) => object.kind === "table");
  const hasSeat = objects.some((object) => object.kind === "chair");
  return hasStrongAnchor || (hasTable && hasSeat);
}

function hasMeasuredWallSupport(object: FurnitureObservation, context: CandidateBuildContext): boolean {
  const maxAngleCos = Math.cos((15 * Math.PI) / 180);
  for (const wall of context.constraints.walls) {
    const delta = sub(wall.p2, wall.p1);
    const length = Math.hypot(delta[0], delta[1]);
    if (length < 0.15) continue;
    const wallAxis = scale(delta, 1 / length);
    for (const [along, normal, halfDepth] of [
      [object.axisW, object.axisD, object.halfD],
      [object.axisD, object.axisW, object.halfW],
    ] as const) {
      if (Math.abs(dot(along, wallAxis)) < maxAngleCos) continue;
      const edgeA = add(object.center, scale(normal, halfDepth));
      const edgeB = add(object.center, scale(normal, -halfDepth));
      if (
        distancePointToSegment(edgeA, wall.p1, wall.p2) <= context.priors.wallThickness / 2 + 0.18
        || distancePointToSegment(edgeB, wall.p1, wall.p2) <= context.priors.wallThickness / 2 + 0.18
      ) return true;
    }
  }
  return false;
}

function measuredWallClearancePose(
  object: FurnitureObservation,
  context: CandidateBuildContext,
  maxDisplacement = 0.12,
  initialPose: FurniturePose = poseClone(object),
): FurniturePose | null {
  const pose: FurniturePose = {
    center: [initialPose.center[0], initialPose.center[1]],
    axisW: [initialPose.axisW[0], initialPose.axisW[1]],
    axisD: [initialPose.axisD[0], initialPose.axisD[1]],
    halfW: initialPose.halfW,
    halfD: initialPose.halfD,
  };
  let changed = false;
  const walls = [...context.constraints.walls].sort((a, b) => a.id.localeCompare(b.id));
  for (let pass = 0; pass < 2; pass += 1) {
    for (const wall of walls) {
      const delta = sub(wall.p2, wall.p1);
      const length = Math.hypot(delta[0], delta[1]);
      if (length < 0.15) continue;
      const along = scale(delta, 1 / length);
      const normal = leftNormal(along);
      const relative = sub(pose.center, wall.p1);
      const alongCenter = dot(relative, along);
      const halfAlong = Math.abs(dot(pose.axisW, along)) * pose.halfW
        + Math.abs(dot(pose.axisD, along)) * pose.halfD;
      const overlap = Math.max(0, Math.min(length, alongCenter + halfAlong) - Math.max(0, alongCenter - halfAlong));
      if (overlap < Math.min(0.18, halfAlong * 0.35)) continue;

      const signedDistance = dot(relative, normal);
      const halfNormal = Math.abs(dot(pose.axisW, normal)) * pose.halfW
        + Math.abs(dot(pose.axisD, normal)) * pose.halfD;
      const wallHalf = (wall.thickness ?? context.priors.wallThickness) / 2;
      const correction = wallHalf + 0.006 - (Math.abs(signedDistance) - halfNormal);
      if (correction <= 0 || correction > maxDisplacement) continue;
      const direction = signedDistance >= 0 ? normal : scale(normal, -1);
      const nextCenter = add(pose.center, scale(direction, correction));
      if (distance(nextCenter, object.center) > maxDisplacement + 1e-6) continue;
      pose.center = nextCenter;
      changed = true;
    }
  }
  return changed && distance(pose.center, object.center) <= maxDisplacement + 1e-6 ? pose : null;
}

export function generateBaseCandidates(
  object: FurnitureObservation,
  roomId: string | null,
  context: CandidateBuildContext,
): PlacementCandidate[] {
  const prior = context.priors.kinds[object.kind];
  const room = roomId ? context.roomsById.get(roomId) : undefined;
  const candidates: PlacementCandidate[] = [];
  let index = 0;
  const fallbackRoom = room?.source === "fallback-hull";
  const fallbackEvidence = !fallbackRoom || hasFallbackSemanticEvidence(context.objects);
  const wallDependent = prior.placement === "wall-required" || prior.placement === "fixture";
  const fallbackObjectSupported = !fallbackRoom || !wallDependent || hasMeasuredWallSupport(object, context);
  if (room && fallbackEvidence && fallbackObjectSupported) {
    const rawCandidate = makeCandidate(object, room, poseClone(object), "raw", index++, context, {
      reasons: ["Preserved measured RoomPlan pose."],
    });
    candidates.push(rawCandidate);
    const explicitDiningAnchor = object.kind === "table"
      && context.objects.some((candidate) => candidate.kind === "chair" && candidate.parentId === object.id);
    const rectificationLimit = explicitDiningAnchor ? Math.max(prior.yawSnapDeg, 22) : prior.yawSnapDeg;
    const rectified = fallbackRoom || object.kind === "table"
      ? chooseRectifiedPoseFromMeasuredWalls(object, room, context, rectificationLimit)
      : chooseRectifiedPose(object, room, context.priors);
    if (rectified) {
      const rectifiedCandidate = makeCandidate(object, room, rectified, "yaw-rectified", index++, context, {
        reasons: ["Corrected small RoomPlan yaw error against the room frame."],
      });
      // A valid raw pose used to dominate every small-yaw correction because
      // its source cost was always lower. Tables are presentation anchors, so
      // a legal correction inside their conservative learned threshold must
      // beat the equivalent noisy raw pose.
      if (object.kind === "table" && poseYawDelta(object, rectified) > (0.25 * Math.PI) / 180) {
        rectifiedCandidate.baseCost = Math.min(rectifiedCandidate.baseCost, rawCandidate.baseCost - 0.08);
      }
      candidates.push(rectifiedCandidate);
    }
    if (fallbackRoom) {
      const lowBuiltIn = object.kind === "storage" && (object.height ?? 0) <= 1.2;
      const clearanceLimit = lowBuiltIn ? 0.16 : 0.12;
      const cleared = measuredWallClearancePose(object, context, clearanceLimit);
      let clearedCandidate: PlacementCandidate | undefined;
      if (cleared) {
        clearedCandidate = makeCandidate(object, room, cleared, "measured-wall-clearance", index++, context, {
          reasons: ["Cleared measured wall penetration with a bounded translation while preserving yaw and size."],
        });
        candidates.push(clearedCandidate);
      }
      const clearedRectified = rectified
        ? measuredWallClearancePose(object, context, clearanceLimit, rectified)
        : null;
      if (clearedRectified) {
        const combined = makeCandidate(object, room, clearedRectified, "measured-wall-clearance", index++, context, {
          reasons: ["Rectified measured yaw and cleared wall penetration without changing the observed size."],
        });
        if (clearedCandidate && poseYawDelta(object, clearedRectified) > (0.25 * Math.PI) / 180) {
          combined.baseCost = Math.min(combined.baseCost, clearedCandidate.baseCost - 0.05);
        }
        candidates.push(combined);
      }
    }
    if (!fallbackRoom) {
      if (object.kind === "storage") candidates.push(...storageCandidates(object, room, context));
      else candidates.push(...wallCandidates(object, room, context));
      candidates.push(...freeSpaceCandidates(object, room, context));
    }
  }

  const confidence = clamp(object.confidence ?? 0.65, 0, 1);
  const partialTopology = [...context.roomsById.values()].some((candidateRoom) => candidateRoom.source === "fallback-hull");
  const rejectionReason = !room
    ? partialTopology
      ? "Rejected because partial room topology could not support a reliable room assignment."
      : "Rejected because no room could be assigned."
    : fallbackRoom && (!fallbackEvidence || !fallbackObjectSupported)
      ? "Rejected because partial room topology lacks measured semantic or wall-support evidence."
    : object.kind === "storage"
      ? "Rejected because no legal storage wall interval exists within the evidence-preserving relocation limit."
      : "Reject if no physically valid placement exists.";
  candidates.push({
    id: `${object.id}:reject`,
    objectId: object.id,
    roomId,
    pose: null,
    source: "reject",
    baseCost: prior.dropPenalty * (0.55 + confidence * 0.9),
    reasons: [rejectionReason],
    hardValid: true,
    hardInvalidReasons: [],
  });

  const deduped = new Map<string, PlacementCandidate>();
  for (const candidate of candidates) {
    if (!candidate.hardValid && candidate.source !== "reject") continue;
    const key = candidateKey(candidate);
    const existing = deduped.get(key);
    if (!existing || candidate.baseCost < existing.baseCost) deduped.set(key, candidate);
  }
  const all = [...deduped.values()].sort((a, b) => a.baseCost - b.baseCost || a.id.localeCompare(b.id));
  const reject = all.find((candidate) => candidate.source === "reject");
  const accepted = all
    .filter((candidate) => candidate.source !== "reject")
    .slice(0, Math.max(1, context.priors.maxCandidatesPerObject - 1));
  return reject ? [...accepted, reject] : accepted;
}

export function createCandidateBuildContext(
  rooms: RoomObservation[],
  openings: OpeningObservation[],
  constraints: ConstraintContext,
  priors: LayoutPriors,
  objects: FurnitureObservation[],
): CandidateBuildContext {
  return { roomsById: new Map(rooms.map((room) => [room.id, room])), openings, constraints, priors, objects };
}

export function nearestRoomEdge(point: Vec2, room: RoomObservation): { edge: EdgeFrame; distance: number } | null {
  let best: { edge: EdgeFrame; distance: number } | null = null;
  for (const edge of roomEdges(room)) {
    const d = distance(point, closestPointOnSegment(point, edge.p1, edge.p2));
    if (!best || d < best.distance) best = { edge, distance: d };
  }
  return best;
}

export { roomEdges, wallPose, makeCandidate, type CandidateBuildContext, type EdgeFrame };
