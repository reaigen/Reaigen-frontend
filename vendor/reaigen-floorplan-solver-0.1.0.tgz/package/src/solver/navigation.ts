import type {
  FurnitureObservation,
  KeepOutZone,
  LayoutPriors,
  NavigationMetrics,
  PlacementCandidate,
  RoomObservation,
  ValidationIssue,
  Vec2,
} from "../types.js";
import { obbCorners } from "../geometry/obb.js";
import { pointInPolygon, polygonBounds, polygonCentroid } from "../geometry/polygon.js";
import type { SelectedPlacement } from "./relations.js";

interface RoomNavigationResult {
  roomId: string;
  freeCount: number;
  largestCount: number;
  largestRatio: number;
  componentByCell: Int32Array;
  free: Uint8Array;
  nx: number;
  ny: number;
  minX: number;
  minY: number;
  grid: number;
  largestComponent: number;
}

function cellIndex(x: number, y: number, nx: number): number {
  return y * nx + x;
}

function cellCenter(result: Pick<RoomNavigationResult, "minX" | "minY" | "grid">, x: number, y: number): Vec2 {
  return [result.minX + (x + 0.5) * result.grid, result.minY + (y + 0.5) * result.grid];
}

function objectObstacle(entry: SelectedPlacement, buffer: number): ReturnType<typeof obbCorners> | null {
  if (!entry.candidate.pose) return null;
  // Chairs have a much smaller practical navigation halo than beds/cabinets.
  const scale = entry.object.kind === "chair" ? 0.45 : entry.object.kind === "table" ? 0.75 : 1;
  return obbCorners(entry.candidate.pose, buffer * scale);
}

function analyzeRoom(
  room: RoomObservation,
  selected: SelectedPlacement[],
  priors: LayoutPriors,
): RoomNavigationResult {
  const bounds = polygonBounds(room.polygon) ?? { minX: 0, maxX: 0, minY: 0, maxY: 0 };
  const grid = Math.max(priors.navigationGrid, 0.08);
  const minX = bounds.minX;
  const minY = bounds.minY;
  const nx = Math.max(1, Math.ceil((bounds.maxX - bounds.minX) / grid));
  const ny = Math.max(1, Math.ceil((bounds.maxY - bounds.minY) / grid));
  const free = new Uint8Array(nx * ny);
  const componentByCell = new Int32Array(nx * ny).fill(-1);
  const obstacles = selected
    .filter((entry) => entry.candidate.roomId === room.id && entry.candidate.pose)
    .map((entry) => objectObstacle(entry, priors.navigationObjectBuffer))
    .filter((polygon): polygon is NonNullable<typeof polygon> => polygon !== null);

  let freeCount = 0;
  for (let y = 0; y < ny; y++) {
    for (let x = 0; x < nx; x++) {
      const point = cellCenter({ minX, minY, grid }, x, y);
      if (!pointInPolygon(point, room.polygon, false)) continue;
      if (obstacles.some((obstacle) => pointInPolygon(point, obstacle, true))) continue;
      free[cellIndex(x, y, nx)] = 1;
      freeCount += 1;
    }
  }

  const queue = new Int32Array(Math.max(1, nx * ny));
  let component = 0;
  let largestCount = 0;
  let largestComponent = -1;
  const offsets = [[1, 0], [-1, 0], [0, 1], [0, -1]] as const;
  for (let seed = 0; seed < free.length; seed++) {
    if (!free[seed] || componentByCell[seed] !== -1) continue;
    let head = 0;
    let tail = 0;
    queue[tail++] = seed;
    componentByCell[seed] = component;
    let count = 0;
    while (head < tail) {
      const current = queue[head++];
      if (current == null) continue;
      count += 1;
      const x = current % nx;
      const y = Math.floor(current / nx);
      for (const [dx, dy] of offsets) {
        const xx = x + dx;
        const yy = y + dy;
        if (xx < 0 || yy < 0 || xx >= nx || yy >= ny) continue;
        const next = cellIndex(xx, yy, nx);
        if (!free[next] || componentByCell[next] !== -1) continue;
        componentByCell[next] = component;
        queue[tail++] = next;
      }
    }
    if (count > largestCount) {
      largestCount = count;
      largestComponent = component;
    }
    component += 1;
  }

  return {
    roomId: room.id,
    freeCount,
    largestCount,
    largestRatio: freeCount > 0 ? largestCount / freeCount : 0,
    componentByCell,
    free,
    nx,
    ny,
    minX,
    minY,
    grid,
    largestComponent,
  };
}

function nearestFreeCell(point: Vec2, result: RoomNavigationResult): number | null {
  const baseX = Math.floor((point[0] - result.minX) / result.grid);
  const baseY = Math.floor((point[1] - result.minY) / result.grid);
  let best: number | null = null;
  let bestDistance = Number.POSITIVE_INFINITY;
  const maxRadius = Math.max(2, Math.ceil(0.65 / result.grid));
  for (let radius = 0; radius <= maxRadius; radius++) {
    for (let dy = -radius; dy <= radius; dy++) {
      for (let dx = -radius; dx <= radius; dx++) {
        if (Math.max(Math.abs(dx), Math.abs(dy)) !== radius) continue;
        const x = baseX + dx;
        const y = baseY + dy;
        if (x < 0 || y < 0 || x >= result.nx || y >= result.ny) continue;
        const index = cellIndex(x, y, result.nx);
        if (!result.free[index]) continue;
        const center = cellCenter(result, x, y);
        const d = Math.hypot(center[0] - point[0], center[1] - point[1]);
        if (d < bestDistance) {
          bestDistance = d;
          best = index;
        }
      }
    }
    if (best != null) break;
  }
  return best;
}

export interface NavigationAnalysis {
  metrics: NavigationMetrics;
  issues: ValidationIssue[];
  roomResults: Map<string, RoomNavigationResult>;
  reachableApproachIds: Set<string>;
}

export function analyzeNavigation(
  rooms: RoomObservation[],
  selections: Map<string, SelectedPlacement> | SelectedPlacement[],
  keepOuts: KeepOutZone[],
  priors: LayoutPriors,
): NavigationAnalysis {
  const selected = Array.isArray(selections) ? selections : [...selections.values()];
  const roomResults = new Map<string, RoomNavigationResult>();
  const issues: ValidationIssue[] = [];
  let freeCellCount = 0;
  let largestComponentCellCount = 0;

  for (const room of rooms) {
    const result = analyzeRoom(room, selected, priors);
    roomResults.set(room.id, result);
    freeCellCount += result.freeCount;
    largestComponentCellCount += result.largestCount;
    if (result.freeCount > 12 && result.largestRatio < priors.minNavigationRatio) {
      issues.push({
        code: "NAVIGATION_FRAGMENTED",
        severity: "warning",
        roomId: room.id,
        metric: result.largestRatio,
        message: `Usable free space in room ${room.id} is fragmented (${(result.largestRatio * 100).toFixed(1)}% in the largest component).`,
      });
    }
  }

  const approaches = keepOuts.filter((zone) => zone.kind === "door-approach" || zone.kind === "opening-approach");
  const reachableApproachIds = new Set<string>();
  let reachableDoorApproaches = 0;
  for (const zone of approaches) {
    if (!zone.roomId) continue;
    const result = roomResults.get(zone.roomId);
    if (!result) continue;
    const cell = nearestFreeCell(polygonCentroid(zone.polygon), result);
    const reachable = cell != null && result.componentByCell[cell] === result.largestComponent;
    if (reachable) {
      reachableDoorApproaches += 1;
      reachableApproachIds.add(zone.id);
    } else {
      issues.push({
        code: "DOOR_APPROACH_UNREACHABLE",
        severity: "warning",
        roomId: zone.roomId,
        openingId: zone.openingId,
        message: `The clear approach for opening ${zone.openingId ?? zone.id} is not connected to the room's main free-space component.`,
      });
    }
  }

  return {
    metrics: {
      gridSize: priors.navigationGrid,
      freeCellCount,
      largestComponentCellCount,
      largestComponentRatio: freeCellCount ? largestComponentCellCount / freeCellCount : 0,
      reachableDoorApproaches,
      totalDoorApproaches: approaches.length,
    },
    issues,
    roomResults,
    reachableApproachIds,
  };
}

/** Candidate objects eligible for navigation repair, low-value first. */
export function navigationRepairOrder(
  selected: Map<string, SelectedPlacement>,
  priors: LayoutPriors,
): SelectedPlacement[] {
  return [...selected.values()]
    .filter((entry) => entry.candidate.pose)
    // Fixtures are expensive to move or reject, but they cannot be exempt from
    // a hard exit/accessibility failure. Their higher drop penalties naturally
    // place them late in the repair order; stairs remain structural.
    .filter((entry) => entry.object.kind !== "stairs")
    .sort((a, b) => {
      const aPenalty = priors.kinds[a.object.kind].dropPenalty * (0.5 + (a.object.confidence ?? 0.5));
      const bPenalty = priors.kinds[b.object.kind].dropPenalty * (0.5 + (b.object.confidence ?? 0.5));
      return aPenalty - bPenalty || a.object.id.localeCompare(b.object.id);
    });
}
