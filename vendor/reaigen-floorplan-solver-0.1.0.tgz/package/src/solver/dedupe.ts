import type { FurnitureKind, FurnitureObservation, LayoutPriors } from "../types.js";
import { obbContainmentRatio, poseArea } from "../geometry/obb.js";
import { dot, sub, yawDelta } from "../geometry/vector.js";

export interface DeduplicatedObject {
  object: FurnitureObservation;
  mergedIntoId: string;
  reason: string;
}

export interface DedupeResult {
  kept: FurnitureObservation[];
  removed: DeduplicatedObject[];
}

const CONTAINMENT_OK: Array<[FurnitureKind, FurnitureKind]> = [
  ["chair", "table"],
  ["sink", "storage"],
  ["oven", "storage"],
  ["stove", "storage"],
  ["dishwasher", "storage"],
  ["television", "storage"],
  ["oven", "stove"],
];

const NO_FRONT_BACK_STACK = new Set<FurnitureKind>([
  "sofa",
  "bed",
  "storage",
  "refrigerator",
  "washerDryer",
  "dishwasher",
  "oven",
  "stove",
  "sink",
  "toilet",
  "bathtub",
  "television",
  "fireplace",
]);

export function isAllowedContainmentPair(a: FurnitureObservation, b: FurnitureObservation): boolean {
  if (a.parentId === b.id || b.parentId === a.id) return true;
  return CONTAINMENT_OK.some(([x, y]) => (a.kind === x && b.kind === y) || (a.kind === y && b.kind === x));
}

function sameCategory(a: FurnitureObservation, b: FurnitureObservation): boolean {
  return a.kind === b.kind || a.category.toLowerCase() === b.category.toLowerCase();
}

function preferredWinner(a: FurnitureObservation, b: FurnitureObservation): FurnitureObservation {
  const confidenceA = a.confidence ?? 0.5;
  const confidenceB = b.confidence ?? 0.5;
  if (Math.abs(confidenceA - confidenceB) > 0.12) return confidenceA > confidenceB ? a : b;
  return poseArea(a) >= poseArea(b) ? a : b;
}

function isStackedFragment(a: FurnitureObservation, b: FurnitureObservation, slack: number): boolean {
  if (a.kind !== b.kind || !NO_FRONT_BACK_STACK.has(a.kind)) return false;
  if (yawDelta(a.axisW, b.axisW) > (18 * Math.PI) / 180 && yawDelta(a.axisW, b.axisD) > (18 * Math.PI) / 180) {
    return false;
  }
  const large = poseArea(a) >= poseArea(b) ? a : b;
  const small = large === a ? b : a;
  const offset = sub(small.center, large.center);
  const lateral = Math.abs(dot(offset, large.axisW));
  const forward = Math.abs(dot(offset, large.axisD));
  const smallLateralExtent =
    Math.abs(dot(large.axisW, small.axisW)) * small.halfW
    + Math.abs(dot(large.axisW, small.axisD)) * small.halfD;
  const smallForwardExtent =
    Math.abs(dot(large.axisD, small.axisW)) * small.halfW
    + Math.abs(dot(large.axisD, small.axisD)) * small.halfD;
  if (lateral >= (large.halfW + smallLateralExtent) * 0.62) return false;
  return forward <= large.halfD + smallForwardExtent + slack;
}

export function deduplicateObjects(objects: FurnitureObservation[], priors: LayoutPriors): DedupeResult {
  const removed = new Map<string, DeduplicatedObject>();
  const ordered = [...objects].sort((a, b) => a.id.localeCompare(b.id));
  for (let i = 0; i < ordered.length; i++) {
    const a = ordered[i];
    if (!a || removed.has(a.id)) continue;
    for (let j = i + 1; j < ordered.length; j++) {
      const b = ordered[j];
      if (!b || removed.has(b.id) || isAllowedContainmentPair(a, b)) continue;
      const same = sameCategory(a, b);
      const containmentA = obbContainmentRatio(a, b);
      const containmentB = obbContainmentRatio(b, a);
      const threshold = same ? priors.dedupeSameKindContainment : priors.dedupeCrossKindContainment;
      const duplicate = Math.max(containmentA, containmentB) >= threshold;
      const stacked = same && isStackedFragment(a, b, priors.sameKindStackSlack);
      if (!duplicate && !stacked) continue;
      const winner = preferredWinner(a, b);
      const loser: FurnitureObservation = winner === a ? b : a;
      removed.set(loser.id, {
        object: loser,
        mergedIntoId: winner.id,
        reason: duplicate
          ? `Duplicate/fragment footprint contained by ${winner.id}.`
          : `Impossible same-kind front/back stack collapsed into ${winner.id}.`,
      });
      if (loser === a) break;
    }
  }
  const resolvedWinner = (id: string): string => {
    let current = id;
    const seen = new Set<string>();
    while (removed.has(current) && !seen.has(current)) {
      seen.add(current);
      current = removed.get(current)!.mergedIntoId;
    }
    return current;
  };
  return {
    kept: ordered
      .filter((object) => !removed.has(object.id))
      .map((object) => object.parentId && removed.has(object.parentId)
        ? { ...object, parentId: resolvedWinner(object.parentId) }
        : object),
    removed: [...removed.values()].map((entry) => ({
      ...entry,
      mergedIntoId: resolvedWinner(entry.mergedIntoId),
    })),
  };
}
