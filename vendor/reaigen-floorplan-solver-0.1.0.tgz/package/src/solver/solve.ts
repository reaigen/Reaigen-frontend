import type {
  FurnitureObservation,
  FurniturePose,
  PlacementCandidate,
  SolveResult,
  SolvedFurniture,
  SolverInput,
  SolverOptions,
} from "../types.js";
import { poseDisplacement, poseYawDelta } from "../geometry/obb.js";
import { resolvePriors } from "../priors/defaults.js";
import { solveCandidateGroups, type CandidateGroup } from "./beam.js";
import { generateBaseCandidates, createCandidateBuildContext } from "./candidates.js";
import { conditionObjects } from "./condition.js";
import { buildConstraintContext, candidatesConflict } from "./constraints.js";
import { deduplicateObjects } from "./dedupe.js";
import { annotateOpeningRooms, buildKeepOutZones } from "./keepouts.js";
import { analyzeNavigation, navigationRepairOrder } from "./navigation.js";
import { addRelationCandidates, isDependentObject, type SelectedPlacement } from "./relations.js";
import { inferUnknownRoomTypes } from "./room-types.js";
import { assignObjectToRoom, assignWallsToRooms, buildRooms } from "./rooms.js";
import { validateSelections } from "./validate.js";

function solveCandidateGroupsByRoom(
  groups: CandidateGroup[],
  priors: ReturnType<typeof resolvePriors>,
  fixed: SelectedPlacement[] = [],
): { selections: Map<string, SelectedPlacement>; exploredStates: number } {
  const partitions = new Map<string, CandidateGroup[]>();
  for (const group of groups) {
    const key = group.object.roomId ?? "__unassigned__";
    const partition = partitions.get(key) ?? [];
    partition.push(group);
    partitions.set(key, partition);
  }
  let selections = new Map(fixed.map((entry) => [entry.object.id, entry]));
  let exploredStates = 0;
  for (const key of [...partitions.keys()].sort()) {
    const solved = solveCandidateGroups(partitions.get(key)!, priors, [...selections.values()]);
    selections = solved.selections;
    exploredStates += solved.exploredStates;
  }
  return { selections, exploredStates };
}

function sourcePose(object: FurnitureObservation): FurniturePose {
  return {
    center: [object.center[0], object.center[1]],
    axisW: [object.axisW[0], object.axisW[1]],
    axisD: [object.axisD[0], object.axisD[1]],
    halfW: object.halfW,
    halfD: object.halfD,
  };
}

function rejectCandidate(object: FurnitureObservation, roomId: string | null, cost: number, reason: string): PlacementCandidate {
  return {
    id: `${object.id}:reject:repair`,
    objectId: object.id,
    roomId,
    pose: null,
    source: "reject",
    baseCost: cost,
    reasons: [reason],
    hardValid: true,
    hardInvalidReasons: [],
  };
}

function candidateCompatibleWithSelection(
  object: FurnitureObservation,
  candidate: PlacementCandidate,
  selections: Map<string, SelectedPlacement>,
  priors: ReturnType<typeof resolvePriors>,
): boolean {
  for (const entry of selections.values()) {
    if (entry.object.id === object.id) continue;
    if (candidatesConflict(object, candidate, entry.object, entry.candidate, priors)) return false;
  }
  return true;
}

function navigationObjective(
  rooms: SolveResult["rooms"],
  selections: Map<string, SelectedPlacement>,
  keepOuts: SolveResult["keepOuts"],
  priors: ReturnType<typeof resolvePriors>,
): number {
  const analysis = analyzeNavigation(rooms, selections, keepOuts, priors);
  const unreachable = analysis.metrics.totalDoorApproaches - analysis.metrics.reachableDoorApproaches;
  const fragmented = analysis.issues.filter((issue) => issue.code === "NAVIGATION_FRAGMENTED").length;
  return unreachable * 1000 + fragmented * 80 + (1 - analysis.metrics.largestComponentRatio) * 35;
}

function cascadeReject(
  objectId: string,
  selections: Map<string, SelectedPlacement>,
  priors: ReturnType<typeof resolvePriors>,
  reason: string,
): number {
  let count = 0;
  const queue = [objectId];
  const seen = new Set<string>();
  while (queue.length) {
    const current = queue.shift();
    if (!current || seen.has(current)) continue;
    seen.add(current);
    const entry = selections.get(current);
    if (entry && entry.candidate.pose) {
      selections.set(current, {
        object: entry.object,
        candidate: rejectCandidate(
          entry.object,
          entry.candidate.roomId,
          priors.kinds[entry.object.kind].dropPenalty,
          reason,
        ),
      });
      count += 1;
    }
    for (const dependent of selections.values()) {
      if (dependent.candidate.pose && dependent.candidate.anchorObjectId === current) queue.push(dependent.object.id);
    }
  }
  return count;
}

function repairNavigation(
  rooms: SolveResult["rooms"],
  selections: Map<string, SelectedPlacement>,
  keepOuts: SolveResult["keepOuts"],
  priors: ReturnType<typeof resolvePriors>,
  groupsByObject: Map<string, CandidateGroup>,
): number {
  let repairs = 0;
  let currentObjective = navigationObjective(rooms, selections, keepOuts, priors);
  if (currentObjective <= 1e-6) return 0;

  for (let pass = 0; pass < 10; pass++) {
    const anchoredIds = new Set(
      [...selections.values()]
        .map((entry) => entry.candidate.anchorObjectId)
        .filter((id): id is string => !!id),
    );
    let best:
      | { objectId: string; candidate: PlacementCandidate; objective: number; total: number }
      | null = null;

    for (const entry of navigationRepairOrder(selections, priors)) {
      if (anchoredIds.has(entry.object.id)) continue;
      const group = groupsByObject.get(entry.object.id);
      const alternatives = group?.candidates ?? [];
      for (const candidate of alternatives) {
        if (candidate.id === entry.candidate.id || !candidate.hardValid) continue;
        if (!candidateCompatibleWithSelection(entry.object, candidate, selections, priors)) continue;
        const trial = new Map(selections);
        trial.set(entry.object.id, { object: entry.object, candidate });
        const objective = navigationObjective(rooms, trial, keepOuts, priors);
        const costDelta = Math.max(0, candidate.baseCost - entry.candidate.baseCost);
        const total = objective + costDelta * 0.4;
        if (!best || total < best.total || (total === best.total && candidate.id < best.candidate.id)) {
          best = { objectId: entry.object.id, candidate, objective, total };
        }
      }
    }

    if (!best || best.objective >= currentObjective - 0.01) break;
    const entry = selections.get(best.objectId);
    if (!entry) break;
    selections.set(best.objectId, { object: entry.object, candidate: best.candidate });
    currentObjective = best.objective;
    repairs += 1;
    if (currentObjective <= 1e-6) break;
  }
  return repairs;
}

function failClosedRepair(
  rooms: SolveResult["rooms"],
  walls: SolveResult["walls"],
  keepOuts: SolveResult["keepOuts"],
  selections: Map<string, SelectedPlacement>,
  priors: ReturnType<typeof resolvePriors>,
): number {
  let repairs = 0;
  for (let pass = 0; pass < selections.size + 4; pass++) {
    const report = validateSelections(rooms, walls, keepOuts, selections, priors);
    const errors = report.issues.filter((issue) => issue.severity === "error");
    if (!errors.length) break;
    const implicated = new Set(errors.flatMap((issue) => issue.objectIds ?? []));
    if (!implicated.size) break;
    const candidates = [...implicated]
      .map((id) => selections.get(id))
      .filter((entry): entry is SelectedPlacement => !!entry && !!entry.candidate.pose)
      .sort((a, b) => {
        const pa = priors.kinds[a.object.kind].dropPenalty * (0.55 + (a.object.confidence ?? 0.5));
        const pb = priors.kinds[b.object.kind].dropPenalty * (0.55 + (b.object.confidence ?? 0.5));
        return pa - pb || a.object.id.localeCompare(b.object.id);
      });
    const victim = candidates[0];
    if (!victim) break;
    repairs += cascadeReject(
      victim.object.id,
      selections,
      priors,
      "Rejected by the final hard-constraint validator because no legal alternative remained.",
    );
  }
  return repairs;
}

function statusFor(
  source: FurniturePose,
  selection: SelectedPlacement,
  conditioningReasons: string[],
): SolvedFurniture["status"] {
  if (!selection.candidate.pose) return "rejected";
  const displacement = poseDisplacement(source, selection.candidate.pose);
  const yaw = (poseYawDelta(source, selection.candidate.pose) * 180) / Math.PI;
  if (selection.candidate.source === "raw" && displacement < 0.02 && yaw < 1 && conditioningReasons.length === 0) return "unchanged";
  if ((selection.candidate.source === "yaw-rectified" || conditioningReasons.length > 0) && displacement < 0.12) return "rectified";
  return "relocated";
}

/** Main deterministic constrained apartment-layout solver. */
export function solveFloorplan(input: SolverInput, options: SolverOptions = {}): SolveResult {
  const started = performance.now();
  const priors = resolvePriors(options);
  const roomBuild = buildRooms(input, priors);
  let rooms = roomBuild.rooms;
  const walls = assignWallsToRooms(input.walls, rooms);
  const openings = annotateOpeningRooms(input.openings ?? [], rooms);
  const keepOuts = buildKeepOutZones(openings, rooms, priors);

  const conditioned = conditionObjects(input.objects, priors);
  const dedupe = deduplicateObjects(conditioned.objects, priors);
  const assignmentById = new Map(
    dedupe.kept.map((object) => [object.id, assignObjectToRoom(object, rooms, priors.minRoomContainment)]),
  );
  let objects = dedupe.kept.map((object) => ({ ...object, roomId: assignmentById.get(object.id)?.roomId ?? undefined }));
  rooms = inferUnknownRoomTypes(rooms, objects);

  const constraints = buildConstraintContext(rooms, walls, keepOuts, priors);
  const buildContext = createCandidateBuildContext(rooms, openings, constraints, priors, objects);
  const roomsById = new Map(rooms.map((room) => [room.id, room]));
  const baseGroups = new Map<string, CandidateGroup>();
  for (const object of objects) {
    baseGroups.set(object.id, {
      object,
      candidates: generateBaseCandidates(object, object.roomId ?? null, buildContext),
    });
  }

  const primaryObjects = objects.filter((object) => !isDependentObject(object, objects, priors));
  const tierOneObjects = objects.filter((object) => isDependentObject(object, objects, priors) && object.kind !== "chair");
  const tierTwoObjects = objects.filter((object) => object.kind === "chair" && isDependentObject(object, objects, priors));

  let exploredStates = 0;
  const primary = solveCandidateGroupsByRoom(
    primaryObjects.map((object) => baseGroups.get(object.id)!),
    priors,
  );
  exploredStates += primary.exploredStates;
  let selections = primary.selections;

  const solveDependentTier = (tier: FurnitureObservation[]): void => {
    if (!tier.length) return;
    const groups: CandidateGroup[] = tier.map((object) => {
      const base = baseGroups.get(object.id)!;
      const candidates = addRelationCandidates(
        object,
        object.roomId ? roomsById.get(object.roomId) : undefined,
        base.candidates,
        selections,
        buildContext,
      );
      const group = { object, candidates };
      baseGroups.set(object.id, group);
      return group;
    });
    const solved = solveCandidateGroupsByRoom(groups, priors, [...selections.values()]);
    exploredStates += solved.exploredStates;
    selections = solved.selections;
  };

  solveDependentTier(tierOneObjects);
  solveDependentTier(tierTwoObjects);

  let repairCount = 0;
  if (options.runNavigationRepair !== false) {
    repairCount += repairNavigation(rooms, selections, keepOuts, priors, baseGroups);
  }
  if (options.strict !== false) {
    repairCount += failClosedRepair(rooms, walls, keepOuts, selections, priors);
  }

  const validation = validateSelections(rooms, walls, keepOuts, selections, priors);
  const removedById = new Map(dedupe.removed.map((entry) => [entry.object.id, entry]));
  const conditionedById = new Map(conditioned.objects.map((object) => [object.id, object]));
  const selectedObjectById = new Map(objects.map((object) => [object.id, object]));
  const originalById = new Map(input.objects.map((object) => [object.id, object]));
  const solvedObjects: SolvedFurniture[] = [];

  for (const original of input.objects) {
    const originalPose = conditioned.sourcePoses.get(original.id) ?? sourcePose(original);
    const removed = removedById.get(original.id);
    if (removed) {
      solvedObjects.push({
        ...original,
        status: "merged",
        roomId: null,
        sourcePose: originalPose,
        selectedCandidateId: null,
        candidateSource: null,
        displacement: 0,
        yawDeltaDeg: 0,
        score: 0,
        reasons: [removed.reason],
        mergedIntoId: removed.mergedIntoId,
      });
      continue;
    }

    const object = selectedObjectById.get(original.id) ?? conditionedById.get(original.id) ?? original;
    const selection = selections.get(original.id) ?? {
      object,
      candidate: rejectCandidate(object, object.roomId ?? null, priors.kinds[object.kind].dropPenalty, "No solver selection was produced."),
    };
    const candidate = selection.candidate;
    const finalPose = candidate.pose ?? object;
    const conditioningReasons = conditioned.reasons.get(original.id) ?? [];
    const reasons = [...conditioningReasons, ...candidate.reasons];
    solvedObjects.push({
      ...object,
      center: [finalPose.center[0], finalPose.center[1]],
      axisW: [finalPose.axisW[0], finalPose.axisW[1]],
      axisD: [finalPose.axisD[0], finalPose.axisD[1]],
      halfW: finalPose.halfW,
      halfD: finalPose.halfD,
      status: statusFor(originalPose, selection, conditioningReasons),
      roomId: candidate.roomId,
      sourcePose: originalPose,
      selectedCandidateId: candidate.pose ? candidate.id : null,
      candidateSource: candidate.source,
      displacement: candidate.pose ? poseDisplacement(originalPose, candidate.pose) : 0,
      yawDeltaDeg: candidate.pose ? (poseYawDelta(originalPose, candidate.pose) * 180) / Math.PI : 0,
      score: candidate.baseCost,
      reasons,
    });
  }

  const acceptedCount = solvedObjects.filter((object) => object.status !== "rejected" && object.status !== "merged").length;
  const rejectedCount = solvedObjects.filter((object) => object.status === "rejected").length;
  const candidateCount = [...baseGroups.values()].reduce((sum, group) => sum + group.candidates.length, 0);

  return {
    rooms,
    walls,
    openings,
    keepOuts,
    objects: solvedObjects,
    validation,
    diagnostics: {
      elapsedMs: performance.now() - started,
      roomSource: roomBuild.source,
      inputObjectCount: input.objects.length,
      deduplicatedObjectCount: dedupe.removed.length,
      acceptedObjectCount: acceptedCount,
      rejectedObjectCount: rejectedCount,
      candidateCount,
      exploredStateCount: exploredStates,
      repairCount,
      warnings: roomBuild.warnings,
    },
  };
}
