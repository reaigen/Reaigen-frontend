import type {
  KeepOutZone,
  LayoutPriors,
  RoomObservation,
  ValidationIssue,
  ValidationReport,
  WallSegment,
} from "../types.js";
import { obbIntersectionArea } from "../geometry/obb.js";
import { candidatesConflict, pairOverlapAllowed, validatePoseAgainstArchitecture } from "./constraints.js";
import { analyzeNavigation } from "./navigation.js";
import type { SelectedPlacement } from "./relations.js";

function architectureIssue(
  objectId: string,
  roomId: string | null,
  reason: string,
): ValidationIssue {
  const lower = reason.toLowerCase();
  if (lower.includes("no room") || lower.includes("unknown room")) {
    return { code: "NO_ROOM", severity: "error", objectIds: [objectId], roomId: roomId ?? undefined, message: reason };
  }
  if (lower.includes("outside") || lower.includes("room polygon")) {
    return { code: "OUTSIDE_ROOM", severity: "error", objectIds: [objectId], roomId: roomId ?? undefined, message: reason };
  }
  if (lower.includes("wall")) {
    return { code: "WALL_COLLISION", severity: "error", objectIds: [objectId], roomId: roomId ?? undefined, message: reason };
  }
  if (lower.includes("window")) {
    return { code: "WINDOW_BLOCKED", severity: "error", objectIds: [objectId], roomId: roomId ?? undefined, message: reason };
  }
  return { code: "OPENING_BLOCKED", severity: "error", objectIds: [objectId], roomId: roomId ?? undefined, message: reason };
}

export function validateSelections(
  rooms: RoomObservation[],
  walls: WallSegment[],
  keepOuts: KeepOutZone[],
  selections: Map<string, SelectedPlacement>,
  priors: LayoutPriors,
): ValidationReport {
  const issues: ValidationIssue[] = [];
  const roomsById = new Map(rooms.map((room) => [room.id, room]));
  const context = { roomsById, walls, keepOuts, priors };
  const accepted = [...selections.values()].filter((entry) => entry.candidate.pose);

  if (!rooms.length) {
    issues.push({ code: "INVALID_GEOMETRY", severity: "error", message: "No valid room polygon is available." });
  }

  for (const entry of accepted) {
    const pose = entry.candidate.pose!;
    const reasons = validatePoseAgainstArchitecture(entry.object, pose, entry.candidate.roomId, context);
    for (const reason of reasons) issues.push(architectureIssue(entry.object.id, entry.candidate.roomId, reason));
  }

  for (let i = 0; i < accepted.length; i++) {
    const a = accepted[i];
    if (!a) continue;
    for (let j = i + 1; j < accepted.length; j++) {
      const b = accepted[j];
      if (!b || !a.candidate.pose || !b.candidate.pose) continue;
      if (a.candidate.roomId && b.candidate.roomId && a.candidate.roomId !== b.candidate.roomId) continue;
      if (pairOverlapAllowed(a.object, a.candidate, b.object, b.candidate, priors)) continue;
      const overlap = obbIntersectionArea(a.candidate.pose, b.candidate.pose, 0);
      if (overlap > 0.0004) {
        const storage = a.object.kind === "storage" && b.object.kind === "storage";
        issues.push({
          code: storage ? "STORAGE_OVERLAP" : "OBJECT_OVERLAP",
          severity: "error",
          objectIds: [a.object.id, b.object.id],
          roomId: a.candidate.roomId ?? b.candidate.roomId ?? undefined,
          metric: overlap,
          message: storage
            ? `Storage footprints ${a.object.id} and ${b.object.id} overlap by ${overlap.toFixed(3)} m².`
            : `Furniture footprints ${a.object.id} and ${b.object.id} overlap by ${overlap.toFixed(3)} m².`,
        });
      } else if (candidatesConflict(a.object, a.candidate, b.object, b.candidate, priors)) {
        issues.push({
          code: "OBJECT_OVERLAP",
          severity: "error",
          objectIds: [a.object.id, b.object.id],
          roomId: a.candidate.roomId ?? b.candidate.roomId ?? undefined,
          message: `Furniture ${a.object.id} occupies the required operational clearance of ${b.object.id}, or vice versa.`,
        });
      }
    }
  }

  const navigation = analyzeNavigation(rooms, selections, keepOuts, priors);
  for (const issue of navigation.issues) {
    issues.push(issue.code === "DOOR_APPROACH_UNREACHABLE" ? { ...issue, severity: "error" } : issue);
  }

  return {
    valid: issues.every((issue) => issue.severity !== "error"),
    issues,
    navigation: navigation.metrics,
  };
}
