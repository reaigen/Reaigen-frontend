import type { FurnitureObservation, FurniturePose, LayoutPriors, Vec2 } from "../types.js";
import { normalizePose } from "../geometry/obb.js";
import { clamp, cross, normalize, scale } from "../geometry/vector.js";

export interface ConditionedObject {
  object: FurnitureObservation;
  sourcePose: FurniturePose;
  reasons: string[];
}

function copyPose(object: FurnitureObservation): FurniturePose {
  return {
    center: [object.center[0], object.center[1]],
    axisW: [object.axisW[0], object.axisW[1]],
    axisD: [object.axisD[0], object.axisD[1]],
    halfW: object.halfW,
    halfD: object.halfD,
  };
}

function semanticAxes(
  object: FurnitureObservation,
  preference: "width-long" | "depth-long" | "preserve",
): FurnitureObservation {
  if (preference === "preserve") return object;
  const widthIsLong = object.halfW >= object.halfD;
  const shouldSwap = preference === "width-long" ? !widthIsLong : widthIsLong;
  if (!shouldSwap) return object;

  // Exchange the footprint axes and extents without changing the physical OBB.
  // Preserve handedness so +axisD keeps a consistent semantic "front" side.
  const handedness = cross(object.axisW, object.axisD) >= 0 ? 1 : -1;
  const newW: Vec2 = [object.axisD[0], object.axisD[1]];
  const newD: Vec2 = handedness >= 0
    ? [-object.axisW[0], -object.axisW[1]]
    : [object.axisW[0], object.axisW[1]];
  return {
    ...object,
    axisW: normalize(newW),
    axisD: normalize(newD),
    halfW: object.halfD,
    halfD: object.halfW,
  };
}

function clampDimension(value: number, minValue: number | undefined, maxValue: number | undefined): number {
  const low = minValue == null ? 0.04 : minValue;
  const high = maxValue == null ? Number.POSITIVE_INFINITY : maxValue;
  return clamp(value, low, high);
}

/**
 * Normalize RoomPlan axes, establish category-specific width/depth semantics,
 * and clamp only physically implausible outliers. The original pose is kept in
 * the returned record so the solver can report exactly what it changed.
 */
export function conditionObject(object: FurnitureObservation, priors: LayoutPriors): ConditionedObject {
  const sourcePose = copyPose(object);
  const prior = priors.kinds[object.kind];
  let conditioned = normalizePose({ ...object });
  const reasons: string[] = [];

  const beforeSemantic = conditioned;
  conditioned = semanticAxes(conditioned, prior.widthDepthPreference);
  if (
    beforeSemantic.halfW !== conditioned.halfW
    || beforeSemantic.axisW[0] !== conditioned.axisW[0]
    || beforeSemantic.axisW[1] !== conditioned.axisW[1]
  ) {
    reasons.push(`Normalized ${object.kind} width/depth semantics without changing its measured footprint.`);
  }

  const width = conditioned.halfW * 2;
  const depth = conditioned.halfD * 2;
  const clampedWidth = clampDimension(width, prior.minWidth, prior.maxWidth);
  const clampedDepth = clampDimension(depth, prior.minDepth, prior.maxDepth);
  if (Math.abs(clampedWidth - width) > 1e-6 || Math.abs(clampedDepth - depth) > 1e-6) {
    conditioned = {
      ...conditioned,
      halfW: clampedWidth / 2,
      halfD: clampedDepth / 2,
    };
    reasons.push(
      `Clamped implausible footprint from ${width.toFixed(2)}×${depth.toFixed(2)} m to ${clampedWidth.toFixed(2)}×${clampedDepth.toFixed(2)} m.`,
    );
  }

  if (conditioned.height != null) {
    const height = clampDimension(conditioned.height, prior.minHeight, prior.maxHeight);
    if (Math.abs(height - conditioned.height) > 1e-6) {
      conditioned = { ...conditioned, height };
      reasons.push(`Clamped implausible height to ${height.toFixed(2)} m.`);
    }
  }

  // Guard against nearly mirrored/non-orthogonal matrices after external JSON
  // transforms. normalizePose already orthogonalizes; this final sign keeps the
  // axis pair stable for icon and front-clearance rendering.
  if (cross(conditioned.axisW, conditioned.axisD) < 0) {
    conditioned = { ...conditioned, axisD: scale(conditioned.axisD, -1) };
  }

  return { object: conditioned, sourcePose, reasons };
}

export function conditionObjects(
  objects: FurnitureObservation[],
  priors: LayoutPriors,
): {
  objects: FurnitureObservation[];
  sourcePoses: Map<string, FurniturePose>;
  reasons: Map<string, string[]>;
} {
  const sourcePoses = new Map<string, FurniturePose>();
  const reasons = new Map<string, string[]>();
  const conditioned = objects.map((object) => {
    const result = conditionObject(object, priors);
    sourcePoses.set(object.id, result.sourcePose);
    if (result.reasons.length) reasons.set(object.id, result.reasons);
    return result.object;
  });
  return { objects: conditioned, sourcePoses, reasons };
}
