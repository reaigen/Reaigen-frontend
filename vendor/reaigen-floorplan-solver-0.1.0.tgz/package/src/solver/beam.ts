import type { FurnitureObservation, LayoutPriors, PlacementCandidate } from "../types.js";
import { poseArea } from "../geometry/obb.js";
import { candidatesConflict } from "./constraints.js";
import { pairwisePlacementCost, type SelectedPlacement } from "./relations.js";

export interface CandidateGroup {
  object: FurnitureObservation;
  candidates: PlacementCandidate[];
}

export interface BeamState {
  score: number;
  selections: SelectedPlacement[];
  signature: string;
}

export interface BeamSolveResult {
  selections: Map<string, SelectedPlacement>;
  score: number;
  exploredStates: number;
}

function objectPriority(object: FurnitureObservation, priors: LayoutPriors): number {
  const prior = priors.kinds[object.kind];
  const placementRank = prior.placement === "fixture" ? 4 : prior.placement === "wall-required" ? 3 : prior.placement === "wall-preferred" ? 2 : 1;
  const parentBoost = object.parentId ? -0.5 : 0;
  return placementRank * 100 + Math.min(prior.dropPenalty, 40) * 2 + Math.min(poseArea(object), 12) + parentBoost;
}

function selectionMap(selections: SelectedPlacement[]): Map<string, SelectedPlacement> {
  return new Map(selections.map((entry) => [entry.object.id, entry]));
}

function compareStates(a: BeamState, b: BeamState): number {
  return a.score - b.score || a.signature.localeCompare(b.signature);
}

function stateKey(selections: SelectedPlacement[]): string {
  return selections.map((entry) => `${entry.object.id}=${entry.candidate.id}`).join("|");
}

function candidateCompatible(
  object: FurnitureObservation,
  candidate: PlacementCandidate,
  selected: SelectedPlacement[],
  priors: LayoutPriors,
): { valid: boolean; pairCost: number } {
  if (candidate.anchorObjectId) {
    const anchor = selected.find((entry) => entry.object.id === candidate.anchorObjectId);
    if (!anchor?.candidate.pose) return { valid: false, pairCost: 0 };
    if (candidate.anchorCandidateId && anchor.candidate.id !== candidate.anchorCandidateId) {
      return { valid: false, pairCost: 0 };
    }
  }
  let pairCost = 0;
  for (const entry of selected) {
    if (candidatesConflict(object, candidate, entry.object, entry.candidate, priors)) {
      return { valid: false, pairCost: 0 };
    }
    pairCost += pairwisePlacementCost(object, candidate, entry.object, entry.candidate, priors);
  }
  return { valid: true, pairCost };
}

/**
 * Deterministic bounded-width search over one discrete placement candidate per
 * object. The reject candidate guarantees feasibility; hard geometry conflicts
 * are never converted into soft penalties.
 */
export function solveCandidateGroups(
  groups: CandidateGroup[],
  priors: LayoutPriors,
  fixed: SelectedPlacement[] = [],
): BeamSolveResult {
  const ordered = [...groups].sort((a, b) => {
    const priority = objectPriority(b.object, priors) - objectPriority(a.object, priors);
    if (priority) return priority;
    const count = a.candidates.length - b.candidates.length;
    if (count) return count;
    return a.object.id.localeCompare(b.object.id);
  });
  const fixedScore = fixed.reduce((sum, entry) => sum + entry.candidate.baseCost, 0);
  let beam: BeamState[] = [{ score: fixedScore, selections: [...fixed], signature: stateKey(fixed) }];
  let exploredStates = 1;

  for (const group of ordered) {
    const next: BeamState[] = [];
    const candidates = [...group.candidates].sort((a, b) => a.baseCost - b.baseCost || a.id.localeCompare(b.id));
    for (const state of beam) {
      for (const candidate of candidates) {
        const compatible = candidateCompatible(group.object, candidate, state.selections, priors);
        exploredStates += 1;
        if (!compatible.valid) continue;
        const selections = [...state.selections, { object: group.object, candidate }];
        next.push({
          score: state.score + candidate.baseCost + compatible.pairCost,
          selections,
          signature: stateKey(selections),
        });
      }
    }

    if (!next.length) {
      // This should be unreachable because every group has a reject candidate,
      // but fail closed and preserve the prior beam if malformed input removed it.
      continue;
    }

    next.sort(compareStates);
    const deduped: BeamState[] = [];
    const seen = new Set<string>();
    for (const state of next) {
      if (seen.has(state.signature)) continue;
      seen.add(state.signature);
      deduped.push(state);
      if (deduped.length >= priors.beamWidth) break;
    }
    beam = deduped;
  }

  const best = [...beam].sort(compareStates)[0] ?? { score: fixedScore, selections: fixed, signature: stateKey(fixed) };
  return { selections: selectionMap(best.selections), score: best.score, exploredStates };
}
