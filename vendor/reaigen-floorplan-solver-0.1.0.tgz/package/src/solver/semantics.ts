import type { FurnitureObservation, LayoutPriors } from "../types.js";
import { distance } from "../geometry/vector.js";

export type TableRole = "dining" | "satellite" | "occasional";

function normalizedAttributes(object: FurnitureObservation): string {
  return [object.category, ...(object.attributes ?? [])].join(" ").toLowerCase();
}

/**
 * RoomPlan collapses dining, coffee, side and work tables into one category.
 * Recover only the distinction needed by the layout solver. Explicit capture
 * attributes and parent relations win; conservative footprint thresholds are
 * the fallback when the source has already discarded the subtype.
 */
export function classifyTableRole(
  table: FurnitureObservation,
  objects: FurnitureObservation[],
  priors: LayoutPriors,
): TableRole {
  const attributes = normalizedAttributes(table);
  if (/coffee|side[ -]?table|night[ -]?stand|end[ -]?table/.test(attributes)) return "satellite";
  if (/dining|conference/.test(attributes)) return "dining";

  const longSide = 2 * Math.max(table.halfW, table.halfD);
  const area = 4 * table.halfW * table.halfD;
  const relatedChair = objects.some((object) => {
    if (object.kind !== "chair") return false;
    if (object.parentId === table.id) return true;
    if (object.roomId && table.roomId && object.roomId !== table.roomId) return false;
    return distance(object.center, table.center) <= priors.semantic.chairTableAssociationMax;
  });
  if (
    relatedChair
    && longSide >= priors.semantic.diningTableMinLong
    && area >= priors.semantic.diningTableMinArea
  ) return "dining";
  if (
    longSide <= priors.semantic.satelliteTableMaxLong
    && area <= priors.semantic.satelliteTableMaxArea
  ) return "satellite";
  return "occasional";
}

/** Return one unambiguous dining anchor. An explicit RoomPlan parent wins. */
export function associatedDiningTable(
  chair: FurnitureObservation,
  tables: FurnitureObservation[],
  objects: FurnitureObservation[],
  priors: LayoutPriors,
): FurnitureObservation | null {
  const parent = chair.parentId ? tables.find((table) => table.id === chair.parentId) : undefined;
  if (parent) return parent;
  const ranked = tables
    .filter((table) => classifyTableRole(table, objects, priors) === "dining")
    .filter((table) => !chair.roomId || !table.roomId || chair.roomId === table.roomId)
    .map((table) => ({ table, distance: distance(chair.center, table.center) }))
    .filter((entry) => entry.distance <= priors.semantic.chairTableAssociationMax)
    .sort((a, b) => a.distance - b.distance || a.table.id.localeCompare(b.table.id));
  if (!ranked.length) return null;
  if (
    ranked.length > 1
    && ranked[1]!.distance - ranked[0]!.distance < priors.semantic.chairTableAmbiguityMargin
  ) return null;
  return ranked[0]!.table;
}
