import type { FurnitureObservation, LayoutPriors, RoomObservation, SolverInput, Vec2, WallSegment } from "../types.js";
import { extractWallFaces } from "../geometry/planar-graph.js";
import { convexSimpleIntersectionArea, ensureCCW, pointInPolygon, polygonArea, polygonCentroid } from "../geometry/polygon.js";
import { obbCorners, poseArea } from "../geometry/obb.js";
import { distance } from "../geometry/vector.js";

export interface RoomBuildResult {
  rooms: RoomObservation[];
  source: "provided" | "wall-faces" | "fallback-hull" | "none";
  warnings: string[];
}

function validProvidedRooms(rooms: RoomObservation[] | undefined, minArea: number): RoomObservation[] {
  return (rooms ?? [])
    .filter((room) => room.polygon.length >= 3 && polygonArea(room.polygon) >= minArea)
    .map((room) => ({ ...room, polygon: ensureCCW(room.polygon), type: room.type ?? "unknown" }));
}

export function buildRooms(input: SolverInput, priors: LayoutPriors): RoomBuildResult {
  const provided = validProvidedRooms(input.rooms, priors.minRoomArea);
  if (provided.length) return { rooms: provided, source: "provided", warnings: [] };

  // Openings are holes in the rendered wall, not holes in room topology.
  // Temporarily seal measured door/window/opening spans for polygonization;
  // the original wall set and exact opening keep-outs remain authoritative for
  // collision detection and presentation.
  const topologyWalls: WallSegment[] = [
    ...input.walls,
    ...(input.openings ?? [])
      .filter((opening) => distance(opening.p1, opening.p2) >= 0.2)
      .map((opening) => ({
        id: `topology-opening:${opening.id}`,
        p1: opening.p1,
        p2: opening.p2,
      })),
  ];
  const extracted = extractWallFaces(topologyWalls, { minArea: priors.minRoomArea, weldEpsilon: 0.025 });
  if (extracted.faces.length) {
    const rooms = extracted.faces.map((polygon, index) => ({
      id: `inferred-room-${index + 1}`,
      polygon,
      type: "unknown" as const,
      source: "wall-face" as const,
      confidence: 0.82,
    }));
    return { rooms, source: "wall-faces", warnings: [] };
  }
  if (extracted.fallbackHull) {
    return {
      rooms: [{
        id: "fallback-room-1",
        polygon: extracted.fallbackHull,
        type: "unknown",
        source: "fallback-hull",
        confidence: 0.35,
      }],
      source: "fallback-hull",
      warnings: ["Partial topology: convex hull is containment-only; inferred edges cannot support placement."],
    };
  }
  return { rooms: [], source: "none", warnings: ["No valid room polygon could be reconstructed from the input."] };
}

export interface RoomAssignment {
  objectId: string;
  roomId: string | null;
  containment: number;
  source: "explicit" | "intersection" | "nearest" | "unassigned";
}

export function assignObjectToRoom(
  object: FurnitureObservation,
  rooms: RoomObservation[],
  minContainment: number,
): RoomAssignment {
  if (object.roomId && rooms.some((room) => room.id === object.roomId)) {
    return { objectId: object.id, roomId: object.roomId, containment: 1, source: "explicit" };
  }
  if (object.sourceRoomId && rooms.some((room) => room.id === object.sourceRoomId)) {
    return { objectId: object.id, roomId: object.sourceRoomId, containment: 1, source: "explicit" };
  }
  const footprint = obbCorners(object);
  const area = Math.max(poseArea(object), 1e-8);
  let best: RoomObservation | undefined;
  let bestContainment = 0;
  for (const room of rooms) {
    const intersection = convexSimpleIntersectionArea(footprint, room.polygon);
    const ratio = intersection / area;
    if (ratio > bestContainment) {
      bestContainment = ratio;
      best = room;
    }
  }
  if (best && bestContainment >= minContainment) {
    return { objectId: object.id, roomId: best.id, containment: bestContainment, source: "intersection" };
  }

  // A centroid can fall just outside a noisy floor polygon while still being
  // close to the correct room. This fallback is deliberately bounded.
  let nearest: RoomObservation | undefined;
  let nearestDistance = Number.POSITIVE_INFINITY;
  for (const room of rooms) {
    if (pointInPolygon(object.center, room.polygon, true)) {
      return { objectId: object.id, roomId: room.id, containment: bestContainment, source: "intersection" };
    }
    const d = distance(object.center, polygonCentroid(room.polygon));
    if (d < nearestDistance) {
      nearestDistance = d;
      nearest = room;
    }
  }
  if (nearest && nearestDistance <= 1.2 && bestContainment > 0.15) {
    return { objectId: object.id, roomId: nearest.id, containment: bestContainment, source: "nearest" };
  }
  return { objectId: object.id, roomId: null, containment: bestContainment, source: "unassigned" };
}

export function assignWallsToRooms(walls: WallSegment[], rooms: RoomObservation[]): WallSegment[] {
  return walls.map((wall) => {
    const mid: Vec2 = [(wall.p1[0] + wall.p2[0]) / 2, (wall.p1[1] + wall.p2[1]) / 2];
    const ids = rooms
      .map((room) => ({ room, d: distance(mid, polygonCentroid(room.polygon)) }))
      .filter(({ room }) => {
        // Midpoint need not be inside because walls lie on the boundary. Test
        // tiny offsets in both normal directions.
        const dx = wall.p2[0] - wall.p1[0];
        const dz = wall.p2[1] - wall.p1[1];
        const len = Math.max(Math.hypot(dx, dz), 1e-6);
        const nx = -dz / len;
        const nz = dx / len;
        return pointInPolygon([mid[0] + nx * 0.08, mid[1] + nz * 0.08], room.polygon, true)
          || pointInPolygon([mid[0] - nx * 0.08, mid[1] - nz * 0.08], room.polygon, true);
      })
      .sort((a, b) => a.d - b.d)
      .slice(0, 2)
      .map(({ room }) => room.id);
    return { ...wall, roomIds: ids };
  });
}
