import type { FurnitureObservation, RoomObservation, RoomType } from "../types.js";
import { polygonArea } from "../geometry/polygon.js";

const ROOM_TYPES: RoomType[] = [
  "bathroom",
  "kitchen",
  "bedroom",
  "livingRoom",
  "diningRoom",
  "office",
  "laundry",
  "storage",
  "hallway",
];

/**
 * Infer only missing RoomPlan section labels. Strong fixtures dominate; weak
 * movable evidence never overwrites an explicit Apple/manual room type.
 */
export function inferUnknownRoomTypes(
  rooms: RoomObservation[],
  objects: FurnitureObservation[],
): RoomObservation[] {
  const byRoom = new Map<string, FurnitureObservation[]>();
  for (const object of objects) {
    if (!object.roomId) continue;
    const list = byRoom.get(object.roomId) ?? [];
    list.push(object);
    byRoom.set(object.roomId, list);
  }

  return rooms.map((room) => {
    if (room.type && room.type !== "unknown") return room;
    const list = byRoom.get(room.id) ?? [];
    const count = (kind: FurnitureObservation["kind"]) => list.filter((object) => object.kind === kind).length;
    const scores: Partial<Record<RoomType, number>> = {};
    const add = (type: RoomType, value: number) => { scores[type] = (scores[type] ?? 0) + value; };

    add("bathroom", count("toilet") * 12 + count("bathtub") * 10 + count("sink") * 2.5 + count("washerDryer") * 1.5);
    add("kitchen", count("stove") * 11 + count("oven") * 8 + count("dishwasher") * 9 + count("refrigerator") * 8 + count("sink") * 3 + count("storage") * 0.5);
    add("bedroom", count("bed") * 12 + count("storage") * 0.8 + count("table") * 0.4);
    add("livingRoom", count("sofa") * 9 + count("television") * 6 + count("fireplace") * 5 + count("table") * 0.4);
    add("diningRoom", count("table") * 3 + count("chair") * 1.2);
    add("office", count("table") * 1.5 + count("chair") * 1.2 + count("television") * 0.3);
    add("laundry", count("washerDryer") * 9 + count("storage") * 0.5 + count("sink") * 1.5);
    add("storage", count("storage") * 2.2);

    const area = polygonArea(room.polygon);
    if (!list.length && area < 8) add("hallway", 1.5);
    if (!list.length && area < 3) add("storage", 1);

    let best: RoomType = "unknown";
    let bestScore = 0;
    for (const type of ROOM_TYPES) {
      const score = scores[type] ?? 0;
      if (score > bestScore) {
        best = type;
        bestScore = score;
      }
    }
    if (bestScore < 2.5) return room;
    return { ...room, type: best, label: room.label ?? best, confidence: Math.min(room.confidence ?? 0.75, 0.82) };
  });
}
