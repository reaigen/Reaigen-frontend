import type {
  FurnitureKind,
  KeepOutZone,
  LayoutPriors,
  OpeningObservation,
  RoomObservation,
  Vec2,
} from "../types.js";
import {
  oneSidedRectangle,
  pointInPolygon,
  rectangleAroundSegment,
  sectorPolygon,
} from "../geometry/polygon.js";
import { add, distance, leftNormal, midpoint, normalize, scale, sub } from "../geometry/vector.js";

interface OpeningSide {
  roomId: string;
  inward: Vec2;
  sign: 1 | -1;
}

function openingSides(opening: OpeningObservation, rooms: RoomObservation[]): OpeningSide[] {
  const direction = normalize(sub(opening.p2, opening.p1));
  const normal = leftNormal(direction);
  const mid = midpoint(opening.p1, opening.p2);
  const sides: OpeningSide[] = [];
  for (const room of rooms) {
    const plus = add(mid, scale(normal, 0.12));
    const minus = add(mid, scale(normal, -0.12));
    const inPlus = pointInPolygon(plus, room.polygon, true);
    const inMinus = pointInPolygon(minus, room.polygon, true);
    if (inPlus && !inMinus) sides.push({ roomId: room.id, inward: normal, sign: 1 });
    else if (inMinus && !inPlus) sides.push({ roomId: room.id, inward: scale(normal, -1), sign: -1 });
    else if (inPlus && inMinus) {
      // The opening lies on an internal line inside a large fallback room.
      // Keep both sides so no object can block the threshold.
      sides.push({ roomId: room.id, inward: normal, sign: 1 });
      sides.push({ roomId: room.id, inward: scale(normal, -1), sign: -1 });
    }
  }
  // Deduplicate room/side pairs.
  const seen = new Set<string>();
  return sides.filter((side) => {
    const key = `${side.roomId}:${side.sign}`;
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });
}

export function annotateOpeningRooms(
  openings: OpeningObservation[],
  rooms: RoomObservation[],
): OpeningObservation[] {
  return openings.map((opening) => ({
    ...opening,
    roomIds: [...new Set(openingSides(opening, rooms).map((side) => side.roomId))],
  }));
}

function configuredSwingSides(opening: OpeningObservation, sides: OpeningSide[]): OpeningSide[] {
  const cfg = opening.configuration;
  const direction = String(cfg?.swingDirection ?? "Unknown").toLowerCase();
  const primary = cfg?.primaryRoomId;
  if (!primary || (direction !== "in" && direction !== "out")) return sides;
  if (direction === "in") {
    const selected = sides.filter((side) => side.roomId === primary);
    return selected.length ? selected : sides;
  }
  const selected = sides.filter((side) => side.roomId !== primary);
  return selected.length ? selected : sides;
}

function hingeChoices(opening: OpeningObservation): Array<{ hinge: Vec2; other: Vec2; label: string }> {
  const hinge = String(opening.configuration?.hingeSide ?? "Unknown").toLowerCase();
  if (hinge === "left") return [{ hinge: opening.p1, other: opening.p2, label: "left" }];
  if (hinge === "right") return [{ hinge: opening.p2, other: opening.p1, label: "right" }];
  return [
    { hinge: opening.p1, other: opening.p2, label: "left-unknown" },
    { hinge: opening.p2, other: opening.p1, label: "right-unknown" },
  ];
}

const TALL_KINDS: FurnitureKind[] = [
  "storage",
  "refrigerator",
  "washerDryer",
  "television",
  "stairs",
  "generic",
];

export function buildKeepOutZones(
  openings: OpeningObservation[],
  rooms: RoomObservation[],
  priors: LayoutPriors,
): KeepOutZone[] {
  const zones: KeepOutZone[] = [];
  for (const opening of openings) {
    const length = Math.max(distance(opening.p1, opening.p2), 0.4);
    const sides = openingSides(opening, rooms);

    if (opening.kind === "door" || opening.kind === "opening") {
      zones.push({
        id: `${opening.id}:threshold`,
        kind: "door-threshold",
        polygon: rectangleAroundSegment(
          opening.p1,
          opening.p2,
          priors.openingThresholdDepth / 2,
          priors.doorSideClearance,
        ),
        openingId: opening.id,
        reason: "Architectural opening threshold must remain clear.",
      });
      for (const side of sides) {
        zones.push({
          id: `${opening.id}:approach:${side.roomId}:${side.sign}`,
          kind: opening.kind === "door" ? "door-approach" : "opening-approach",
          polygon: oneSidedRectangle(
            opening.p1,
            opening.p2,
            side.inward,
            priors.doorApproachDepth,
            priors.doorSideClearance,
          ),
          roomId: side.roomId,
          openingId: opening.id,
          reason: "Doorway approach and circulation area must remain clear.",
        });
      }
    }

    if (opening.kind === "door") {
      const doorType = String(opening.configuration?.doorType ?? "Unknown").toLowerCase();
      if (doorType === "moving") {
        const direction = normalize(sub(opening.p2, opening.p1));
        const extendedP1 = add(opening.p1, scale(direction, -length));
        const extendedP2 = add(opening.p2, scale(direction, length));
        for (const side of sides) {
          zones.push({
            id: `${opening.id}:slide:${side.roomId}:${side.sign}`,
            kind: "sliding-door-travel",
            polygon: oneSidedRectangle(
              extendedP1,
              extendedP2,
              side.inward,
              priors.openingThresholdDepth,
              0.04,
            ),
            roomId: side.roomId,
            openingId: opening.id,
            reason: "Sliding door leaf and track travel must remain unobstructed.",
          });
        }
      } else {
        const swingSides = configuredSwingSides(opening, sides);
        for (const side of swingSides) {
          for (const choice of hingeChoices(opening)) {
            const closedVector = sub(choice.other, choice.hinge);
            const openVector = scale(side.inward, length);
            zones.push({
              id: `${opening.id}:swing:${side.roomId}:${side.sign}:${choice.label}`,
              kind: "door-swing",
              polygon: sectorPolygon(choice.hinge, closedVector, openVector, length + 0.06, 14),
              roomId: side.roomId,
              openingId: opening.id,
              reason: "Swinging door swept area must remain clear.",
            });
          }
        }
      }
    }

    if (opening.kind === "window") {
      for (const side of sides) {
        zones.push({
          id: `${opening.id}:window-tall:${side.roomId}:${side.sign}`,
          kind: "window-tall-object",
          polygon: oneSidedRectangle(
            opening.p1,
            opening.p2,
            side.inward,
            priors.windowTallClearanceDepth,
            priors.windowTallSideClearance,
          ),
          roomId: side.roomId,
          openingId: opening.id,
          appliesToKinds: TALL_KINDS,
          reason: "Tall furniture must not cover a window opening.",
        });
      }
    }
  }
  return zones;
}

export function keepOutApplies(zone: KeepOutZone, kind: FurnitureKind, height?: number): boolean {
  if (zone.kind === "window-tall-object") {
    if (typeof height === "number" && height > 0) return height >= 1.05;
    return zone.appliesToKinds?.includes(kind) ?? false;
  }
  return !zone.appliesToKinds?.length || zone.appliesToKinds.includes(kind);
}
