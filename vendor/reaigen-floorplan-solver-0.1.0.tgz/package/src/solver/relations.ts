import type {
  FurnitureObservation,
  FurniturePose,
  LayoutPriors,
  PlacementCandidate,
  RoomObservation,
  Vec2,
} from "../types.js";
import { obbContainmentRatio, obbCorners, poseDisplacement } from "../geometry/obb.js";
import { convexSimpleIntersectionArea } from "../geometry/polygon.js";
import { add, clamp, distance, dot, leftNormal, normalize, scale, sub } from "../geometry/vector.js";
import { makeCandidate, type CandidateBuildContext } from "./candidates.js";
import { associatedDiningTable, classifyTableRole } from "./semantics.js";

export interface SelectedPlacement {
  object: FurnitureObservation;
  candidate: PlacementCandidate;
}

const PARENT_CONTAINED_KINDS = new Set([
  "dishwasher",
  "oven",
  "stove",
  "sink",
  "television",
] as const);

function selectedPose(entry: SelectedPlacement | undefined): FurniturePose | null {
  return entry?.candidate.pose ?? null;
}

function relationCostForFacing(
  aPose: FurniturePose,
  bPose: FurniturePose,
  preferredDistance: number,
): number {
  const delta = sub(bPose.center, aPose.center);
  const d = Math.max(distance(aPose.center, bPose.center), 1e-6);
  const direction = scale(delta, 1 / d);
  const aFacing = clamp(dot(aPose.axisD, direction), -1, 1);
  const bFacing = clamp(dot(bPose.axisD, scale(direction, -1)), -1, 1);
  return 0.35 * ((d - preferredDistance) / Math.max(preferredDistance, 0.5)) ** 2
    + 0.8 * (1 - aFacing)
    + 0.8 * (1 - bFacing);
}

/** Pairwise semantic cost used after hard geometry has passed. */
export function pairwisePlacementCost(
  aObject: FurnitureObservation,
  aCandidate: PlacementCandidate,
  bObject: FurnitureObservation,
  bCandidate: PlacementCandidate,
  priors: LayoutPriors,
): number {
  if (!aCandidate.pose || !bCandidate.pose) return 0;
  if (aCandidate.roomId && bCandidate.roomId && aCandidate.roomId !== bCandidate.roomId) return 0;

  let cost = 0;
  for (const prior of priors.pairs) {
    const direct = aObject.kind === prior.a && bObject.kind === prior.b;
    const reverse = aObject.kind === prior.b && bObject.kind === prior.a;
    if (!direct && !reverse) continue;
    const aPose = direct ? aCandidate.pose : bCandidate.pose;
    const bPose = direct ? bCandidate.pose : aCandidate.pose;
    const aObj = direct ? aObject : bObject;
    const bObj = direct ? bObject : aObject;
    const d = distance(aPose.center, bPose.center);

    if (prior.relation === "faces") {
      if (prior.maxDistance != null && d > prior.maxDistance) continue;
      cost += relationCostForFacing(aPose, bPose, prior.preferredDistance ?? d);
    } else if (prior.relation === "seat") {
      if (aCandidate.anchorObjectId === bObj.id || bCandidate.anchorObjectId === aObj.id) {
        cost -= priors.semantic.anchoredSeatReward;
      } else if (prior.maxDistance != null && d <= prior.maxDistance) {
        cost += 0.15 * Math.abs(d - (prior.preferredDistance ?? d));
      }
    } else if (prior.relation === "satellite") {
      if (aCandidate.anchorObjectId === bObj.id || bCandidate.anchorObjectId === aObj.id) cost -= 0.15;
    } else if (prior.relation === "containment") {
      const area = convexSimpleIntersectionArea(obbCorners(aPose), obbCorners(bPose));
      if ((aObj.parentId === bObj.id || bObj.parentId === aObj.id) && area <= 1e-6) cost += 0.8;
    }
  }

  // A contiguous cabinet run reads as one deliberate architectural line.
  if (aObject.kind === "storage" && bObject.kind === "storage" && aCandidate.wallId && aCandidate.wallId === bCandidate.wallId) {
    const d = distance(aCandidate.pose.center, bCandidate.pose.center);
    const expected = aCandidate.pose.halfW + bCandidate.pose.halfW;
    const gap = Math.max(0, d - expected);
    cost += Math.min(gap, 1) * 0.08;
  }
  return cost;
}

function candidatePoseClone(object: FurnitureObservation): FurniturePose {
  return {
    center: [object.center[0], object.center[1]],
    axisW: [object.axisW[0], object.axisW[1]],
    axisD: [object.axisD[0], object.axisD[1]],
    halfW: object.halfW,
    halfD: object.halfD,
  };
}

function seatCandidates(
  chair: FurnitureObservation,
  room: RoomObservation,
  selected: Map<string, SelectedPlacement>,
  context: CandidateBuildContext,
): PlacementCandidate[] {
  const tables = [...selected.values()].filter((entry) => entry.object.kind === "table" && entry.candidate.roomId === room.id && entry.candidate.pose);
  if (!tables.length) return [];
  const anchorObject = associatedDiningTable(
    chair,
    tables.map((entry) => entry.object),
    context.objects,
    context.priors,
  );
  const anchors = anchorObject
    ? tables.filter((entry) => entry.object.id === anchorObject.id)
    : [];
  const candidates: PlacementCandidate[] = [];
  let index = 0;
  for (const anchor of anchors) {
    const table = anchor.candidate.pose!;
    const sides: Array<{ normal: Vec2; along: Vec2; edgeHalf: number; alongHalf: number }> = [
      { normal: table.axisW, along: table.axisD, edgeHalf: table.halfW, alongHalf: table.halfD },
      { normal: scale(table.axisW, -1), along: table.axisD, edgeHalf: table.halfW, alongHalf: table.halfD },
      { normal: table.axisD, along: table.axisW, edgeHalf: table.halfD, alongHalf: table.halfW },
      { normal: scale(table.axisD, -1), along: table.axisW, edgeHalf: table.halfD, alongHalf: table.halfW },
    ];
    for (const side of sides) {
      const offset = sub(chair.center, table.center);
      const rawAlong = dot(offset, side.along);
      const maxAlong = Math.max(0, side.alongHalf - chair.halfW * 0.7);
      const centered = Math.abs(rawAlong) < 0.28 ? 0 : clamp(rawAlong, -maxAlong, maxAlong);
      const alongValues = [centered, 0];
      if (side.alongHalf > chair.halfW * 2.2) {
        alongValues.push(clamp(-side.alongHalf * 0.45, -maxAlong, maxAlong));
        alongValues.push(clamp(side.alongHalf * 0.45, -maxAlong, maxAlong));
      }
      for (const alongValue of alongValues) {
        const outward = side.normal;
        const face = scale(outward, -1);
        const pose: FurniturePose = {
          ...candidatePoseClone(chair),
          center: add(
            add(table.center, scale(outward, side.edgeHalf + chair.halfD - context.priors.semantic.seatInset)),
            scale(side.along, alongValue),
          ),
          axisD: face,
          axisW: leftNormal(face),
        };
        const candidate = makeCandidate(chair, room, pose, "table-seat", index++, context, {
          anchorObjectId: anchor.object.id,
          anchorCandidateId: anchor.candidate.id,
          reasons: [`Placed chair in a legal table-facing seat slot around ${anchor.object.id}.`],
        });
        // Prefer the measured side and parent relationship without forcing a
        // large jump across the room.
        candidate.baseCost += 0.18 * poseDisplacement(chair, pose);
        candidate.baseCost -= context.priors.semantic.anchoredSeatReward;
        if (chair.parentId === anchor.object.id) candidate.baseCost -= 0.35;
        candidates.push(candidate);
      }
    }
  }
  return candidates;
}

function satelliteTableCandidates(
  table: FurnitureObservation,
  room: RoomObservation,
  selected: Map<string, SelectedPlacement>,
  context: CandidateBuildContext,
): PlacementCandidate[] {
  if (classifyTableRole(table, context.objects, context.priors) !== "satellite") return [];
  const anchors = [...selected.values()]
    .filter((entry) => (entry.object.kind === "sofa" || entry.object.kind === "bed") && entry.candidate.roomId === room.id && entry.candidate.pose)
    .sort((a, b) => distance(table.center, a.candidate.pose!.center) - distance(table.center, b.candidate.pose!.center))
    .slice(0, 3);
  const candidates: PlacementCandidate[] = [];
  let index = 0;
  for (const anchor of anchors) {
    const pose = anchor.candidate.pose!;
    const tableWidth = Math.max(table.halfW, table.halfD);
    const tableDepth = Math.min(table.halfW, table.halfD);
    if (anchor.object.kind === "sofa") {
      const coffee: FurniturePose = {
        center: add(pose.center, scale(pose.axisD, pose.halfD + 0.45 + tableDepth)),
        axisW: [pose.axisW[0], pose.axisW[1]],
        axisD: [pose.axisD[0], pose.axisD[1]],
        halfW: tableWidth,
        halfD: tableDepth,
      };
      candidates.push(makeCandidate(table, room, coffee, "satellite-table", index++, context, {
        anchorObjectId: anchor.object.id,
        anchorCandidateId: anchor.candidate.id,
        reasons: [`Composed a coffee table in front of sofa ${anchor.object.id}.`],
      }));
    }
    for (const sign of [-1, 1] as const) {
      const side = scale(pose.axisW, sign);
      const back = anchor.object.kind === "bed"
        ? scale(pose.axisD, -pose.halfD + tableDepth + 0.04)
        : scale(pose.axisD, -pose.halfD + tableDepth);
      const sidePose: FurniturePose = {
        center: add(add(pose.center, scale(side, pose.halfW + tableWidth + 0.035)), back),
        axisW: [pose.axisW[0], pose.axisW[1]],
        axisD: [pose.axisD[0], pose.axisD[1]],
        halfW: tableWidth,
        halfD: tableDepth,
      };
      candidates.push(makeCandidate(table, room, sidePose, "satellite-table", index++, context, {
        anchorObjectId: anchor.object.id,
        anchorCandidateId: anchor.candidate.id,
        reasons: [`Composed a side table beside ${anchor.object.kind} ${anchor.object.id}.`],
      }));
    }
  }
  return candidates;
}

function tvFacingCandidates(
  television: FurnitureObservation,
  room: RoomObservation,
  selected: Map<string, SelectedPlacement>,
  base: PlacementCandidate[],
  context: CandidateBuildContext,
): PlacementCandidate[] {
  const sofas = [...selected.values()]
    .filter((entry) => entry.object.kind === "sofa" && entry.candidate.roomId === room.id && entry.candidate.pose)
    .sort((a, b) => distance(television.center, a.candidate.pose!.center) - distance(television.center, b.candidate.pose!.center))
    .slice(0, 2);
  const candidates: PlacementCandidate[] = [];
  let index = 0;
  for (const sofa of sofas) {
    for (const candidate of base.filter((value) => value.pose && value.source !== "reject")) {
      const basePose = candidate.pose!;
      const toSofa = normalize(sub(sofa.candidate.pose!.center, basePose.center), basePose.axisD);
      const pose: FurniturePose = {
        ...basePose,
        axisD: toSofa,
        axisW: scale(leftNormal(toSofa), -1),
      };
      const relationCandidate = makeCandidate(television, room, pose, "tv-sofa", index++, context, {
        anchorObjectId: sofa.object.id,
        anchorCandidateId: sofa.candidate.id,
        wallId: candidate.wallId,
        wallParameter: candidate.wallParameter,
        reasons: [`Oriented television toward sofa ${sofa.object.id}.`],
      });
      relationCandidate.baseCost = Math.min(relationCandidate.baseCost, candidate.baseCost + 0.1);
      candidates.push(relationCandidate);
    }
  }
  return candidates;
}

function candidateKey(candidate: PlacementCandidate): string {
  if (!candidate.pose) return "reject";
  return [
    Math.round(candidate.pose.center[0] * 100),
    Math.round(candidate.pose.center[1] * 100),
    Math.round(Math.atan2(candidate.pose.axisW[1], candidate.pose.axisW[0]) * 100),
    candidate.anchorObjectId ?? "",
  ].join(":");
}

export function isDependentObject(object: FurnitureObservation, objects: FurnitureObservation[], priors: LayoutPriors): boolean {
  if (
    object.parentId
    && PARENT_CONTAINED_KINDS.has(object.kind as never)
    && objects.some((other) => other.id === object.parentId)
  ) return true;
  if (object.kind === "chair") {
    return !!associatedDiningTable(object, objects.filter((other) => other.kind === "table"), objects, priors);
  }
  if (object.kind === "television") return objects.some((other) => other.kind === "sofa");
  if (object.kind === "table" && classifyTableRole(object, objects, priors) === "satellite") {
    return objects.some((other) => other.kind === "sofa" || other.kind === "bed");
  }
  return false;
}

export function addRelationCandidates(
  object: FurnitureObservation,
  room: RoomObservation | undefined,
  baseCandidates: PlacementCandidate[],
  selected: Map<string, SelectedPlacement>,
  context: CandidateBuildContext,
): PlacementCandidate[] {
  if (!room) return baseCandidates;
  const rejectCandidates = baseCandidates.filter((candidate) => candidate.source === "reject");
  const explicitParent = object.parentId
    ? context.objects.find((candidate) => candidate.id === object.parentId)
    : undefined;
  if (explicitParent && PARENT_CONTAINED_KINDS.has(object.kind as never)) {
    const parentSelection = selected.get(explicitParent.id);
    if (!parentSelection?.candidate.pose) return rejectCandidates;
    const anchored = baseCandidates
      .filter((candidate) => candidate.source !== "reject" && candidate.pose)
      .filter((candidate) => obbContainmentRatio(candidate.pose!, parentSelection.candidate.pose!) >= 0.45)
      .map((candidate) => ({
        ...candidate,
        anchorObjectId: explicitParent.id,
        anchorCandidateId: parentSelection.candidate.id,
        reasons: [...candidate.reasons, `Retained within explicit RoomPlan parent ${explicitParent.id}.`],
      }));
    return [...anchored, ...rejectCandidates];
  }
  // A fallback hull is only a containment envelope. It cannot support
  // invented TV walls or satellite-table slots; chair-to-table relations are
  // the sole semantic relocation allowed without a reconstructed room face.
  if (room.source === "fallback-hull" && object.kind !== "chair") return baseCandidates;
  let relation: PlacementCandidate[] = [];
  if (object.kind === "chair") relation = seatCandidates(object, room, selected, context);
  else if (object.kind === "table") relation = satelliteTableCandidates(object, room, selected, context);
  else if (object.kind === "television") relation = tvFacingCandidates(object, room, selected, baseCandidates, context);

  const chairMustAnchor = object.kind === "chair"
    && !!associatedDiningTable(
      object,
      context.objects.filter((other) => other.kind === "table"),
      context.objects,
      context.priors,
    );
  const pool = chairMustAnchor ? [...relation, ...rejectCandidates] : [...baseCandidates, ...relation];
  const deduped = new Map<string, PlacementCandidate>();
  for (const candidate of pool) {
    if (!candidate.hardValid && candidate.source !== "reject") continue;
    const key = candidateKey(candidate);
    const existing = deduped.get(key);
    if (!existing || candidate.baseCost < existing.baseCost) deduped.set(key, candidate);
  }
  const all = [...deduped.values()].sort((a, b) => a.baseCost - b.baseCost || a.id.localeCompare(b.id));
  const reject = all.find((candidate) => candidate.source === "reject");
  const accepted = all.filter((candidate) => candidate.source !== "reject").slice(0, Math.max(1, context.priors.maxCandidatesPerObject - 1));
  return reject ? [...accepted, reject] : accepted;
}
