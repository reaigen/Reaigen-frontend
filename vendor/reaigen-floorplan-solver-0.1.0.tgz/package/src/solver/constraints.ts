import type {
  FurnitureObservation,
  FurniturePose,
  KeepOutZone,
  LayoutPriors,
  PlacementCandidate,
  RoomObservation,
  WallSegment,
} from "../types.js";
import {
  convexInsideSimple,
  convexSimpleIntersectionArea,
  rectangleAroundSegment,
} from "../geometry/polygon.js";
import { frontClearancePolygon, obbCorners, obbIntersectionArea, poseArea } from "../geometry/obb.js";
import { isAllowedContainmentPair } from "./dedupe.js";
import { keepOutApplies } from "./keepouts.js";
import { dot, sub } from "../geometry/vector.js";

const HARD_SERVICE_CLEARANCE_KINDS = new Set([
  "storage",
  "refrigerator",
  "washerDryer",
  "dishwasher",
  "oven",
  "stove",
  "sink",
] as const);

const PARENT_CONTAINED_SERVICE_KINDS = new Set([
  "dishwasher",
  "oven",
  "stove",
  "sink",
] as const);

function needsHardServiceClearance(object: FurnitureObservation): boolean {
  // A built-in appliance shares the operational zone of its surviving
  // cabinet parent. Counting the child again creates duplicate phantom
  // clearances that can wrongly delete a nearby dining group.
  if (object.parentId && PARENT_CONTAINED_SERVICE_KINDS.has(object.kind as never)) return false;
  return HARD_SERVICE_CLEARANCE_KINDS.has(object.kind as never);
}

export interface ConstraintContext {
  roomsById: Map<string, RoomObservation>;
  walls: WallSegment[];
  keepOuts: KeepOutZone[];
  priors: LayoutPriors;
}

export function buildConstraintContext(
  rooms: RoomObservation[],
  walls: WallSegment[],
  keepOuts: KeepOutZone[],
  priors: LayoutPriors,
): ConstraintContext {
  return {
    roomsById: new Map(rooms.map((room) => [room.id, room])),
    walls,
    keepOuts,
    priors,
  };
}

export function validatePoseAgainstArchitecture(
  object: FurnitureObservation,
  pose: FurniturePose,
  roomId: string | null,
  context: ConstraintContext,
): string[] {
  const reasons: string[] = [];
  if (!roomId) return ["No room assignment."];
  const room = context.roomsById.get(roomId);
  if (!room) return [`Unknown room ${roomId}.`];
  const footprint = obbCorners(pose);
  if (!convexInsideSimple(footprint, room.polygon)) reasons.push("Footprint is outside or crosses the assigned room polygon.");

  for (const wall of context.walls) {
    // Only test walls associated with this room when room IDs are available;
    // otherwise test every architectural wall.
    if (wall.roomIds?.length && !wall.roomIds.includes(roomId)) continue;
    const thickness = wall.thickness ?? context.priors.wallThickness;
    const wallPoly = rectangleAroundSegment(wall.p1, wall.p2, thickness / 2, thickness / 2);
    const area = convexSimpleIntersectionArea(footprint, wallPoly);
    if (area > 0.0004) {
      reasons.push(`Intersects wall ${wall.id}.`);
      break;
    }
  }

  for (const zone of context.keepOuts) {
    if (zone.roomId && zone.roomId !== roomId) continue;
    if (!keepOutApplies(zone, object.kind, object.height)) continue;
    const area = convexSimpleIntersectionArea(footprint, zone.polygon);
    if (area > 0.0004) reasons.push(`${zone.reason} (${zone.id})`);
  }

  // Cabinet and appliance fronts are functional free space, not decoration.
  // Reject candidates whose service area cuts across a door threshold/swing.
  if (needsHardServiceClearance(object)) {
    const service = frontClearancePolygon(pose, context.priors.kinds[object.kind].frontClearance, 0.04);
    for (const zone of context.keepOuts) {
      if (zone.roomId && zone.roomId !== roomId) continue;
      if (zone.kind === "window-tall-object") continue;
      const area = convexSimpleIntersectionArea(service, zone.polygon);
      if (area > 0.003) {
        reasons.push(`Required ${object.kind} front clearance intersects ${zone.kind} (${zone.id}).`);
        break;
      }
    }
  }
  return reasons;
}

export function validateCandidate(
  candidate: PlacementCandidate,
  object: FurnitureObservation,
  context: ConstraintContext,
): PlacementCandidate {
  if (!candidate.pose) return { ...candidate, hardValid: true, hardInvalidReasons: [] };
  const reasons = validatePoseAgainstArchitecture(object, candidate.pose, candidate.roomId, context);
  return { ...candidate, hardValid: reasons.length === 0, hardInvalidReasons: reasons };
}


export function pairOverlapAllowed(
  aObject: FurnitureObservation,
  aCandidate: PlacementCandidate,
  bObject: FurnitureObservation,
  bCandidate: PlacementCandidate,
  priors: LayoutPriors,
): boolean {
  if (!aCandidate.pose || !bCandidate.pose) return false;
  const chairTable =
    (aObject.kind === "chair" && bObject.kind === "table")
    || (aObject.kind === "table" && bObject.kind === "chair");
  if (chairTable) {
    const chairObject = aObject.kind === "chair" ? aObject : bObject;
    const tableObject = aObject.kind === "table" ? aObject : bObject;
    const chairCandidate = aObject.kind === "chair" ? aCandidate : bCandidate;
    const tableCandidate = aObject.kind === "table" ? aCandidate : bCandidate;
    const anchored = chairCandidate.source === "table-seat"
      && chairCandidate.anchorObjectId === tableObject.id
      && (!chairCandidate.anchorCandidateId || chairCandidate.anchorCandidateId === tableCandidate.id);
    if (!anchored || chairObject.roomId !== tableObject.roomId) return false;
    const chair = chairCandidate.pose!;
    const table = tableCandidate.pose!;
    const relative = sub(chair.center, table.center);
    const u = Math.abs(dot(relative, table.axisW));
    const v = Math.abs(dot(relative, table.axisD));
    const nearAnEdge = u >= Math.max(0, table.halfW - chair.halfD * 0.9)
      || v >= Math.max(0, table.halfD - chair.halfD * 0.9);
    const overlapRatio = obbIntersectionArea(chair, table, 0) / Math.max(poseArea(chair), 1e-6);
    return nearAnEdge && overlapRatio <= priors.semantic.maxSeatOverlapRatio;
  }
  return isAllowedContainmentPair(aObject, bObject);
}

export function candidatesConflict(
  aObject: FurnitureObservation,
  a: PlacementCandidate,
  bObject: FurnitureObservation,
  b: PlacementCandidate,
  priors: LayoutPriors,
): boolean {
  if (!a.pose || !b.pose) return false;
  if (a.roomId && b.roomId && a.roomId !== b.roomId) return false;
  if (pairOverlapAllowed(aObject, a, bObject, b, priors)) return false;
  if (obbIntersectionArea(a.pose, b.pose, priors.objectGap) > 0.0004) return true;

  // Do not let another solid object occupy the operational front zone of a
  // cabinet/appliance. Clearance-clearance overlap remains legal.
  if (needsHardServiceClearance(aObject)) {
    const service = frontClearancePolygon(a.pose, priors.kinds[aObject.kind].frontClearance, 0.03);
    if (convexSimpleIntersectionArea(service, obbCorners(b.pose)) > 0.003) return true;
  }
  if (needsHardServiceClearance(bObject)) {
    const service = frontClearancePolygon(b.pose, priors.kinds[bObject.kind].frontClearance, 0.03);
    if (convexSimpleIntersectionArea(service, obbCorners(a.pose)) > 0.003) return true;
  }
  return false;
}
