import type { FurnitureKind, KindPrior, LayoutPriors, PairPrior, SemanticPriors, SolverOptions } from "../types.js";
import { MINED_LAYOUT_PRIORS } from "./mined.js";

const roomWeights = {
  livingRoom: 1,
  bedroom: 1,
  bathroom: 1,
  kitchen: 1,
  diningRoom: 1,
  hallway: 1,
  office: 1,
  laundry: 1,
  storage: 1,
  unknown: 1,
} as const;

const kind = (value: KindPrior): KindPrior => value;

/**
 * Bootstrap coefficients for the runtime solver.
 *
 * Wall-affinity/back-gap values preserve the ProcTHOR/ARKitScenes-derived
 * conventions already used by the Reaigen renderer. The important production
 * change is that yaw correction is category-specific and conservative: 45°
 * is not used because it snaps every possible orientation to a cardinal axis.
 * The included mining scripts regenerate a JSON override from local copies of
 * ProcTHOR-10K and ARKitScenes.
 */
export const DEFAULT_KIND_PRIORS: Record<FurnitureKind, KindPrior> = {
  storage: kind({
    wallAffinity: 1,
    backGap: 0.01,
    yawSnapDeg: Math.ceil(MINED_LAYOUT_PRIORS.replicaCad.yawResidualP90Deg.storage) + 1,
    maxMove: 1.25,
    dropPenalty: 12,
    frontClearance: 0.65,
    heightClass: "tall",
    widthDepthPreference: "width-long",
    placement: "wall-required",
    roomWeights: { ...roomWeights, kitchen: 0.75, bedroom: 0.8, storage: 0.7, hallway: 1.1 },
  }),
  refrigerator: kind({
    wallAffinity: 1,
    backGap: 0.01,
    yawSnapDeg: 10,
    maxMove: 0.8,
    dropPenalty: 18,
    frontClearance: 0.85,
    heightClass: "tall",
    widthDepthPreference: "width-long",
    placement: "fixture",
    roomWeights: { ...roomWeights, kitchen: 0.35, diningRoom: 1.5, bedroom: 3, bathroom: 3 },
  }),
  washerDryer: kind({
    wallAffinity: 1,
    backGap: 0.01,
    yawSnapDeg: 10,
    maxMove: 0.65,
    dropPenalty: 18,
    frontClearance: 0.8,
    heightClass: "medium",
    widthDepthPreference: "width-long",
    placement: "fixture",
    roomWeights: { ...roomWeights, bathroom: 0.65, laundry: 0.3, kitchen: 0.9, bedroom: 3 },
  }),
  sink: kind({
    wallAffinity: 1,
    backGap: 0.01,
    yawSnapDeg: 10,
    maxMove: 0.45,
    dropPenalty: 24,
    frontClearance: 0.65,
    heightClass: "medium",
    widthDepthPreference: "width-long",
    placement: "fixture",
    roomWeights: { ...roomWeights, bathroom: 0.45, kitchen: 0.35, bedroom: 4 },
  }),
  toilet: kind({
    wallAffinity: 1,
    backGap: 0.01,
    yawSnapDeg: 10,
    maxMove: 0.35,
    dropPenalty: 28,
    frontClearance: 0.75,
    heightClass: "low",
    widthDepthPreference: "depth-long",
    placement: "fixture",
    roomWeights: { ...roomWeights, bathroom: 0.2, kitchen: 5, bedroom: 5 },
  }),
  television: kind({
    wallAffinity: 0.98,
    backGap: 0.02,
    yawSnapDeg: 10,
    maxMove: 1,
    dropPenalty: 8,
    frontClearance: 0.1,
    heightClass: "medium",
    widthDepthPreference: "width-long",
    placement: "wall-required",
    roomWeights: { ...roomWeights, livingRoom: 0.45, bedroom: 0.85, bathroom: 4, kitchen: 2 },
  }),
  bed: kind({
    wallAffinity: 1,
    backGap: 0.01,
    yawSnapDeg: 10,
    maxMove: 0.9,
    dropPenalty: 22,
    frontClearance: 0.75,
    heightClass: "low",
    widthDepthPreference: "depth-long",
    placement: "wall-required",
    roomWeights: { ...roomWeights, bedroom: 0.2, livingRoom: 2, bathroom: 5, kitchen: 5 },
  }),
  bathtub: kind({
    wallAffinity: 1,
    backGap: 0.01,
    yawSnapDeg: 8,
    maxMove: 0.4,
    dropPenalty: 28,
    frontClearance: 0.65,
    heightClass: "low",
    widthDepthPreference: "depth-long",
    placement: "fixture",
    roomWeights: { ...roomWeights, bathroom: 0.2, bedroom: 5, kitchen: 5 },
  }),
  stove: kind({
    wallAffinity: 1,
    backGap: 0.01,
    yawSnapDeg: 8,
    maxMove: 0.4,
    dropPenalty: 24,
    frontClearance: 0.75,
    heightClass: "medium",
    widthDepthPreference: "width-long",
    placement: "fixture",
    roomWeights: { ...roomWeights, kitchen: 0.2, bedroom: 5, bathroom: 4 },
  }),
  oven: kind({
    wallAffinity: 1,
    backGap: 0.01,
    yawSnapDeg: 8,
    maxMove: 0.4,
    dropPenalty: 24,
    frontClearance: 0.75,
    heightClass: "medium",
    widthDepthPreference: "width-long",
    placement: "fixture",
    roomWeights: { ...roomWeights, kitchen: 0.2, bedroom: 5, bathroom: 4 },
  }),
  dishwasher: kind({
    wallAffinity: 1,
    backGap: 0.01,
    yawSnapDeg: 8,
    maxMove: 0.4,
    dropPenalty: 24,
    frontClearance: 0.75,
    heightClass: "medium",
    widthDepthPreference: "width-long",
    placement: "fixture",
    roomWeights: { ...roomWeights, kitchen: 0.25, bathroom: 3, bedroom: 5 },
  }),
  fireplace: kind({
    wallAffinity: 1,
    backGap: 0,
    yawSnapDeg: 8,
    maxMove: 0.25,
    dropPenalty: 28,
    frontClearance: 0.9,
    heightClass: "medium",
    widthDepthPreference: "width-long",
    placement: "fixture",
    roomWeights: { ...roomWeights, livingRoom: 0.3, bedroom: 1, bathroom: 4, kitchen: 2 },
  }),
  sofa: kind({
    wallAffinity: 0.51,
    backGap: 0.05,
    yawSnapDeg: Math.min(10, Math.ceil(MINED_LAYOUT_PRIORS.replicaCad.yawResidualP90Deg.sofa)),
    maxMove: 1,
    dropPenalty: 18,
    frontClearance: 0.75,
    heightClass: "medium",
    widthDepthPreference: "width-long",
    placement: "wall-preferred",
    roomWeights: { ...roomWeights, livingRoom: 0.25, bedroom: 1.2, bathroom: 5, kitchen: 3 },
  }),
  table: kind({
    wallAffinity: 0,
    backGap: 0,
    yawSnapDeg: Math.ceil(MINED_LAYOUT_PRIORS.replicaCad.yawResidualP90Deg.table) + 1,
    maxMove: 0.75,
    dropPenalty: 12,
    frontClearance: 0.65,
    heightClass: "medium",
    widthDepthPreference: "preserve",
    placement: "free",
    roomWeights: { ...roomWeights, diningRoom: 0.35, kitchen: 0.7, livingRoom: 0.75, bathroom: 4 },
  }),
  chair: kind({
    wallAffinity: 0,
    backGap: 0,
    // ReplicaCAD chairs are intentionally angled (38.2 degrees at P90), so
    // only small sensor residuals are even eligible for rectification.
    yawSnapDeg: 7,
    maxMove: 0.8,
    dropPenalty: 6,
    frontClearance: 0.35,
    heightClass: "medium",
    widthDepthPreference: "preserve",
    placement: "free",
    roomWeights: { ...roomWeights, diningRoom: 0.5, livingRoom: 0.7, office: 0.6, bathroom: 3 },
  }),
  stairs: kind({
    wallAffinity: 1,
    backGap: 0,
    yawSnapDeg: 8,
    maxMove: 0.2,
    dropPenalty: 35,
    frontClearance: 0.9,
    heightClass: "tall",
    widthDepthPreference: "depth-long",
    placement: "fixture",
    roomWeights: { ...roomWeights, hallway: 0.45, livingRoom: 0.8, bathroom: 5 },
  }),
  generic: kind({
    wallAffinity: 0,
    backGap: 0,
    yawSnapDeg: 6,
    maxMove: 0.45,
    dropPenalty: 3.5,
    frontClearance: 0.4,
    heightClass: "medium",
    widthDepthPreference: "preserve",
    placement: "free",
    roomWeights: { ...roomWeights },
  }),
};


const PHYSICAL_RANGES: Partial<Record<FurnitureKind, Partial<KindPrior>>> = {
  bed: { minWidth: 0.65, maxWidth: 2.5, minDepth: 1.45, maxDepth: 2.55, minHeight: 0.25, maxHeight: 1.5 },
  sofa: { minWidth: 0.75, maxWidth: 4.5, minDepth: 0.5, maxDepth: 2.8, minHeight: 0.35, maxHeight: 1.5 },
  chair: { minWidth: 0.28, maxWidth: 1.25, minDepth: 0.28, maxDepth: 1.25, minHeight: 0.35, maxHeight: 1.5 },
  table: { minWidth: 0.35, maxWidth: 4.0, minDepth: 0.35, maxDepth: 2.4, minHeight: 0.25, maxHeight: 1.25 },
  storage: { minWidth: 0.2, maxWidth: 4.8, minDepth: 0.18, maxDepth: 0.95, minHeight: 0.25, maxHeight: 3.2 },
  refrigerator: { minWidth: 0.42, maxWidth: 1.35, minDepth: 0.42, maxDepth: 1.15, minHeight: 0.8, maxHeight: 2.5 },
  stove: { minWidth: 0.35, maxWidth: 1.3, minDepth: 0.35, maxDepth: 1.0, minHeight: 0.2, maxHeight: 1.25 },
  oven: { minWidth: 0.35, maxWidth: 1.3, minDepth: 0.35, maxDepth: 1.0, minHeight: 0.2, maxHeight: 2.4 },
  dishwasher: { minWidth: 0.35, maxWidth: 1.0, minDepth: 0.35, maxDepth: 0.95, minHeight: 0.45, maxHeight: 1.25 },
  washerDryer: { minWidth: 0.4, maxWidth: 1.45, minDepth: 0.4, maxDepth: 1.15, minHeight: 0.5, maxHeight: 2.4 },
  sink: { minWidth: 0.25, maxWidth: 2.2, minDepth: 0.25, maxDepth: 1.0, minHeight: 0.2, maxHeight: 1.4 },
  toilet: { minWidth: 0.28, maxWidth: 0.9, minDepth: 0.42, maxDepth: 1.2, minHeight: 0.25, maxHeight: 1.25 },
  bathtub: { minWidth: 0.55, maxWidth: 1.4, minDepth: 1.1, maxDepth: 2.8, minHeight: 0.25, maxHeight: 1.1 },
  fireplace: { minWidth: 0.45, maxWidth: 2.8, minDepth: 0.12, maxDepth: 0.9, minHeight: 0.3, maxHeight: 2.4 },
  television: { minWidth: 0.35, maxWidth: 3.0, minDepth: 0.04, maxDepth: 0.5, minHeight: 0.2, maxHeight: 2.2 },
  stairs: { minWidth: 0.55, maxWidth: 2.5, minDepth: 1.0, maxDepth: 8.0, minHeight: 0.2, maxHeight: 5.0 },
};

for (const [kindName, range] of Object.entries(PHYSICAL_RANGES)) {
  Object.assign(DEFAULT_KIND_PRIORS[kindName as FurnitureKind], range);
}

export const DEFAULT_PAIR_PRIORS: PairPrior[] = [
  {
    a: "chair",
    b: "table",
    relation: "seat",
    preferredDistance: MINED_LAYOUT_PRIORS.procthor.diningSeatDistanceMedian,
    maxDistance: MINED_LAYOUT_PRIORS.procthor.diningSeatDistanceP90 + 0.1,
    hardContainmentAllowed: true,
  },
  { a: "sink", b: "storage", relation: "containment", hardContainmentAllowed: true },
  { a: "oven", b: "storage", relation: "containment", hardContainmentAllowed: true },
  { a: "stove", b: "storage", relation: "containment", hardContainmentAllowed: true },
  { a: "dishwasher", b: "storage", relation: "containment", hardContainmentAllowed: true },
  { a: "television", b: "storage", relation: "containment", hardContainmentAllowed: true },
  { a: "oven", b: "stove", relation: "containment", hardContainmentAllowed: true },
  { a: "television", b: "sofa", relation: "faces", preferredDistance: 2.9, maxDistance: 5 },
  { a: "table", b: "sofa", relation: "satellite", preferredDistance: 0.45, maxDistance: 1.7 },
  { a: "table", b: "bed", relation: "satellite", preferredDistance: 0.08, maxDistance: 1.3 },
];

/**
 * Semantic grouping thresholds. Chair/table distance uses the 10k-house
 * nearest dining-seat distribution in the bundled ProcTHOR mining artifact
 * (median 0.685 m, P90 1.053 m). Footprint
 * thresholds remain conservative engineering fallbacks until a licensed
 * ARKitScenes geometry export is supplied.
 */
export const DEFAULT_SEMANTIC_PRIORS: SemanticPriors = {
  diningTableMinLong: 1.12,
  diningTableMinArea: 0.82,
  // Applied only after a hard constraint already forces relocation. Raw valid
  // tables retain their measured yaw, including intentionally angled layouts.
  relocatedDiningAxialMaxDeg: 24,
  satelliteTableMaxLong: 1.08,
  satelliteTableMaxArea: 0.9,
  chairTableAssociationMax: MINED_LAYOUT_PRIORS.procthor.diningSeatDistanceP90 + 0.1,
  chairTableAmbiguityMargin: 0.18,
  // Negative means a visible presentation gap. With the mined P90 dining-seat
  // centre distance this remains realistic while avoiding fused SVG symbols.
  seatInset: 0.03,
  anchoredSeatReward: 1.1,
  maxSeatOverlapRatio: 0.1,
};

export const DEFAULT_LAYOUT_PRIORS: LayoutPriors = {
  kinds: DEFAULT_KIND_PRIORS,
  pairs: DEFAULT_PAIR_PRIORS,
  semantic: DEFAULT_SEMANTIC_PRIORS,
  dedupeSameKindContainment: 0.45,
  dedupeCrossKindContainment: 0.9,
  sameKindStackSlack: 0.18,
  objectGap: 0.025,
  wallThickness: 0.18,
  doorSideClearance: 0.22,
  doorApproachDepth: 0.8,
  openingThresholdDepth: 0.24,
  windowTallClearanceDepth: 0.32,
  windowTallSideClearance: 0.16,
  storageEndClearance: 0.04,
  minRoomArea: 1.2,
  minRoomContainment: 0.55,
  navigationGrid: 0.16,
  navigationObjectBuffer: 0.16,
  minNavigationRatio: 0.62,
  beamWidth: 160,
  maxCandidatesPerObject: 12,
};

export function resolvePriors(options: SolverOptions = {}): LayoutPriors {
  const override = options.priors;
  const kinds = { ...DEFAULT_LAYOUT_PRIORS.kinds } as Record<FurnitureKind, KindPrior>;
  if (override?.kinds) {
    for (const [key, value] of Object.entries(override.kinds)) {
      if (!value) continue;
      const k = key as FurnitureKind;
      kinds[k] = { ...kinds[k], ...value };
    }
  }
  return {
    ...DEFAULT_LAYOUT_PRIORS,
    ...override,
    kinds,
    pairs: override?.pairs ?? DEFAULT_LAYOUT_PRIORS.pairs,
    semantic: { ...DEFAULT_LAYOUT_PRIORS.semantic, ...(override?.semantic ?? {}) },
    beamWidth: options.beamWidth ?? override?.beamWidth ?? DEFAULT_LAYOUT_PRIORS.beamWidth,
    maxCandidatesPerObject:
      options.maxCandidatesPerObject ?? override?.maxCandidatesPerObject ?? DEFAULT_LAYOUT_PRIORS.maxCandidatesPerObject,
  };
}
