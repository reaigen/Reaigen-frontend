#!/usr/bin/env node

import { readFile, writeFile } from "node:fs/promises";
import { parseRoomPlanJSON } from "./input/roomplan-json.js";
import { solveFloorplan } from "./solver/solve.js";
import type { SolverInput } from "./types.js";

function usage(): never {
  console.error("Usage: reaigen-floorplan-solve <input.json> <output.json> [--roomplan] [--non-strict]");
  process.exit(2);
}

const args = process.argv.slice(2);
const inputPath = args[0];
const outputPath = args[1];
if (!inputPath || !outputPath) usage();
const roomPlan = args.includes("--roomplan");
const strict = !args.includes("--non-strict");

try {
  const parsed = JSON.parse(await readFile(inputPath, "utf8")) as unknown;
  const input = roomPlan ? parseRoomPlanJSON(parsed) : parsed as SolverInput;
  const result = solveFloorplan(input, { strict });
  await writeFile(outputPath, `${JSON.stringify(result, null, 2)}\n`, "utf8");
  console.error(
    `Solved ${result.diagnostics.inputObjectCount} observations: `
    + `${result.diagnostics.acceptedObjectCount} accepted, `
    + `${result.diagnostics.rejectedObjectCount} rejected, `
    + `${result.diagnostics.deduplicatedObjectCount} merged; valid=${result.validation.valid}`,
  );
} catch (error) {
  const value = error instanceof Error ? error : new Error(String(error));
  console.error(`${value.name}: ${value.message}`);
  process.exit(1);
}
