export type Vec2 = [number, number];
export type Polygon2 = Vec2[];

export type RoomType =
  | "livingRoom"
  | "bedroom"
  | "bathroom"
  | "kitchen"
  | "diningRoom"
  | "hallway"
  | "office"
  | "laundry"
  | "storage"
  | "unknown";

export type FurnitureKind =
  | "bed"
  | "sofa"
  | "chair"
  | "table"
  | "storage"
  | "refrigerator"
  | "stove"
  | "oven"
  | "dishwasher"
  | "washerDryer"
  | "sink"
  | "toilet"
  | "bathtub"
  | "fireplace"
  | "television"
  | "stairs"
  | "generic";

export type OpeningKind = "door" | "window" | "opening";

export interface WallSegment {
  id: string;
  p1: Vec2;
  p2: Vec2;
  thickness?: number;
  roomIds?: string[];
}

export interface DoorConfiguration {
  doorType?: "Swinging" | "Moving" | "Unknown" | string;
  hingeSide?: "Left" | "Right" | "Moving" | "Unknown" | string;
  swingDirection?: "In" | "Out" | "Moving" | "Unknown" | string;
  /** Optional room against which In/Out is interpreted. */
  primaryRoomId?: string;
}

export interface OpeningObservation {
  id: string;
  kind: OpeningKind;
  p1: Vec2;
  p2: Vec2;
  wallId?: string;
  parentId?: string;
  roomIds?: string[];
  configuration?: DoorConfiguration;
}

export interface RoomObservation {
  id: string;
  polygon: Polygon2;
  type?: RoomType;
  label?: string;
  floorId?: string;
  confidence?: number;
  source?: "roomplan-floor" | "roomplan-section" | "wall-face" | "fallback-hull" | "manual";
}

export interface FurniturePose {
  center: Vec2;
  axisW: Vec2;
  axisD: Vec2;
  halfW: number;
  halfD: number;
}

export interface FurnitureObservation extends FurniturePose {
  id: string;
  category: string;
  kind: FurnitureKind;
  height?: number;
  centerY?: number;
  confidence?: number;
  parentId?: string;
  attributes?: string[];
  roomId?: string;
  sourceRoomId?: string;
  sourceIndex?: number;
}

export interface SolverInput {
  rooms?: RoomObservation[];
  walls: WallSegment[];
  openings?: OpeningObservation[];
  objects: FurnitureObservation[];
  /** Optional source marker included in diagnostics. */
  source?: "roomplan-json" | "captured-structure" | "legacy-web" | "canonical";
  metadata?: Record<string, unknown>;
}

export type KeepOutKind =
  | "door-threshold"
  | "door-approach"
  | "door-swing"
  | "sliding-door-travel"
  | "window-tall-object"
  | "opening-approach";

export interface KeepOutZone {
  id: string;
  kind: KeepOutKind;
  polygon: Polygon2;
  roomId?: string;
  openingId?: string;
  /** Empty means every kind. */
  appliesToKinds?: FurnitureKind[];
  reason: string;
}

export type CandidateSource =
  | "raw"
  | "yaw-rectified"
  | "measured-wall-clearance"
  | "wall"
  | "storage-wall-run"
  | "table-seat"
  | "dining-group"
  | "satellite-table"
  | "tv-sofa"
  | "fallback"
  | "reject";

export interface PlacementCandidate {
  id: string;
  objectId: string;
  roomId: string | null;
  pose: FurniturePose | null;
  source: CandidateSource;
  baseCost: number;
  reasons: string[];
  hardValid: boolean;
  hardInvalidReasons: string[];
  anchorObjectId?: string;
  anchorCandidateId?: string;
  wallId?: string;
  wallParameter?: number;
}

export type SolvedStatus = "unchanged" | "rectified" | "relocated" | "merged" | "rejected";

export interface SolvedFurniture extends Omit<FurnitureObservation, "roomId"> {
  status: SolvedStatus;
  roomId: string | null;
  sourcePose: FurniturePose;
  selectedCandidateId: string | null;
  candidateSource: CandidateSource | null;
  displacement: number;
  yawDeltaDeg: number;
  score: number;
  reasons: string[];
  mergedIntoId?: string;
}

export type ValidationIssueCode =
  | "NO_ROOM"
  | "OUTSIDE_ROOM"
  | "WALL_COLLISION"
  | "OPENING_BLOCKED"
  | "WINDOW_BLOCKED"
  | "OBJECT_OVERLAP"
  | "STORAGE_OVERLAP"
  | "NAVIGATION_FRAGMENTED"
  | "DOOR_APPROACH_UNREACHABLE"
  | "INVALID_GEOMETRY";

export interface ValidationIssue {
  code: ValidationIssueCode;
  severity: "error" | "warning";
  message: string;
  objectIds?: string[];
  roomId?: string;
  openingId?: string;
  metric?: number;
}

export interface NavigationMetrics {
  gridSize: number;
  freeCellCount: number;
  largestComponentCellCount: number;
  largestComponentRatio: number;
  reachableDoorApproaches: number;
  totalDoorApproaches: number;
}

export interface ValidationReport {
  valid: boolean;
  issues: ValidationIssue[];
  navigation: NavigationMetrics;
}

export interface SolverDiagnostics {
  elapsedMs: number;
  roomSource: "provided" | "wall-faces" | "fallback-hull" | "none";
  inputObjectCount: number;
  deduplicatedObjectCount: number;
  acceptedObjectCount: number;
  rejectedObjectCount: number;
  candidateCount: number;
  exploredStateCount: number;
  repairCount: number;
  warnings: string[];
}

export interface SolveResult {
  rooms: RoomObservation[];
  walls: WallSegment[];
  openings: OpeningObservation[];
  keepOuts: KeepOutZone[];
  objects: SolvedFurniture[];
  validation: ValidationReport;
  diagnostics: SolverDiagnostics;
}

export interface KindPrior {
  wallAffinity: number;
  backGap: number;
  yawSnapDeg: number;
  maxMove: number;
  dropPenalty: number;
  frontClearance: number;
  heightClass: "low" | "medium" | "tall";
  widthDepthPreference: "width-long" | "depth-long" | "preserve";
  placement: "wall-required" | "wall-preferred" | "free" | "fixture";
  /** Conservative physical footprint ranges in metres; mined overrides may replace them. */
  minWidth?: number;
  maxWidth?: number;
  minDepth?: number;
  maxDepth?: number;
  minHeight?: number;
  maxHeight?: number;
  roomWeights?: Partial<Record<RoomType, number>>;
}

export interface PairPrior {
  a: FurnitureKind;
  b: FurnitureKind;
  relation: "containment" | "faces" | "adjacent" | "seat" | "satellite";
  preferredDistance?: number;
  maxDistance?: number;
  hardContainmentAllowed?: boolean;
}

export interface SemanticPriors {
  diningTableMinLong: number;
  diningTableMinArea: number;
  relocatedDiningAxialMaxDeg: number;
  satelliteTableMaxLong: number;
  satelliteTableMaxArea: number;
  chairTableAssociationMax: number;
  chairTableAmbiguityMargin: number;
  seatInset: number;
  anchoredSeatReward: number;
  maxSeatOverlapRatio: number;
}

export interface LayoutPriors {
  kinds: Record<FurnitureKind, KindPrior>;
  pairs: PairPrior[];
  semantic: SemanticPriors;
  dedupeSameKindContainment: number;
  dedupeCrossKindContainment: number;
  sameKindStackSlack: number;
  objectGap: number;
  wallThickness: number;
  doorSideClearance: number;
  doorApproachDepth: number;
  openingThresholdDepth: number;
  windowTallClearanceDepth: number;
  windowTallSideClearance: number;
  storageEndClearance: number;
  minRoomArea: number;
  minRoomContainment: number;
  navigationGrid: number;
  navigationObjectBuffer: number;
  minNavigationRatio: number;
  beamWidth: number;
  maxCandidatesPerObject: number;
}

export interface SolverOptions {
  priors?: Omit<Partial<LayoutPriors>, "kinds" | "semantic"> & {
    kinds?: Partial<Record<FurnitureKind, Partial<KindPrior>>>;
    semantic?: Partial<SemanticPriors>;
  };
  strict?: boolean;
  beamWidth?: number;
  maxCandidatesPerObject?: number;
  runNavigationRepair?: boolean;
  debug?: boolean;
}
