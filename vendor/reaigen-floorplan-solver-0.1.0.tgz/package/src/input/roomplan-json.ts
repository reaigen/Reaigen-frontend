import type {
  DoorConfiguration,
  FurnitureKind,
  FurnitureObservation,
  OpeningObservation,
  Polygon2,
  RoomObservation,
  RoomType,
  SolverInput,
  Vec2,
  WallSegment,
} from "../types.js";
import { ensureCCW, polygonArea } from "../geometry/polygon.js";
import { normalize } from "../geometry/vector.js";

const asRecord = (value: unknown): Record<string, unknown> | null =>
  value && typeof value === "object" ? (value as Record<string, unknown>) : null;
const asArray = (value: unknown): unknown[] => (Array.isArray(value) ? value : []);
const num = (value: unknown, fallback = 0): number => {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
};

function identifier(value: unknown, fallback: string): string {
  const rec = asRecord(value);
  return String(rec?.identifier ?? rec?.id ?? fallback).toLowerCase();
}

function categoryKey(raw: unknown): string {
  if (typeof raw === "string") return raw;
  const rec = asRecord(raw);
  const first = rec ? Object.keys(rec)[0] : undefined;
  return first ?? "";
}

export function furnitureKindFromRoomPlan(raw: string): FurnitureKind {
  const key = raw.toLowerCase().replace(/_var.*$|[\s_-]|\d+$/g, "");
  switch (key) {
    case "bed": return "bed";
    case "sofa":
    case "couch": return "sofa";
    case "chair":
    case "stool": return "chair";
    case "table":
    case "desk": return "table";
    case "storage":
    case "wardrobe":
    case "closet":
    case "cabinet":
    case "shelf": return "storage";
    case "refrigerator":
    case "fridge": return "refrigerator";
    case "stove":
    case "cooktop": return "stove";
    case "oven": return "oven";
    case "dishwasher": return "dishwasher";
    case "washerdryer":
    case "washer":
    case "dryer":
    case "washingmachine": return "washerDryer";
    case "sink": return "sink";
    case "toilet":
    case "wc": return "toilet";
    case "bathtub":
    case "tub":
    case "shower": return "bathtub";
    case "fireplace": return "fireplace";
    case "television":
    case "tv": return "television";
    case "stairs":
    case "staircase": return "stairs";
    default: return "generic";
  }
}

function matrix(value: unknown): number[] | null {
  if (!Array.isArray(value) || value.length < 16) return null;
  const out = value.map(Number);
  return out.every(Number.isFinite) ? out : null;
}

function dimensions(value: unknown): number[] | null {
  if (!Array.isArray(value) || value.length < 2) return null;
  return value.map(Number);
}

/** Bottom edge of a vertical RoomPlan surface in XZ world coordinates. */
function verticalSurfaceEndpoints(surface: Record<string, unknown>): [Vec2, Vec2] | null {
  const dims = dimensions(surface.dimensions);
  const m = matrix(surface.transform);
  if (!dims || !m) return null;
  const hx = Math.abs(dims[0] ?? 0) / 2;
  const hy = Math.abs(dims[1] ?? 0) / 2;
  const world = (lx: number, ly: number): Vec2 => [
    (m[0] ?? 0) * lx + (m[4] ?? 0) * ly + (m[12] ?? 0),
    (m[2] ?? 0) * lx + (m[6] ?? 0) * ly + (m[14] ?? 0),
  ];
  return [world(-hx, -hy), world(hx, -hy)];
}

function parsePoint(raw: unknown): Vec2 | null {
  if (Array.isArray(raw)) {
    if (raw.length >= 3) return [num(raw[0]), num(raw[2])];
    if (raw.length >= 2) return [num(raw[0]), num(raw[1])];
  }
  const rec = asRecord(raw);
  if (rec) return [num(rec.x), num(rec.z ?? rec.y)];
  return null;
}

/**
 * Apple encodings have used `polygonCorners`/`polygonCorner` in different
 * SDK representations. This accepts world-space points and local points. When
 * a transform exists and the values look local, the transform is applied.
 */
function polygonCorners(surface: Record<string, unknown>): Polygon2 | null {
  const raw = surface.polygonCorners ?? surface.polygonCorner ?? surface.corners ?? surface.polygon;
  const values = asArray(raw);
  if (values.length < 3) return null;
  let points = values.map(parsePoint).filter((p): p is Vec2 => p !== null);
  if (points.length < 3) return null;
  const m = matrix(surface.transform);
  if (m) {
    const translationMagnitude = Math.hypot(m[12] ?? 0, m[14] ?? 0);
    const averageMagnitude = points.reduce((s, p) => s + Math.hypot(p[0], p[1]), 0) / points.length;
    // Local polygon corners normally cluster around the origin; world corners
    // are already near the transform translation.
    if (translationMagnitude > 1 && averageMagnitude < translationMagnitude * 0.7 + 2) {
      points = points.map(([x, z]) => [
        (m[0] ?? 0) * x + (m[8] ?? 0) * z + (m[12] ?? 0),
        (m[2] ?? 0) * x + (m[10] ?? 0) * z + (m[14] ?? 0),
      ] as Vec2);
    }
  }
  const poly = ensureCCW(points);
  return polygonArea(poly) > 0.1 ? poly : null;
}

function floorRectangle(surface: Record<string, unknown>): Polygon2 | null {
  const dims = dimensions(surface.dimensions);
  const m = matrix(surface.transform);
  if (!dims || !m) return null;
  const hx = Math.abs(dims[0] ?? 0) / 2;
  const hz = Math.abs(dims[2] ?? dims[1] ?? 0) / 2;
  if (hx < 0.05 || hz < 0.05) return null;
  const world = (x: number, z: number): Vec2 => [
    (m[0] ?? 0) * x + (m[8] ?? 0) * z + (m[12] ?? 0),
    (m[2] ?? 0) * x + (m[10] ?? 0) * z + (m[14] ?? 0),
  ];
  return ensureCCW([world(-hx, -hz), world(hx, -hz), world(hx, hz), world(-hx, hz)]);
}

function parseAttributes(raw: unknown): string[] {
  return asArray(raw).map((value) => {
    if (typeof value === "string") return value;
    const rec = asRecord(value);
    return rec ? Object.keys(rec)[0] ?? JSON.stringify(rec) : String(value);
  });
}

function parseObject(raw: unknown, index: number, sourceRoomId?: string): FurnitureObservation | null {
  const object = asRecord(raw);
  if (!object) return null;
  const dims = dimensions(object.dimensions);
  const m = matrix(object.transform);
  if (!dims || !m || dims.length < 3) return null;
  const halfW = Math.abs(dims[0] ?? 0) / 2;
  const halfD = Math.abs(dims[2] ?? 0) / 2;
  if (halfW < 0.02 || halfD < 0.02) return null;
  const axisW = normalize([m[0] ?? 1, m[2] ?? 0]);
  const axisD = normalize([m[8] ?? 0, m[10] ?? 1], [-axisW[1], axisW[0]]);
  const category = categoryKey(object.category);
  return {
    id: identifier(object, `object-${index}`),
    category,
    kind: furnitureKindFromRoomPlan(category),
    center: [m[12] ?? 0, m[14] ?? 0],
    axisW,
    axisD,
    halfW,
    halfD,
    height: Math.abs(dims[1] ?? 0),
    centerY: m[13] ?? 0,
    confidence: typeof object.confidence === "number" ? object.confidence : undefined,
    parentId: object.parentIdentifier ? String(object.parentIdentifier).toLowerCase() : undefined,
    attributes: parseAttributes(object.attributes),
    sourceRoomId,
    sourceIndex: index,
  };
}

function parseWalls(raw: unknown[], prefix: string): WallSegment[] {
  const out: WallSegment[] = [];
  raw.forEach((entry, index) => {
    const surface = asRecord(entry);
    if (!surface) return;
    const endpoints = verticalSurfaceEndpoints(surface);
    if (!endpoints) return;
    out.push({
      id: identifier(surface, `${prefix}-wall-${index}`),
      p1: endpoints[0],
      p2: endpoints[1],
      thickness: typeof surface.thickness === "number" ? surface.thickness : undefined,
    });
  });
  return out;
}

function parseOpenings(raw: unknown[], kind: "door" | "window" | "opening", prefix: string): OpeningObservation[] {
  const out: OpeningObservation[] = [];
  raw.forEach((entry, index) => {
    const surface = asRecord(entry);
    if (!surface) return;
    const endpoints = verticalSurfaceEndpoints(surface);
    if (!endpoints) return;
    out.push({
      id: identifier(surface, `${prefix}-${kind}-${index}`),
      kind,
      p1: endpoints[0],
      p2: endpoints[1],
      parentId: surface.parentIdentifier ? String(surface.parentIdentifier).toLowerCase() : undefined,
      wallId: surface.parentIdentifier ? String(surface.parentIdentifier).toLowerCase() : undefined,
    });
  });
  return out;
}

function normalizeRoomType(raw: unknown): RoomType {
  const key = categoryKey(raw).toLowerCase();
  if (key.includes("living")) return "livingRoom";
  if (key.includes("bed")) return "bedroom";
  if (key.includes("bath")) return "bathroom";
  if (key.includes("kitchen")) return "kitchen";
  if (key.includes("dining")) return "diningRoom";
  if (key.includes("hall")) return "hallway";
  if (key.includes("office")) return "office";
  if (key.includes("laundry")) return "laundry";
  if (key.includes("storage")) return "storage";
  return "unknown";
}

function roomFloors(room: Record<string, unknown>, roomId: string): RoomObservation[] {
  const floors = asArray(room.floors);
  const out: RoomObservation[] = [];
  floors.forEach((raw, index) => {
    const floor = asRecord(raw);
    if (!floor) return;
    const polygon = polygonCorners(floor) ?? floorRectangle(floor);
    if (!polygon) return;
    out.push({
      id: floors.length === 1 ? roomId : `${roomId}-floor-${index + 1}`,
      floorId: identifier(floor, `${roomId}-floor-${index + 1}`),
      polygon,
      type: "unknown",
      source: polygonCorners(floor) ? "roomplan-floor" : "roomplan-floor",
      confidence: 0.95,
    });
  });
  return out;
}

function parseSections(root: Record<string, unknown>): Array<{ type: RoomType; center: Vec2; floorId?: string }> {
  return asArray(root.sections).map((raw) => {
    const section = asRecord(raw) ?? {};
    const m = matrix(section.transform);
    const center = parsePoint(section.center) ?? (m ? [m[12] ?? 0, m[14] ?? 0] as Vec2 : [0, 0]);
    return {
      type: normalizeRoomType(section.label ?? section.category),
      center,
      floorId: section.floorIdentifier ? String(section.floorIdentifier).toLowerCase() : undefined,
    };
  });
}

function dedupeById<T extends { id: string }>(items: T[]): T[] {
  const map = new Map<string, T>();
  for (const item of items) if (!map.has(item.id)) map.set(item.id, item);
  return [...map.values()];
}

export interface RoomPlanParseOptions {
  doorConfigurations?: Record<string, DoorConfiguration>;
}

/** Parse Codable CapturedRoom or CapturedStructure JSON into the solver model. */
export function parseRoomPlanJSON(json: unknown, options: RoomPlanParseOptions = {}): SolverInput {
  const root = asRecord(json);
  if (!root) throw new TypeError("RoomPlan payload must be an object");
  const containedRooms = asArray(root.rooms).map(asRecord).filter((r): r is Record<string, unknown> => r !== null);
  const roomRoots = containedRooms.length ? containedRooms : [root];
  const rooms: RoomObservation[] = [];
  const walls: WallSegment[] = [];
  const openings: OpeningObservation[] = [];
  const objects: FurnitureObservation[] = [];

  roomRoots.forEach((room, roomIndex) => {
    const roomId = identifier(room, `room-${roomIndex + 1}`);
    rooms.push(...roomFloors(room, roomId));
    walls.push(...parseWalls(asArray(room.walls), roomId));
    openings.push(...parseOpenings(asArray(room.doors), "door", roomId));
    openings.push(...parseOpenings(asArray(room.windows), "window", roomId));
    openings.push(...parseOpenings(asArray(room.openings), "opening", roomId));
    asArray(room.objects).forEach((raw, index) => {
      const object = parseObject(raw, objects.length + index, roomId);
      if (object) objects.push(object);
    });
  });

  // CapturedStructure also exposes deduplicated global arrays. Add only IDs not
  // already represented by room-local elements.
  if (containedRooms.length) {
    walls.push(...parseWalls(asArray(root.walls), "structure"));
    openings.push(...parseOpenings(asArray(root.doors), "door", "structure"));
    openings.push(...parseOpenings(asArray(root.windows), "window", "structure"));
    openings.push(...parseOpenings(asArray(root.openings), "opening", "structure"));
    asArray(root.objects).forEach((raw, index) => {
      const object = parseObject(raw, objects.length + index);
      if (object) objects.push(object);
    });
  }

  const dedupedRooms = dedupeById(rooms);
  const sections = parseSections(root);
  for (const section of sections) {
    let best: RoomObservation | undefined;
    let bestDist = Number.POSITIVE_INFINITY;
    for (const room of dedupedRooms) {
      if (section.floorId && room.floorId === section.floorId) {
        best = room;
        break;
      }
      const cx = room.polygon.reduce((s, p) => s + p[0], 0) / room.polygon.length;
      const cz = room.polygon.reduce((s, p) => s + p[1], 0) / room.polygon.length;
      const d = Math.hypot(section.center[0] - cx, section.center[1] - cz);
      if (d < bestDist) {
        bestDist = d;
        best = room;
      }
    }
    if (best) {
      best.type = section.type;
      best.source = "roomplan-section";
    }
  }

  const dedupedOpenings = dedupeById(openings).map((opening) => ({
    ...opening,
    configuration: options.doorConfigurations?.[opening.id] ?? opening.configuration,
  }));

  return {
    rooms: dedupedRooms,
    walls: dedupeById(walls),
    openings: dedupedOpenings,
    objects: dedupeById(objects),
    source: containedRooms.length ? "captured-structure" : "roomplan-json",
  };
}
