import type {
  DoorConfiguration,
  FurnitureObservation,
  OpeningObservation,
  Polygon2,
  RoomObservation,
  SolverInput,
  Vec2,
  WallSegment,
} from "../types.js";
import { furnitureKindFromRoomPlan } from "./roomplan-json.js";

export interface LegacyObjectXZ {
  id: string;
  category: string;
  center: Vec2;
  axisW: Vec2;
  axisD: Vec2;
  halfW: number;
  halfD: number;
  height?: number;
  parentId?: string;
  confidence?: number;
}

export interface LegacySurfaceXZ {
  id?: string;
  p1: Vec2;
  p2: Vec2;
}

export interface LegacySolverInput {
  walls: Array<[Vec2, Vec2]> | LegacySurfaceXZ[];
  doors?: LegacySurfaceXZ[];
  windows?: LegacySurfaceXZ[];
  objects: LegacyObjectXZ[];
  doorConfigs?: Record<string, DoorConfiguration>;
  roomPolygons?: Array<{ id: string; polygon: Polygon2; type?: RoomObservation["type"] }>;
}

function surfacesToWalls(values: LegacySolverInput["walls"]): WallSegment[] {
  return values.map((value, index) => {
    if (Array.isArray(value)) return { id: `wall-${index}`, p1: value[0], p2: value[1] };
    return { id: value.id ?? `wall-${index}`, p1: value.p1, p2: value.p2 };
  });
}

export function buildSolverInputFromLegacy(input: LegacySolverInput): SolverInput {
  const openings: OpeningObservation[] = [
    ...(input.doors ?? []).map((door, index) => ({
      id: (door.id ?? `door-${index}`).toLowerCase(),
      kind: "door" as const,
      p1: door.p1,
      p2: door.p2,
      configuration: input.doorConfigs?.[(door.id ?? "").toLowerCase()],
    })),
    ...(input.windows ?? []).map((window, index) => ({
      id: (window.id ?? `window-${index}`).toLowerCase(),
      kind: "window" as const,
      p1: window.p1,
      p2: window.p2,
    })),
  ];
  const objects: FurnitureObservation[] = input.objects.map((object, index) => ({
    ...object,
    id: (object.id || `object-${index}`).toLowerCase(),
    kind: furnitureKindFromRoomPlan(object.category),
  }));
  return {
    rooms: input.roomPolygons?.map((room) => ({
      id: room.id,
      polygon: room.polygon,
      type: room.type ?? "unknown",
      source: "manual",
    })),
    walls: surfacesToWalls(input.walls),
    openings,
    objects,
    source: "legacy-web",
  };
}

export type LegacyFloorplanInput = LegacySolverInput;
export const legacyFloorplanToSolverInput = buildSolverInputFromLegacy;
