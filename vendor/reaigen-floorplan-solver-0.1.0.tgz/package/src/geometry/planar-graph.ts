import type { Polygon2, Vec2, WallSegment } from "../types.js";
import { convexHull, ensureCCW, polygonArea, polygonCentroid, segmentIntersection, signedArea, simplifyCollinear } from "./polygon.js";
import { distance, lerp, sub } from "./vector.js";

interface RawSegment {
  id: string;
  a: Vec2;
  b: Vec2;
}

interface Edge {
  a: number;
  b: number;
  sourceIds: string[];
}

function parameterOnSegment(point: Vec2, a: Vec2, b: Vec2): number {
  const d = sub(b, a);
  const denom = d[0] * d[0] + d[1] * d[1];
  if (denom <= 1e-12) return 0;
  return ((point[0] - a[0]) * d[0] + (point[1] - a[1]) * d[1]) / denom;
}

function uniqueNumbers(values: number[], epsilon: number): number[] {
  const sorted = [...values].sort((a, b) => a - b);
  const out: number[] = [];
  for (const value of sorted) {
    if (!out.length || Math.abs(value - (out[out.length - 1] ?? value)) > epsilon) out.push(value);
  }
  return out;
}

/** Split wall segments at T-junctions/crossings before planar face walking. */
function splitSegments(segments: RawSegment[], epsilon: number): RawSegment[] {
  const cuts = segments.map(() => [0, 1]);
  for (let i = 0; i < segments.length; i++) {
    const s0 = segments[i];
    if (!s0) continue;
    for (let j = i + 1; j < segments.length; j++) {
      const s1 = segments[j];
      if (!s1) continue;
      const hit = segmentIntersection(s0.a, s0.b, s1.a, s1.b, epsilon);
      if (hit.point) {
        const t0 = parameterOnSegment(hit.point, s0.a, s0.b);
        const t1 = parameterOnSegment(hit.point, s1.a, s1.b);
        if (t0 > epsilon && t0 < 1 - epsilon) cuts[i]?.push(t0);
        if (t1 > epsilon && t1 < 1 - epsilon) cuts[j]?.push(t1);
      }
      // Collinear overlap: add every endpoint that lies on the opposite segment.
      for (const p of [s0.a, s0.b]) {
        const t = parameterOnSegment(p, s1.a, s1.b);
        const q = lerp(s1.a, s1.b, t);
        if (t > epsilon && t < 1 - epsilon && distance(p, q) <= epsilon) cuts[j]?.push(t);
      }
      for (const p of [s1.a, s1.b]) {
        const t = parameterOnSegment(p, s0.a, s0.b);
        const q = lerp(s0.a, s0.b, t);
        if (t > epsilon && t < 1 - epsilon && distance(p, q) <= epsilon) cuts[i]?.push(t);
      }
    }
  }
  const out: RawSegment[] = [];
  for (let i = 0; i < segments.length; i++) {
    const s = segments[i];
    if (!s) continue;
    const ts = uniqueNumbers(cuts[i] ?? [0, 1], epsilon);
    for (let k = 0; k + 1 < ts.length; k++) {
      const t0 = ts[k];
      const t1 = ts[k + 1];
      if (t0 == null || t1 == null || t1 - t0 <= epsilon) continue;
      const a = lerp(s.a, s.b, t0);
      const b = lerp(s.a, s.b, t1);
      if (distance(a, b) > epsilon) out.push({ id: s.id, a, b });
    }
  }
  return out;
}

function pointKey(p: Vec2, epsilon: number): string {
  return `${Math.round(p[0] / epsilon)},${Math.round(p[1] / epsilon)}`;
}

function dedupeNode(points: Vec2[], buckets: Map<string, number[]>, p: Vec2, epsilon: number): number {
  const ix = Math.round(p[0] / epsilon);
  const iy = Math.round(p[1] / epsilon);
  for (let dx = -1; dx <= 1; dx++) {
    for (let dy = -1; dy <= 1; dy++) {
      const bucket = buckets.get(`${ix + dx},${iy + dy}`) ?? [];
      for (const idx of bucket) {
        const q = points[idx];
        if (q && distance(p, q) <= epsilon) return idx;
      }
    }
  }
  const index = points.length;
  points.push([p[0], p[1]]);
  const key = pointKey(p, epsilon);
  const bucket = buckets.get(key) ?? [];
  bucket.push(index);
  buckets.set(key, bucket);
  return index;
}

function canonicalCycleKey(poly: Polygon2, epsilon: number): string {
  const quantized = poly.map((p) => `${Math.round(p[0] / epsilon)}:${Math.round(p[1] / epsilon)}`);
  let best = "";
  for (let offset = 0; offset < quantized.length; offset++) {
    const rotated = [...quantized.slice(offset), ...quantized.slice(0, offset)].join("|");
    if (!best || rotated < best) best = rotated;
  }
  return best;
}

export interface FaceExtractionResult {
  faces: Polygon2[];
  fallbackHull: Polygon2 | null;
  splitSegments: Array<[Vec2, Vec2]>;
}

/**
 * Extract bounded faces from a wall centre-line graph using a half-edge walk.
 * The traversal chooses the clockwise predecessor of the reverse edge, which
 * keeps each bounded face on the left and produces CCW room cycles.
 */
export function extractWallFaces(
  walls: WallSegment[],
  options: { weldEpsilon?: number; minArea?: number } = {},
): FaceExtractionResult {
  const epsilon = options.weldEpsilon ?? 0.02;
  const minArea = options.minArea ?? 1;
  const raw: RawSegment[] = walls
    .filter((w) => distance(w.p1, w.p2) > epsilon)
    .map((w) => ({ id: w.id, a: [w.p1[0], w.p1[1]], b: [w.p2[0], w.p2[1]] }));
  const split = splitSegments(raw, epsilon * 0.25);
  const points: Vec2[] = [];
  const buckets = new Map<string, number[]>();
  const edgesByKey = new Map<string, Edge>();
  for (const s of split) {
    const a = dedupeNode(points, buckets, s.a, epsilon);
    const b = dedupeNode(points, buckets, s.b, epsilon);
    if (a === b) continue;
    const key = a < b ? `${a}:${b}` : `${b}:${a}`;
    const existing = edgesByKey.get(key);
    if (existing) {
      if (!existing.sourceIds.includes(s.id)) existing.sourceIds.push(s.id);
    } else {
      edgesByKey.set(key, { a: Math.min(a, b), b: Math.max(a, b), sourceIds: [s.id] });
    }
  }
  const edges = [...edgesByKey.values()];
  const adjacency: number[][] = points.map(() => []);
  for (const edge of edges) {
    adjacency[edge.a]?.push(edge.b);
    adjacency[edge.b]?.push(edge.a);
  }
  for (let i = 0; i < adjacency.length; i++) {
    const p = points[i];
    if (!p) continue;
    adjacency[i]?.sort((a, b) => {
      const pa = points[a];
      const pb = points[b];
      if (!pa || !pb) return 0;
      return Math.atan2(pa[1] - p[1], pa[0] - p[0]) - Math.atan2(pb[1] - p[1], pb[0] - p[0]);
    });
  }

  const visited = new Set<string>();
  const faces: Polygon2[] = [];
  const seenCycles = new Set<string>();
  const directedKey = (a: number, b: number) => `${a}>${b}`;
  const maxSteps = Math.max(16, edges.length * 4 + 4);

  for (const edge of edges) {
    for (const [startA, startB] of [
      [edge.a, edge.b],
      [edge.b, edge.a],
    ] as Array<[number, number]>) {
      if (visited.has(directedKey(startA, startB))) continue;
      const cycleIndices: number[] = [];
      let a = startA;
      let b = startB;
      let closed = false;
      for (let step = 0; step < maxSteps; step++) {
        const key = directedKey(a, b);
        if (visited.has(key) && !(a === startA && b === startB)) break;
        visited.add(key);
        cycleIndices.push(a);
        const neighbors = adjacency[b] ?? [];
        const reverseIndex = neighbors.indexOf(a);
        if (reverseIndex < 0 || neighbors.length < 2) break;
        const next = neighbors[(reverseIndex - 1 + neighbors.length) % neighbors.length];
        if (next == null) break;
        a = b;
        b = next;
        if (a === startA && b === startB) {
          closed = true;
          break;
        }
      }
      if (!closed || cycleIndices.length < 3) continue;
      let polygon = cycleIndices.map((idx) => points[idx]).filter((p): p is Vec2 => !!p);
      polygon = simplifyCollinear(polygon, 1e-7);
      const area = signedArea(polygon);
      // With the predecessor rule, bounded faces are CCW and the outer face is clockwise.
      if (area <= minArea) continue;
      polygon = ensureCCW(polygon);
      const cycleKey = canonicalCycleKey(polygon, epsilon);
      if (seenCycles.has(cycleKey)) continue;
      seenCycles.add(cycleKey);
      faces.push(polygon);
    }
  }

  // Remove face duplicates produced by near-coincident wall traces.
  const deduped: Polygon2[] = [];
  for (const face of faces.sort((a, b) => polygonArea(b) - polygonArea(a))) {
    const c = polygonCentroid(face);
    const duplicate = deduped.some((other) => {
      const oc = polygonCentroid(other);
      const areaRatio = polygonArea(face) / Math.max(polygonArea(other), 1e-6);
      return distance(c, oc) < epsilon * 2 && areaRatio > 0.97 && areaRatio < 1.03;
    });
    if (!duplicate) deduped.push(face);
  }

  const fallbackHull = points.length >= 3 ? convexHull(points) : null;
  return {
    faces: deduped,
    fallbackHull: fallbackHull && polygonArea(fallbackHull) >= minArea ? fallbackHull : null,
    splitSegments: split.map((s) => [s.a, s.b]),
  };
}
