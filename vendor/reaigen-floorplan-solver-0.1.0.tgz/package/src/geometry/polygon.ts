import type { Polygon2, Vec2 } from "../types.js";
import { EPS, add, clamp, cross, distance, dot, leftNormal, lerp, normalize, scale, sub } from "./vector.js";

export interface SegmentHit {
  intersects: boolean;
  proper: boolean;
  point?: Vec2;
  t?: number;
  u?: number;
}

export function signedArea(polygon: Polygon2): number {
  let area = 0;
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i];
    const b = polygon[(i + 1) % polygon.length];
    if (!a || !b) continue;
    area += a[0] * b[1] - b[0] * a[1];
  }
  return area / 2;
}

export const polygonArea = (polygon: Polygon2): number => Math.abs(signedArea(polygon));

export function ensureCCW(polygon: Polygon2): Polygon2 {
  const out = polygon.map((p) => [p[0], p[1]] as Vec2);
  return signedArea(out) < 0 ? out.reverse() : out;
}

export function polygonCentroid(polygon: Polygon2): Vec2 {
  if (!polygon.length) return [0, 0];
  const a = signedArea(polygon);
  if (Math.abs(a) <= EPS) {
    const sx = polygon.reduce((sum, p) => sum + p[0], 0);
    const sy = polygon.reduce((sum, p) => sum + p[1], 0);
    return [sx / polygon.length, sy / polygon.length];
  }
  let cx = 0;
  let cy = 0;
  for (let i = 0; i < polygon.length; i++) {
    const p = polygon[i];
    const q = polygon[(i + 1) % polygon.length];
    if (!p || !q) continue;
    const f = p[0] * q[1] - q[0] * p[1];
    cx += (p[0] + q[0]) * f;
    cy += (p[1] + q[1]) * f;
  }
  const factor = 1 / (6 * a);
  return [cx * factor, cy * factor];
}

export function polygonEdges(polygon: Polygon2): Array<[Vec2, Vec2]> {
  const edges: Array<[Vec2, Vec2]> = [];
  for (let i = 0; i < polygon.length; i++) {
    const a = polygon[i];
    const b = polygon[(i + 1) % polygon.length];
    if (a && b) edges.push([a, b]);
  }
  return edges;
}

export function pointOnSegment(point: Vec2, a: Vec2, b: Vec2, epsilon = 1e-7): boolean {
  const ab = sub(b, a);
  const ap = sub(point, a);
  if (Math.abs(cross(ab, ap)) > epsilon * Math.max(1, Math.hypot(ab[0], ab[1]))) return false;
  const d = dot(ap, ab);
  return d >= -epsilon && d <= dot(ab, ab) + epsilon;
}

export function pointInPolygon(point: Vec2, polygon: Polygon2, includeBoundary = true): boolean {
  if (polygon.length < 3) return false;
  let inside = false;
  for (let i = 0, j = polygon.length - 1; i < polygon.length; j = i++) {
    const pi = polygon[i];
    const pj = polygon[j];
    if (!pi || !pj) continue;
    if (pointOnSegment(point, pj, pi)) return includeBoundary;
    const crosses = (pi[1] > point[1]) !== (pj[1] > point[1]);
    if (!crosses) continue;
    const xAtY = ((pj[0] - pi[0]) * (point[1] - pi[1])) / (pj[1] - pi[1]) + pi[0];
    if (point[0] < xAtY) inside = !inside;
  }
  return inside;
}

export function segmentIntersection(a: Vec2, b: Vec2, c: Vec2, d: Vec2, epsilon = 1e-8): SegmentHit {
  const r = sub(b, a);
  const s = sub(d, c);
  const rxs = cross(r, s);
  const cma = sub(c, a);
  const cmaxr = cross(cma, r);
  if (Math.abs(rxs) <= epsilon && Math.abs(cmaxr) <= epsilon) {
    const rr = dot(r, r);
    if (rr <= epsilon) return { intersects: distance(a, c) <= epsilon, proper: false, point: a };
    const t0 = dot(cma, r) / rr;
    const t1 = t0 + dot(s, r) / rr;
    const lo = Math.max(0, Math.min(t0, t1));
    const hi = Math.min(1, Math.max(t0, t1));
    if (hi < lo - epsilon) return { intersects: false, proper: false };
    const t = clamp((lo + hi) / 2, 0, 1);
    return { intersects: true, proper: false, point: lerp(a, b, t), t };
  }
  if (Math.abs(rxs) <= epsilon) return { intersects: false, proper: false };
  const t = cross(cma, s) / rxs;
  const u = cross(cma, r) / rxs;
  if (t < -epsilon || t > 1 + epsilon || u < -epsilon || u > 1 + epsilon) {
    return { intersects: false, proper: false, t, u };
  }
  const proper = t > epsilon && t < 1 - epsilon && u > epsilon && u < 1 - epsilon;
  return { intersects: true, proper, point: lerp(a, b, clamp(t, 0, 1)), t, u };
}

export function polygonsIntersect(a: Polygon2, b: Polygon2, boundaryCounts = true): boolean {
  for (const [a0, a1] of polygonEdges(a)) {
    for (const [b0, b1] of polygonEdges(b)) {
      const hit = segmentIntersection(a0, a1, b0, b1);
      if (hit.proper || (boundaryCounts && hit.intersects)) return true;
    }
  }
  const ap = a[0];
  const bp = b[0];
  return (ap ? pointInPolygon(ap, b, boundaryCounts) : false) || (bp ? pointInPolygon(bp, a, boundaryCounts) : false);
}

export function distancePointToSegment(point: Vec2, a: Vec2, b: Vec2): number {
  const ab = sub(b, a);
  const denom = dot(ab, ab);
  if (denom <= EPS) return distance(point, a);
  const t = clamp(dot(sub(point, a), ab) / denom, 0, 1);
  return distance(point, lerp(a, b, t));
}

export function closestPointOnSegment(point: Vec2, a: Vec2, b: Vec2): Vec2 {
  const ab = sub(b, a);
  const denom = dot(ab, ab);
  if (denom <= EPS) return [a[0], a[1]];
  const t = clamp(dot(sub(point, a), ab) / denom, 0, 1);
  return lerp(a, b, t);
}

export function distanceSegmentToSegment(a: Vec2, b: Vec2, c: Vec2, d: Vec2): number {
  if (segmentIntersection(a, b, c, d).intersects) return 0;
  return Math.min(
    distancePointToSegment(a, c, d),
    distancePointToSegment(b, c, d),
    distancePointToSegment(c, a, b),
    distancePointToSegment(d, a, b),
  );
}

export function simplifyCollinear(polygon: Polygon2, epsilon = 1e-6): Polygon2 {
  if (polygon.length <= 3) return polygon.map((p) => [p[0], p[1]] as Vec2);
  const out: Polygon2 = [];
  for (let i = 0; i < polygon.length; i++) {
    const prev = polygon[(i - 1 + polygon.length) % polygon.length];
    const current = polygon[i];
    const next = polygon[(i + 1) % polygon.length];
    if (!prev || !current || !next) continue;
    const a = normalize(sub(current, prev));
    const b = normalize(sub(next, current));
    if (Math.abs(cross(a, b)) <= epsilon && dot(a, b) > 0) continue;
    out.push([current[0], current[1]]);
  }
  return out;
}

export function convexHull(points: Vec2[]): Polygon2 {
  if (points.length <= 1) return points.map((p) => [p[0], p[1]] as Vec2);
  const sorted = [...points]
    .map((p) => [p[0], p[1]] as Vec2)
    .sort((a, b) => a[0] - b[0] || a[1] - b[1]);
  const unique = sorted.filter((p, i) => i === 0 || p[0] !== sorted[i - 1]?.[0] || p[1] !== sorted[i - 1]?.[1]);
  if (unique.length <= 2) return unique;
  const lower: Vec2[] = [];
  for (const p of unique) {
    while (lower.length >= 2) {
      const a = lower[lower.length - 2];
      const b = lower[lower.length - 1];
      if (!a || !b || cross(sub(b, a), sub(p, b)) > 0) break;
      lower.pop();
    }
    lower.push(p);
  }
  const upper: Vec2[] = [];
  for (let i = unique.length - 1; i >= 0; i--) {
    const p = unique[i];
    if (!p) continue;
    while (upper.length >= 2) {
      const a = upper[upper.length - 2];
      const b = upper[upper.length - 1];
      if (!a || !b || cross(sub(b, a), sub(p, b)) > 0) break;
      upper.pop();
    }
    upper.push(p);
  }
  lower.pop();
  upper.pop();
  return ensureCCW([...lower, ...upper]);
}

function lineIntersectionInfinite(a: Vec2, b: Vec2, c: Vec2, d: Vec2): Vec2 {
  const r = sub(b, a);
  const s = sub(d, c);
  const denom = cross(r, s);
  if (Math.abs(denom) <= EPS) return b;
  const t = cross(sub(c, a), s) / denom;
  return add(a, scale(r, t));
}

/** Sutherland-Hodgman clipping. Both polygons must be convex; clip must be CCW. */
export function clipConvexPolygon(subject: Polygon2, clip: Polygon2): Polygon2 {
  let output = ensureCCW(subject);
  const clipCCW = ensureCCW(clip);
  for (let i = 0; i < clipCCW.length; i++) {
    const cp1 = clipCCW[i];
    const cp2 = clipCCW[(i + 1) % clipCCW.length];
    if (!cp1 || !cp2) continue;
    const input = output;
    output = [];
    if (!input.length) break;
    let s = input[input.length - 1];
    if (!s) continue;
    for (const e of input) {
      const insideE = cross(sub(cp2, cp1), sub(e, cp1)) >= -1e-8;
      const insideS = cross(sub(cp2, cp1), sub(s, cp1)) >= -1e-8;
      if (insideE) {
        if (!insideS) output.push(lineIntersectionInfinite(s, e, cp1, cp2));
        output.push(e);
      } else if (insideS) {
        output.push(lineIntersectionInfinite(s, e, cp1, cp2));
      }
      s = e;
    }
  }
  return simplifyCollinear(output, 1e-7);
}

function isConvexVertex(prev: Vec2, current: Vec2, next: Vec2): boolean {
  return cross(sub(current, prev), sub(next, current)) > 1e-9;
}

function pointInTriangle(p: Vec2, a: Vec2, b: Vec2, c: Vec2): boolean {
  const c1 = cross(sub(b, a), sub(p, a));
  const c2 = cross(sub(c, b), sub(p, b));
  const c3 = cross(sub(a, c), sub(p, c));
  return c1 >= -1e-9 && c2 >= -1e-9 && c3 >= -1e-9;
}

/** Ear-clipping triangulation for a simple polygon. */
export function triangulateSimplePolygon(polygon: Polygon2): Polygon2[] {
  const poly = simplifyCollinear(ensureCCW(polygon));
  if (poly.length < 3) return [];
  if (poly.length === 3) return [poly];
  const indices = poly.map((_, i) => i);
  const triangles: Polygon2[] = [];
  let guard = 0;
  while (indices.length > 3 && guard++ < poly.length * poly.length) {
    let clipped = false;
    for (let k = 0; k < indices.length; k++) {
      const i0 = indices[(k - 1 + indices.length) % indices.length];
      const i1 = indices[k];
      const i2 = indices[(k + 1) % indices.length];
      if (i0 == null || i1 == null || i2 == null) continue;
      const a = poly[i0];
      const b = poly[i1];
      const c = poly[i2];
      if (!a || !b || !c || !isConvexVertex(a, b, c)) continue;
      let contains = false;
      for (const idx of indices) {
        if (idx === i0 || idx === i1 || idx === i2) continue;
        const p = poly[idx];
        if (p && pointInTriangle(p, a, b, c)) {
          contains = true;
          break;
        }
      }
      if (contains) continue;
      triangles.push([a, b, c]);
      indices.splice(k, 1);
      clipped = true;
      break;
    }
    if (!clipped) break;
  }
  if (indices.length === 3) {
    const a = poly[indices[0] ?? 0];
    const b = poly[indices[1] ?? 0];
    const c = poly[indices[2] ?? 0];
    if (a && b && c) triangles.push([a, b, c]);
  }
  return triangles;
}

export function convexPolygonIntersectionArea(convexA: Polygon2, convexB: Polygon2): number {
  return polygonArea(clipConvexPolygon(convexA, convexB));
}

export function convexSimpleIntersectionArea(convex: Polygon2, simple: Polygon2): number {
  let area = 0;
  for (const triangle of triangulateSimplePolygon(simple)) {
    area += convexPolygonIntersectionArea(convex, triangle);
  }
  return area;
}

/** True when a convex footprint is completely inside a possibly concave room. */
export function convexInsideSimple(convex: Polygon2, room: Polygon2, tolerance = 1e-7): boolean {
  if (!convex.length || room.length < 3) return false;
  if (convex.some((p) => !pointInPolygon(p, room, true))) return false;
  for (const [a0, a1] of polygonEdges(convex)) {
    const mid = lerp(a0, a1, 0.5);
    if (!pointInPolygon(mid, room, true)) return false;
    for (const [b0, b1] of polygonEdges(room)) {
      const hit = segmentIntersection(a0, a1, b0, b1, tolerance);
      if (hit.proper) return false;
    }
  }
  return true;
}

export function rectangleAroundSegment(p1: Vec2, p2: Vec2, halfDepth: number, sideExtension = 0): Polygon2 {
  const direction = normalize(sub(p2, p1));
  const normal = leftNormal(direction);
  const a = add(p1, scale(direction, -sideExtension));
  const b = add(p2, scale(direction, sideExtension));
  return ensureCCW([
    add(a, scale(normal, halfDepth)),
    add(b, scale(normal, halfDepth)),
    add(b, scale(normal, -halfDepth)),
    add(a, scale(normal, -halfDepth)),
  ]);
}

export function oneSidedRectangle(
  p1: Vec2,
  p2: Vec2,
  inward: Vec2,
  depth: number,
  sideExtension = 0,
): Polygon2 {
  const direction = normalize(sub(p2, p1));
  const a = add(p1, scale(direction, -sideExtension));
  const b = add(p2, scale(direction, sideExtension));
  const n = normalize(inward);
  return ensureCCW([a, b, add(b, scale(n, depth)), add(a, scale(n, depth))]);
}

export function sectorPolygon(
  center: Vec2,
  startVector: Vec2,
  endVector: Vec2,
  radius: number,
  steps = 12,
): Polygon2 {
  let a0 = Math.atan2(startVector[1], startVector[0]);
  let a1 = Math.atan2(endVector[1], endVector[0]);
  let delta = a1 - a0;
  while (delta > Math.PI) delta -= Math.PI * 2;
  while (delta <= -Math.PI) delta += Math.PI * 2;
  const points: Polygon2 = [[center[0], center[1]]];
  for (let i = 0; i <= steps; i++) {
    const a = a0 + (delta * i) / steps;
    points.push([center[0] + Math.cos(a) * radius, center[1] + Math.sin(a) * radius]);
  }
  return ensureCCW(points);
}

export function polygonBounds(polygon: Polygon2): { minX: number; maxX: number; minY: number; maxY: number } | null {
  if (!polygon.length) return null;
  let minX = polygon[0]?.[0] ?? 0;
  let maxX = minX;
  let minY = polygon[0]?.[1] ?? 0;
  let maxY = minY;
  for (const p of polygon) {
    minX = Math.min(minX, p[0]);
    maxX = Math.max(maxX, p[0]);
    minY = Math.min(minY, p[1]);
    maxY = Math.max(maxY, p[1]);
  }
  return { minX, maxX, minY, maxY };
}
