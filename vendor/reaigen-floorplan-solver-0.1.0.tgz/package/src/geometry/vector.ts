import type { Vec2 } from "../types.js";

export const EPS = 1e-8;

export const add = (a: Vec2, b: Vec2): Vec2 => [a[0] + b[0], a[1] + b[1]];
export const sub = (a: Vec2, b: Vec2): Vec2 => [a[0] - b[0], a[1] - b[1]];
export const scale = (a: Vec2, s: number): Vec2 => [a[0] * s, a[1] * s];
export const dot = (a: Vec2, b: Vec2): number => a[0] * b[0] + a[1] * b[1];
export const cross = (a: Vec2, b: Vec2): number => a[0] * b[1] - a[1] * b[0];
export const lengthSq = (a: Vec2): number => dot(a, a);
export const length = (a: Vec2): number => Math.hypot(a[0], a[1]);
export const distanceSq = (a: Vec2, b: Vec2): number => lengthSq(sub(a, b));
export const distance = (a: Vec2, b: Vec2): number => Math.hypot(a[0] - b[0], a[1] - b[1]);
export const midpoint = (a: Vec2, b: Vec2): Vec2 => [(a[0] + b[0]) / 2, (a[1] + b[1]) / 2];
export const leftNormal = (a: Vec2): Vec2 => [-a[1], a[0]];
export const rightNormal = (a: Vec2): Vec2 => [a[1], -a[0]];
export const clamp = (value: number, low: number, high: number): number => Math.max(low, Math.min(high, value));
export const lerp = (a: Vec2, b: Vec2, t: number): Vec2 => [a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t];

export function normalize(a: Vec2, fallback: Vec2 = [1, 0]): Vec2 {
  const l = length(a);
  return l > EPS ? [a[0] / l, a[1] / l] : [fallback[0], fallback[1]];
}

export function rotate(a: Vec2, radians: number): Vec2 {
  const c = Math.cos(radians);
  const s = Math.sin(radians);
  return [a[0] * c - a[1] * s, a[0] * s + a[1] * c];
}

export function rotateAround(point: Vec2, pivot: Vec2, radians: number): Vec2 {
  return add(pivot, rotate(sub(point, pivot), radians));
}

export function angleOf(a: Vec2): number {
  return Math.atan2(a[1], a[0]);
}

export function wrapAngle(radians: number): number {
  let value = radians;
  while (value > Math.PI) value -= Math.PI * 2;
  while (value <= -Math.PI) value += Math.PI * 2;
  return value;
}

export function unsignedAxisAngle(a: Vec2, b: Vec2): number {
  const na = normalize(a);
  const nb = normalize(b);
  const cosine = clamp(Math.abs(dot(na, nb)), -1, 1);
  return Math.acos(cosine);
}

export function yawDelta(a: Vec2, b: Vec2): number {
  const raw = Math.abs(wrapAngle(angleOf(a) - angleOf(b)));
  return Math.min(raw, Math.abs(Math.PI - raw));
}

export function almostEqual(a: number, b: number, epsilon = 1e-6): boolean {
  return Math.abs(a - b) <= epsilon;
}

export function pointAlmostEqual(a: Vec2, b: Vec2, epsilon = 1e-6): boolean {
  return distanceSq(a, b) <= epsilon * epsilon;
}

export function projectPointToLine(point: Vec2, origin: Vec2, direction: Vec2): number {
  return dot(sub(point, origin), normalize(direction));
}
