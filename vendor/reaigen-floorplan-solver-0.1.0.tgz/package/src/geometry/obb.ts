import type { FurniturePose, Polygon2, Vec2 } from "../types.js";
import { add, distance, dot, normalize, scale, sub, yawDelta } from "./vector.js";
import { clipConvexPolygon, convexPolygonIntersectionArea, distancePointToSegment, polygonArea, polygonEdges } from "./polygon.js";

export function normalizePose<T extends FurniturePose>(pose: T): T {
  const w = normalize(pose.axisW);
  let d = normalize(pose.axisD, [-w[1], w[0]]);
  // Re-orthogonalize because RoomPlan matrices can carry slight numerical drift.
  d = normalize(sub(d, scale(w, dot(d, w))), [-w[1], w[0]]);
  return { ...pose, axisW: w, axisD: d };
}

export function obbCorners(pose: FurniturePose, inflate = 0): Polygon2 {
  const o = normalizePose(pose);
  const hw = Math.max(0, o.halfW + inflate);
  const hd = Math.max(0, o.halfD + inflate);
  const corner = (sw: number, sd: number): Vec2 =>
    add(o.center, add(scale(o.axisW, hw * sw), scale(o.axisD, hd * sd)));
  return [corner(-1, -1), corner(1, -1), corner(1, 1), corner(-1, 1)];
}

export function poseArea(pose: FurniturePose): number {
  return 4 * pose.halfW * pose.halfD;
}

export function poseYaw(pose: FurniturePose): number {
  return Math.atan2(pose.axisW[1], pose.axisW[0]);
}

export function poseDisplacement(a: FurniturePose, b: FurniturePose): number {
  return distance(a.center, b.center);
}

export function poseYawDelta(a: FurniturePose, b: FurniturePose): number {
  return yawDelta(a.axisW, b.axisW);
}

export function expandedPose(pose: FurniturePose, amount: number): FurniturePose {
  return { ...pose, halfW: Math.max(0, pose.halfW + amount), halfD: Math.max(0, pose.halfD + amount) };
}

export function obbIntersectionArea(a: FurniturePose, b: FurniturePose, inflate = 0): number {
  return convexPolygonIntersectionArea(obbCorners(a, inflate), obbCorners(b, inflate));
}

export function obbContainmentRatio(smaller: FurniturePose, larger: FurniturePose): number {
  const area = poseArea(smaller);
  if (area <= 1e-9) return 0;
  return obbIntersectionArea(smaller, larger) / area;
}

export interface SatResult {
  overlaps: boolean;
  minDepth: number;
  axis: Vec2;
}

function projection(poly: Polygon2, axis: Vec2): [number, number] {
  let lo = dot(poly[0] ?? [0, 0], axis);
  let hi = lo;
  for (let i = 1; i < poly.length; i++) {
    const value = dot(poly[i] ?? [0, 0], axis);
    lo = Math.min(lo, value);
    hi = Math.max(hi, value);
  }
  return [lo, hi];
}

export function obbSat(a: FurniturePose, b: FurniturePose, inflate = 0): SatResult {
  const A = normalizePose(a);
  const B = normalizePose(b);
  const polyA = obbCorners(A, inflate);
  const polyB = obbCorners(B, inflate);
  const axes = [A.axisW, A.axisD, B.axisW, B.axisD];
  let minDepth = Number.POSITIVE_INFINITY;
  let bestAxis: Vec2 = [1, 0];
  for (const axisRaw of axes) {
    const axis = normalize(axisRaw);
    const [a0, a1] = projection(polyA, axis);
    const [b0, b1] = projection(polyB, axis);
    const depth = Math.min(a1, b1) - Math.max(a0, b0);
    if (depth <= 0) return { overlaps: false, minDepth: 0, axis };
    if (depth < minDepth) {
      minDepth = depth;
      bestAxis = axis;
    }
  }
  return { overlaps: true, minDepth, axis: bestAxis };
}

export function obbDistanceToSegment(pose: FurniturePose, a: Vec2, b: Vec2): number {
  const corners = obbCorners(pose);
  const clipped = clipConvexPolygon(corners, [a, b, b, a]);
  void clipped;
  let min = Number.POSITIVE_INFINITY;
  for (const p of corners) min = Math.min(min, distancePointToSegment(p, a, b));
  for (const [p0, p1] of polygonEdges(corners)) {
    min = Math.min(min, distancePointToSegment(a, p0, p1), distancePointToSegment(b, p0, p1));
  }
  return min;
}

export function polygonPoseIntersectionArea(polygon: Polygon2, pose: FurniturePose): number {
  return polygonArea(clipConvexPolygon(obbCorners(pose), polygon));
}

export function poseWithAxes(
  source: FurniturePose,
  axisW: Vec2,
  axisD: Vec2,
  swapExtents = false,
): FurniturePose {
  return {
    center: [source.center[0], source.center[1]],
    axisW: normalize(axisW),
    axisD: normalize(axisD),
    halfW: swapExtents ? source.halfD : source.halfW,
    halfD: swapExtents ? source.halfW : source.halfD,
  };
}

/** Rectangle extending from an object's semantic front edge (+axisD). */
export function frontClearancePolygon(
  pose: FurniturePose,
  depth: number,
  sideMargin = 0.04,
): Polygon2 {
  const o = normalizePose(pose);
  const halfWidth = o.halfW + Math.max(0, sideMargin);
  const front = add(o.center, scale(o.axisD, o.halfD));
  const far = add(front, scale(o.axisD, Math.max(0, depth)));
  return [
    add(front, scale(o.axisW, -halfWidth)),
    add(front, scale(o.axisW, halfWidth)),
    add(far, scale(o.axisW, halfWidth)),
    add(far, scale(o.axisW, -halfWidth)),
  ];
}
