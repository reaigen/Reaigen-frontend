# Third-party dataset notice

This package contains analysis scripts only. It does not include ProcTHOR-10K, ARKitScenes, Apple RoomPlan scan content, or derived full-dataset statistics.

## ProcTHOR-10K

Repository: https://github.com/allenai/procthor-10k

Consult the repository's current license before use or redistribution.

## ARKitScenes

Repository: https://github.com/apple/ARKitScenes

The official repository directs users to its `LICENSE` file and lists `ARKitScenes-license@group.apple.com` for licensing questions. Review those terms before commercial use, redistribution, or publication of derived data.

## Apple SDK output

RoomPlan/ARKit API usage and exported scan data remain subject to Apple SDK terms, platform policies, and the consent/privacy requirements of the Reaigen product.
