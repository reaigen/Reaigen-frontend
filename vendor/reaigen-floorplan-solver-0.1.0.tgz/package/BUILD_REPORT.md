# Build and verification report

Package: `@reaigen/floorplan-solver`

Version: `0.1.0`

Build date: `2026-08-05`

## Verification completed

The delivered source was compiled and tested in the package directory with Node.js 20+ compatible ESM output and TypeScript strict checking.

```text
npm run check
  typecheck: passed
  TypeScript build: passed
  Node regression tests: 14 passed, 0 failed
  Python mining/extraction script syntax check: passed

npm run test:fuzz
  randomized scenes: 500
  invalid strict outputs: 0

extended deterministic fuzz run
  randomized scenes: 1,200
  invalid strict outputs: 0
  accepted observations: 3,010
  rejected observations: 6,667
  merged observations: 435
```

The extended fuzz run used seed `42424242`. The package fuzz command uses seed `987654321`.

The generated npm tarball was then installed into a clean temporary project. Both the public ESM library export and the packaged `reaigen-floorplan-solve` CLI completed a strict valid solve.

## Demonstration fixture

`fixtures/apartment-chaos.json` intentionally contains overlapping storage, an object outside the room, a chair/table conflict, a door obstruction, and noisy orientations. The production strict solve produced:

```text
observations: 9
accepted: 6
rejected: 2
merged: 1
validation.valid: true
```

Generated outputs are in `examples/output/`.

## Regression coverage

The automated suite covers:

1. bounded room-face extraction from wall graphs;
2. storage relocation away from a door swing;
3. storage-storage non-overlap;
4. chair placement at a legal table-facing slot;
5. RoomPlan Codable parsing of categories, floor polygons, and parent relations;
6. deterministic output;
7. wall-only room polygonization;
8. concave-room containment rejection;
9. conservative unknown-door handling;
10. fail-closed handling outside all rooms;
11. duplicate storage merging with explanations;
12. `CapturedStructure` section-to-room mapping;
13. cabinet and appliance operational-front clearance;
14. navigation repair by relocating or rejecting a fixture that disconnects a door approach.

## Included runtime paths

- pure TypeScript library and declarations;
- Node/Next.js server usage;
- browser Web Worker client;
- React/Next.js hook;
- Apple RoomPlan Codable JSON parser;
- legacy Reaigen `ObjectXZ` adapter;
- command-line solver;
- iOS JSON + USDZ + metadata export helper;
- integration notes for the provided Viewer and Editor;
- ProcTHOR-10K and ARKitScenes analysis scripts;
- USDZ geometry fallback extractor;
- fixtures, SVG/PNG debug output, and regression tests.

## Dataset boundary

No ProcTHOR-10K or ARKitScenes dataset files are redistributed. The packaged priors are conservative bootstrap engineering defaults. Reproducible mining scripts are included so Reaigen can generate and review versioned priors inside an environment where the relevant dataset licenses and access requirements have been satisfied.

## Production boundary

The solver is designed to fail closed for furniture placement. It does not certify building-code or life-safety compliance. Architectural topology that cannot produce a valid room polygon is reported through diagnostics and should be repaired by the editor or backend preprocessing rather than hidden by furniture relocation.
