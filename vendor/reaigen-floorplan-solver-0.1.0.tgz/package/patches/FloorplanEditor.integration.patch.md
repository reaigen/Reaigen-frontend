# `FloorplanEditor.tsx` integration

The editor must solve furniture against the **live** wall graph and openings. The current implementation solves against `base.initialGraph` and `base.geom?.doors`, so edited walls and custom/deleted openings do not affect furniture.

## 1. Import the adapter

```ts
import { solveReaigenFloorplan } from "../lib/reaigen-floorplan-adapter";
```

## 2. Replace the stale furniture memo

Replace:

```ts
const furniture = useMemo(
  () =>
    solveFurnitureLayout(
      prepareObjects(base.geom?.objects ?? [], computeBounds(base.initialGraph.vertices)),
      graphSegs(base.initialGraph),
      base.geom?.interiorCentroid ?? [0, 0],
      base.geom?.doors ?? []
    ),
  [base]
);
```

with:

```ts
const furnitureSolve = useMemo(
  () =>
    solveReaigenFloorplan({
      walls: segs,
      doors,
      windows,
      objects: base.geom?.objects ?? [],
      doorConfigs,
      options: {
        strict: true,
        runNavigationRepair: true,
      },
    }),
  [segs, doors, windows, base.geom?.objects, doorConfigs],
);

const furniture = furnitureSolve.objects;
```

This memo belongs **after** the current `segs`, `doors`, and `windows` derivations.

## 3. Recompute after the 300 ms wall persistence debounce

Rendering may solve immediately from local state. Persistence remains debounced. The visual plan therefore reacts during editing without waiting for the backend:

```text
pointer edit → graph/opening state → constrained solve → render
                              ↘ 300 ms saveDraftDataFields
```

## 4. Surface invalid input instead of drawing nonsense

The strict solver should normally return `validation.valid === true` because it rejects unsalvageable observations. Still show an editor warning when the room geometry itself is invalid:

```tsx
{!furnitureSolve.result.validation.valid && (
  <div role="alert" className="absolute right-3 top-3 rounded-xl bg-red-50 px-3 py-2 text-xs text-red-700">
    Floorplan geometry needs repair before furniture can be placed safely.
  </div>
)}
```

Use `result.objects[].reasons` in a selected-object inspector so a user can see, for example, “Packed into a legal wall interval that excludes doors and windows” or “Rejected because no physically valid placement exists.”
