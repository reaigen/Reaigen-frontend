# `FloorplanViewer.tsx` integration

The runtime solver replaces the old `prepareObjects(...) → solveFurnitureLayout(...)` nudge pipeline. Walls, openings and furniture must all be passed in the same snapped RoomPlan XZ frame, before the user-facing `floorplan_rotation_degrees` transform.

## 1. Import the adapter

Place `integration/reaigen-floorplan-adapter.ts` in the app, for example as `app/lib/reaigen-floorplan-adapter.ts`, then import it:

```ts
import { solveReaigenFloorplan } from "../lib/reaigen-floorplan-adapter";
```

Remove `prepareObjects` and `solveFurnitureLayout` from the `floorplan-geometry` import after all callers have migrated.

## 2. Replace the furniture solve in `buildLocalModel`

Replace:

```ts
const rawObjects = geom?.objects ?? [];
const solvedObjects = solveFurnitureLayout(
  prepareObjects(rawObjects, preBounds),
  wallSegs,
  geom?.interiorCentroid ?? pivot,
  doors
);
const objectsR = solvedObjects.map(rotObj);
```

with:

```ts
const rawObjects = geom?.objects ?? [];
const furnitureSolve = solveReaigenFloorplan({
  walls: wallSegs,
  doors,
  windows,
  objects: rawObjects,
  doorConfigs: parseDoorConfigs(textData),
  // Room polygons are optional here. When absent, the engine polygonizes the
  // closed edited wall graph. Pass RoomPlan floor polygons when available.
  options: {
    strict: true,
    runNavigationRepair: true,
  },
});

const objectsR = furnitureSolve.objects.map(rotObj);
```

The solver result should also be retained in `LocalModel` while developing:

```ts
interface LocalModel {
  // ...existing fields...
  furnitureDiagnostics: SolveResult["diagnostics"];
  furnitureValidation: SolveResult["validation"];
}
```

and returned as:

```ts
furnitureDiagnostics: furnitureSolve.result.diagnostics,
furnitureValidation: furnitureSolve.result.validation,
```

Do not render objects with `status === "rejected"` or `status === "merged"`; the adapter already removes them. This is deliberate fail-closed behavior: an omitted uncertain box is preferable to storage outside the apartment or across a door.

## 3. Keep the raw debug overlay

The existing `?fpdebug=1` red dashed boxes remain useful. They show the original RoomPlan observations, while the solid symbols show constrained output. Add the solver reason in the debug panel from `result.objects[].reasons` when diagnosing a scene.
