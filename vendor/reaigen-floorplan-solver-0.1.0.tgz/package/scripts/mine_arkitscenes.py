#!/usr/bin/env python3
"""Mine real size, orientation and overlap priors from ARKitScenes 3DOD JSON."""
from __future__ import annotations
import argparse, json, math
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any

ALIASES = {
 "bed":["bed"],"sofa":["sofa","couch"],"chair":["chair","stool"],"table":["table","desk"],
 "storage":["cabinet","shelf","storage","wardrobe","dresser"],"refrigerator":["refrigerator","fridge"],
 "stove":["stove"],"oven":["oven"],"dishwasher":["dishwasher"],"washerDryer":["washer","dryer"],
 "sink":["sink"],"toilet":["toilet"],"bathtub":["bathtub","tub"],"fireplace":["fireplace"],
 "television":["television","tv"],"stairs":["stairs"]}

def kind(label:str)->str|None:
 t=label.lower().replace("_","").replace(" ","")
 for k,aa in ALIASES.items():
  if any(a.replace("_","") in t for a in aa): return k
 return None

def quant(v:list[float],p:float):
 if not v:return None
 v=sorted(v);x=(len(v)-1)*p;i=int(x);j=min(i+1,len(v)-1);return v[i]*(j-x)+v[j]*(x-i)

def matrix(raw:Any)->list[list[float]]:
 if isinstance(raw,list) and len(raw)==3 and all(isinstance(r,list) for r in raw): return [[float(x) for x in r] for r in raw]
 flat=[float(x) for x in raw] if isinstance(raw,list) else []
 return [flat[0:3],flat[3:6],flat[6:9]] if len(flat)>=9 else [[1,0,0],[0,1,0],[0,0,1]]

def poly(center,axes,half,up:int,layout:str):
 floor=[i for i in range(3) if i!=up]
 def axis(j): return [axes[j][floor[0]],axes[j][floor[1]]] if layout=="rows" else [axes[floor[0]][j],axes[floor[1]][j]]
 a=axis(floor[0]);b=axis(floor[1]); la=math.hypot(*a) or 1;lb=math.hypot(*b) or 1;a=[a[0]/la,a[1]/la];b=[b[0]/lb,b[1]/lb]
 c=[center[floor[0]],center[floor[1]]];ha=half[floor[0]];hb=half[floor[1]]
 return [[c[0]+a[0]*ha*s+b[0]*hb*t,c[1]+a[1]*ha*s+b[1]*hb*t] for s,t in [(-1,-1),(1,-1),(1,1),(-1,1)]],a

def clip(subject,clipper):
 def cross(a,b,c):return (b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0])
 def inter(a,b,c,d):
  rx,ry=b[0]-a[0],b[1]-a[1];sx,sy=d[0]-c[0],d[1]-c[1];den=rx*sy-ry*sx
  if abs(den)<1e-12:return b
  t=((c[0]-a[0])*sy-(c[1]-a[1])*sx)/den;return [a[0]+t*rx,a[1]+t*ry]
 out=subject[:]
 for i,c in enumerate(clipper):
  d=clipper[(i+1)%len(clipper)];inp=out;out=[]
  if not inp:break
  s=inp[-1]
  for e in inp:
   ie=cross(c,d,e)>=-1e-9;is_=cross(c,d,s)>=-1e-9
   if ie:
    if not is_:out.append(inter(s,e,c,d))
    out.append(e)
   elif is_:out.append(inter(s,e,c,d))
   s=e
 return out

def area(p):return abs(sum(p[i][0]*p[(i+1)%len(p)][1]-p[(i+1)%len(p)][0]*p[i][1] for i in range(len(p)))/2) if len(p)>=3 else 0

def main():
 ap=argparse.ArgumentParser();ap.add_argument("root",type=Path);ap.add_argument("output",type=Path);ap.add_argument("--up-axis",choices=["x","y","z"],default="y");ap.add_argument("--matrix-layout",choices=["rows","columns"],default="columns");ap.add_argument("--max-scenes",type=int,default=0);args=ap.parse_args()
 up="xyz".index(args.up_axis); dims=defaultdict(lambda:defaultdict(list));yaw=defaultdict(list);count=Counter();same_overlap=0;same_pairs=0;cross_contain=0;scenes=0;pairdist=defaultdict(list)
 for path in sorted(args.root.rglob("*_3dod_annotation.json")):
  if args.max_scenes and scenes>=args.max_scenes:break
  try:data=json.loads(path.read_text())
  except Exception:continue
  boxes=[]
  for item in data.get("data",[]):
   k=kind(str(item.get("label",""))); lengths=item.get("axesLengths");cent=item.get("centroid")
   if not k or not isinstance(lengths,list) or len(lengths)<3 or not isinstance(cent,list) or len(cent)<3:continue
   lengths=[abs(float(x)) for x in lengths[:3]];cent=[float(x) for x in cent[:3]];axes=matrix(item.get("normalizedAxes"));p,a=poly(cent,axes,[x/2 for x in lengths],up,args.matrix_layout)
   floor=[i for i in range(3) if i!=up]; w,d=sorted([lengths[floor[0]],lengths[floor[1]]],reverse=True);h=lengths[up]
   dims[k]["width"].append(w);dims[k]["depth"].append(d);dims[k]["height"].append(h);count[k]+=1
   theta=math.atan2(a[1],a[0]);res=abs(((theta+math.pi/4)%(math.pi/2))-math.pi/4);yaw[k].append(math.degrees(res));boxes.append((k,p,cent))
  for i,(ka,pa,ca) in enumerate(boxes):
   for kb,pb,cb in boxes[i+1:]:
    inter=area(clip(pa,pb));mina=min(area(pa),area(pb))
    if ka==kb:
     same_pairs+=1
     if inter>0.003:same_overlap+=1
    elif mina and inter/mina>0.85:cross_contain+=1
    pair="|".join(sorted((ka,kb)))
    if pair in {"chair|table","sofa|television","bed|table","sofa|table"}:pairdist[pair].append(math.dist(ca,cb))
  scenes+=1
 out={"source":"ARKitScenes-3DOD","scenes":scenes,"boxes":sum(count.values()),"sameLabelOverlapRate":same_overlap/same_pairs if same_pairs else None,"crossLabelContainmentPairs":cross_contain,"kinds":{},"pairs":{}}
 for k in sorted(count):
  out["kinds"][k]={"count":count[k],"widthP02":quant(dims[k]["width"],.02),"widthMedian":quant(dims[k]["width"],.5),"widthP98":quant(dims[k]["width"],.98),"depthP02":quant(dims[k]["depth"],.02),"depthMedian":quant(dims[k]["depth"],.5),"depthP98":quant(dims[k]["depth"],.98),"heightP02":quant(dims[k]["height"],.02),"heightP98":quant(dims[k]["height"],.98),"yawResidualP90Deg":quant(yaw[k],.9),"yawWithin5Deg":sum(x<=5 for x in yaw[k])/len(yaw[k]) if yaw[k] else None,"yawWithin10Deg":sum(x<=10 for x in yaw[k])/len(yaw[k]) if yaw[k] else None}
 for p,v in sorted(pairdist.items()):out["pairs"][p]={"count":len(v),"p10":quant(v,.1),"median":quant(v,.5),"p90":quant(v,.9)}
 args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(out,indent=2,sort_keys=True));print(f"wrote {args.output} from {scenes} scenes")
if __name__=="__main__":main()
