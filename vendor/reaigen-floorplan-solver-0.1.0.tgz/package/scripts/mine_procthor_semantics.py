#!/usr/bin/env python3
"""Mine reproducible layout semantics from the public ProcTHOR-10K houses.

The house JSON references asset IDs but does not embed asset bounding boxes.
This miner therefore emits only facts supported by the release: room polygons,
object roles/centres, doors and relative distances. Physical dimensions must be
merged from an asset database or a separately licensed ARKitScenes export.
"""

from __future__ import annotations

import argparse
import collections
import gzip
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Iterable


TABLE_ROLES = {
    "DiningTable": "dining",
    "CoffeeTable": "coffee",
    "SideTable": "side",
    "Desk": "desk",
}
DINING_SEATS = {"Chair", "Stool"}


def percentile(values: list[float], fraction: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = (len(ordered) - 1) * fraction
    low = math.floor(index)
    high = math.ceil(index)
    if low == high:
        return ordered[low]
    return ordered[low] * (high - index) + ordered[high] * (index - low)


def summary(values: list[float]) -> dict[str, float | int | None]:
    return {
        "count": len(values),
        "p10": percentile(values, 0.10),
        "median": percentile(values, 0.50),
        "p75": percentile(values, 0.75),
        "p90": percentile(values, 0.90),
    }


def point(object_: dict[str, Any]) -> tuple[float, float] | None:
    position = object_.get("position") or {}
    if "x" not in position or "z" not in position:
        return None
    return float(position["x"]), float(position["z"])


def object_type(object_: dict[str, Any]) -> str:
    return str(object_.get("id", "")).split("|", 1)[0]


def polygon(room: dict[str, Any]) -> list[tuple[float, float]]:
    return [(float(p["x"]), float(p["z"])) for p in room.get("floorPolygon", []) if "x" in p and "z" in p]


def polygon_area(points: list[tuple[float, float]]) -> float:
    return abs(sum(
        points[i][0] * points[(i + 1) % len(points)][1]
        - points[(i + 1) % len(points)][0] * points[i][1]
        for i in range(len(points))
    )) / 2 if len(points) >= 3 else 0.0


def point_in_polygon(p: tuple[float, float], points: list[tuple[float, float]]) -> bool:
    if len(points) < 3:
        return False
    inside = False
    x, y = p
    j = len(points) - 1
    for i, (xi, yi) in enumerate(points):
        xj, yj = points[j]
        intersects = ((yi > y) != (yj > y)) and x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi
        if intersects:
            inside = not inside
        j = i
    return inside


def distance(a: dict[str, Any], b: dict[str, Any]) -> float:
    pa, pb = point(a), point(b)
    if pa is None or pb is None:
        return math.inf
    return math.hypot(pa[0] - pb[0], pa[1] - pb[1])


def nearest_distances(
    sources: Iterable[dict[str, Any]],
    targets: list[dict[str, Any]],
    cutoff: float | None = None,
) -> list[float]:
    values: list[float] = []
    for source in sources:
        nearest = min((distance(source, target) for target in targets), default=math.inf)
        if math.isfinite(nearest) and (cutoff is None or nearest <= cutoff):
            values.append(nearest)
    return values


def stream_houses(path: Path) -> Iterable[dict[str, Any]]:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--max-houses", type=int, default=10_000)
    args = parser.parse_args()

    type_counts: collections.Counter[str] = collections.Counter()
    role_room_counts: dict[str, collections.Counter[str]] = collections.defaultdict(collections.Counter)
    room_areas: dict[str, list[float]] = collections.defaultdict(list)
    room_vertices: dict[str, list[float]] = collections.defaultdict(list)
    room_door_counts: dict[str, list[float]] = collections.defaultdict(list)
    chair_table_distances: list[float] = []
    chairs_per_table: list[float] = []
    coffee_sofa_distances: list[float] = []
    side_anchor_distances: list[float] = []
    sofa_tv_distances: list[float] = []
    houses = 0

    for house in stream_houses(args.input):
        if houses >= args.max_houses:
            break
        houses += 1
        objects = [o for o in house.get("objects", []) if point(o) is not None]
        for object_ in objects:
            type_counts[object_type(object_)] += 1
        door_counts: collections.Counter[str] = collections.Counter()
        for door in house.get("doors", []):
            for room_id in {door.get("room0"), door.get("room1")} - {None}:
                door_counts[str(room_id)] += 1

        for room in house.get("rooms", []):
            points = polygon(room)
            room_type = str(room.get("roomType", "Unknown"))
            room_id = str(room.get("id", ""))
            room_areas[room_type].append(polygon_area(points))
            room_vertices[room_type].append(float(len(points)))
            room_door_counts[room_type].append(float(door_counts[room_id]))
            members = [o for o in objects if point_in_polygon(point(o), points)]  # type: ignore[arg-type]
            by_type: dict[str, list[dict[str, Any]]] = collections.defaultdict(list)
            for object_ in members:
                by_type[object_type(object_)].append(object_)
                role = TABLE_ROLES.get(object_type(object_))
                if role:
                    role_room_counts[role][room_type] += 1

            dining = by_type["DiningTable"]
            seats = by_type["Chair"] + by_type["Stool"]
            chair_table_distances.extend(nearest_distances(seats, dining, cutoff=2.4))
            for table in dining:
                assigned = 0
                for seat in seats:
                    nearest = min(dining, key=lambda value: (distance(seat, value), str(value.get("id", ""))))
                    if nearest is table and distance(seat, table) <= 2.4:
                        assigned += 1
                chairs_per_table.append(float(assigned))

            sofas = by_type["Sofa"]
            beds = by_type["Bed"]
            televisions = by_type["Television"]
            coffee_sofa_distances.extend(nearest_distances(by_type["CoffeeTable"], sofas, cutoff=3.5))
            side_anchor_distances.extend(nearest_distances(by_type["SideTable"], sofas + beds, cutoff=3.5))
            sofa_tv_distances.extend(nearest_distances(sofas, televisions, cutoff=7.0))

    digest = hashlib.sha256(args.input.read_bytes()).hexdigest()
    role_rooms = {
        role: {
            "count": sum(counts.values()),
            "probability": {
                room: count / sum(counts.values())
                for room, count in sorted(counts.items())
            },
        }
        for role, counts in sorted(role_room_counts.items())
    }
    output = {
        "schemaVersion": 1,
        "source": {
            "name": "ProcTHOR-10K",
            "url": "https://github.com/allenai/procthor-10k",
            "sha256": digest,
            "houses": houses,
        },
        "geometryAvailability": {
            "objectDimensions": False,
            "reason": "Public house JSON references assetId but does not embed asset bounding boxes.",
        },
        "objectTypeCounts": dict(sorted(type_counts.items())),
        "tableRoles": role_rooms,
        "relations": {
            "nearestDiningSeatCenterDistanceMetres": summary(chair_table_distances),
            "chairsPerDiningTable": summary(chairs_per_table),
            "nearestCoffeeTableSofaCenterDistanceMetres": summary(coffee_sofa_distances),
            "nearestSideTableSofaOrBedCenterDistanceMetres": summary(side_anchor_distances),
            "nearestSofaTelevisionCenterDistanceMetres": summary(sofa_tv_distances),
        },
        "roomGeometry": {
            room_type: {
                "areaSquareMetres": summary(values),
                "polygonVertexCount": summary(room_vertices[room_type]),
                "doorCount": summary(room_door_counts[room_type]),
            }
            for room_type, values in sorted(room_areas.items())
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"wrote {args.output} from {houses} houses")


if __name__ == "__main__":
    main()
