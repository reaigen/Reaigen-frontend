# Data and utility scripts

All dataset-mining scripts use only the Python standard library. The USDZ fallback additionally requires Pixar USD Python bindings (`pxr`).

## ProcTHOR

```bash
python mine_procthor.py /path/to/train.jsonl.gz ../data/generated/procthor.json
```

The input may be a repository `*.jsonl.gz` split or a JSON export from the `prior` package.

## ARKitScenes

```bash
python mine_arkitscenes.py /path/to/ARKitScenes ../data/generated/arkitscenes.json
```

The script recursively finds `*_3dod_annotation.json`. Verify `--up-axis` and `--matrix-layout` against the annotation version before freezing priors:

```bash
python mine_arkitscenes.py ROOT OUTPUT --up-axis y --matrix-layout columns
```

## Merge

```bash
python merge_priors.py \
  ../data/generated/procthor.json \
  ../data/generated/arkitscenes.json \
  ../data/generated/runtime-priors.json
```

Review low-count categories and all dimensional outliers. Generated values are runtime overrides, not automatic truth.

## USDZ fallback

```bash
python extract_roomplan_usdz.py scan.usdz solver-input.json --pretty
```

Prefer Codable RoomPlan JSON. The USDZ extractor is approximate and requires compatible Pixar USD bindings.

## SVG debug render

```bash
node render_solution_svg.mjs solved.json solved.svg
```
