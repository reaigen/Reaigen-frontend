#!/usr/bin/env python3
"""Convert MLStructFP metre-scaled wall/slab annotations to solver fixtures."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any


def point_in_polygon(point: tuple[float, float], polygon: list[list[float]]) -> bool:
    x, y = point
    inside = False
    j = len(polygon) - 1
    for i, (xi, yi) in enumerate(polygon):
        xj, yj = polygon[j]
        if ((yi > y) != (yj > y)) and x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi:
            inside = not inside
        j = i
    return inside


def segment_distance(point: tuple[float, float], a: list[float], b: list[float]) -> float:
    px, py = point
    ax, ay = a
    bx, by = b
    dx, dy = bx - ax, by - ay
    length2 = dx * dx + dy * dy
    t = max(0.0, min(1.0, ((px - ax) * dx + (py - ay) * dy) / length2)) if length2 else 0.0
    return math.hypot(px - (ax + t * dx), py - (ay + t * dy))


def wall_centerline(identifier: str, rect: dict[str, Any], room_id: str) -> dict[str, Any]:
    xs = [float(value) for value in rect["x"]]
    ys = [float(value) for value in rect["y"]]
    center = [sum(xs) / len(xs), sum(ys) / len(ys)]
    angle_value = rect.get("angle", 0)
    # Square junction rectangles can expose both equivalent principal axes.
    # Either centreline is valid because thickness equals length.
    if isinstance(angle_value, list):
        angle_value = angle_value[0] if angle_value else 0
    angle = math.radians(float(angle_value))
    length = float(rect["length"])
    direction = [math.cos(angle), math.sin(angle)]
    return {
        "id": f"mlstructfp-wall-{identifier}",
        "p1": [center[0] - direction[0] * length / 2, center[1] - direction[1] * length / 2],
        "p2": [center[0] + direction[0] * length / 2, center[1] + direction[1] * length / 2],
        "thickness": float(rect.get("thickness", 0.18)),
        "roomIds": [room_id],
    }


def free_probe(polygon: list[list[float]], walls: list[dict[str, Any]]) -> dict[str, Any] | None:
    if len(polygon) < 3:
        return None
    xs = [point[0] for point in polygon]
    ys = [point[1] for point in polygon]
    boundary = list(zip(polygon, polygon[1:] + polygon[:1]))
    best: tuple[float, tuple[float, float]] | None = None
    step = 0.3
    y = min(ys) + step / 2
    while y < max(ys):
        x = min(xs) + step / 2
        while x < max(xs):
            candidate = (x, y)
            if point_in_polygon(candidate, polygon):
                wall_clearance = min(
                    (segment_distance(candidate, wall["p1"], wall["p2"]) - float(wall["thickness"]) / 2 for wall in walls),
                    default=math.inf,
                )
                edge_clearance = min(segment_distance(candidate, a, b) for a, b in boundary)
                clearance = min(wall_clearance, edge_clearance)
                if best is None or clearance > best[0]:
                    best = (clearance, candidate)
            x += step
        y += step
    if best is None:
        return None
    return {"center": [best[1][0], best[1][1]], "clearance": best[0]}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    raw = args.input.read_bytes()
    data = json.loads(raw)
    scenes: list[dict[str, Any]] = []
    for floor_key, floor in sorted(data.get("floor", {}).items(), key=lambda entry: int(entry[0])):
        floor_id = int(floor_key)
        slabs = [value for value in data.get("slab", {}).values() if int(value["floorID"]) == floor_id]
        if not slabs:
            continue
        slab = max(slabs, key=lambda value: len(value.get("x", [])))
        polygon = [[float(x), float(y)] for x, y in zip(slab["x"], slab["y"])]
        room_id = f"mlstructfp-floor-{floor_id}"
        walls = [
            wall_centerline(identifier, rect, room_id)
            for identifier, rect in data.get("rect", {}).items()
            if int(rect["floorID"]) == floor_id
        ]
        scenes.append({
            "id": room_id,
            "sourceImage": floor.get("image"),
            "pixelsPerMetre": floor.get("scale"),
            "rooms": [{
                "id": room_id,
                "polygon": polygon,
                "type": "unknown",
                "source": "manual",
            }],
            "walls": walls,
            "openings": [],
            "objects": [],
            "probe": free_probe(polygon, walls),
            "source": "canonical",
        })
    output = {
        "schemaVersion": 1,
        "provenance": {
            "name": "MLStructFP bundled test annotations",
            "repository": "https://github.com/MLSTRUCT/MLStructFP",
            "license": "MIT",
            "inputSha256": hashlib.sha256(raw).hexdigest(),
        },
        "scenes": scenes,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"wrote {len(scenes)} MLStructFP architecture scenes to {args.output}")


if __name__ == "__main__":
    main()
