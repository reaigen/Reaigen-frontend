#!/usr/bin/env node

import { readFile, writeFile } from "node:fs/promises";

const [inputPath, outputPath] = process.argv.slice(2);
if (!inputPath || !outputPath) {
  console.error("Usage: node scripts/render_solution_svg.mjs <solved.json> <output.svg>");
  process.exit(2);
}

const result = JSON.parse(await readFile(inputPath, "utf8"));
const points = [];
for (const room of result.rooms ?? []) points.push(...(room.polygon ?? []));
for (const wall of result.walls ?? []) points.push(wall.p1, wall.p2);
for (const opening of result.openings ?? []) points.push(opening.p1, opening.p2);
for (const zone of result.keepOuts ?? []) points.push(...(zone.polygon ?? []));
for (const object of result.objects ?? []) {
  if (object.sourcePose) points.push(...corners(object.sourcePose));
  if (!['rejected', 'merged'].includes(object.status)) points.push(...corners(object));
}
if (!points.length) throw new Error("No drawable geometry in solve result.");

let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
for (const [x, y] of points) {
  minX = Math.min(minX, x); maxX = Math.max(maxX, x);
  minY = Math.min(minY, y); maxY = Math.max(maxY, y);
}
const spanX = Math.max(maxX - minX, 1);
const spanY = Math.max(maxY - minY, 1);
const W = 1200;
const H = Math.max(600, Math.min(1000, Math.round(W * spanY / spanX)));
const pad = 70;
const scale = Math.min((W - 2 * pad) / spanX, (H - 2 * pad) / spanY);
const project = ([x, y]) => [pad + (x - minX) * scale, pad + (y - minY) * scale];
const poly = (value) => value.map((p) => project(p).map((n) => n.toFixed(2)).join(',')).join(' ');
const esc = (value) => String(value).replace(/[&<>"']/g, (ch) => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));

function corners(pose) {
  const { center: c, axisW: w, axisD: d, halfW: hw, halfD: hd } = pose;
  return [[-1,-1],[1,-1],[1,1],[-1,1]].map(([sw, sd]) => [
    c[0] + w[0] * hw * sw + d[0] * hd * sd,
    c[1] + w[1] * hw * sw + d[1] * hd * sd,
  ]);
}

const keepOutColors = {
  'door-threshold': '#fee2e2',
  'door-approach': '#ffedd5',
  'door-swing': '#fef3c7',
  'sliding-door-travel': '#fef3c7',
  'opening-approach': '#ffedd5',
  'window-tall-object': '#dbeafe',
};

const svg = [];
svg.push(`<?xml version="1.0" encoding="UTF-8"?>`);
svg.push(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">`);
svg.push(`<rect width="100%" height="100%" fill="#ffffff"/>`);
svg.push(`<g font-family="Inter, ui-sans-serif, system-ui, sans-serif">`);

for (const room of result.rooms ?? []) {
  svg.push(`<polygon points="${poly(room.polygon)}" fill="#fafafa" stroke="#d4d4d8" stroke-width="1.5"/>`);
}
for (const zone of result.keepOuts ?? []) {
  const fill = keepOutColors[zone.kind] ?? '#f3f4f6';
  svg.push(`<polygon points="${poly(zone.polygon)}" fill="${fill}" fill-opacity="0.42" stroke="#9ca3af" stroke-width="1" stroke-dasharray="6 5"><title>${esc(zone.reason)}</title></polygon>`);
}
for (const wall of result.walls ?? []) {
  const [x1, y1] = project(wall.p1); const [x2, y2] = project(wall.p2);
  svg.push(`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#111827" stroke-width="${Math.max(9, scale * 0.18)}" stroke-linecap="square"/>`);
}
for (const opening of result.openings ?? []) {
  const [x1, y1] = project(opening.p1); const [x2, y2] = project(opening.p2);
  svg.push(`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="#ffffff" stroke-width="${Math.max(12, scale * 0.24)}"/>`);
  svg.push(`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" stroke="${opening.kind === 'window' ? '#2563eb' : '#111827'}" stroke-width="2.2"/>`);
}

for (const object of result.objects ?? []) {
  if (!object.sourcePose) continue;
  const [cx, cy] = project(object.sourcePose.center);
  svg.push(`<polygon points="${poly(corners(object.sourcePose))}" fill="none" stroke="#dc2626" stroke-width="2" stroke-dasharray="8 6" opacity="0.68"/>`);
  svg.push(`<text x="${cx}" y="${cy - 7}" text-anchor="middle" font-size="15" fill="#dc2626" opacity="0.82">raw ${esc(object.category)}</text>`);
}
for (const object of result.objects ?? []) {
  if (['rejected', 'merged'].includes(object.status)) continue;
  const [cx, cy] = project(object.center);
  const reason = (object.reasons ?? []).join(' ');
  svg.push(`<polygon points="${poly(corners(object))}" fill="#ffffff" fill-opacity="0.92" stroke="#374151" stroke-width="2.4"><title>${esc(reason)}</title></polygon>`);
  svg.push(`<text x="${cx}" y="${cy + 5}" text-anchor="middle" font-size="16" font-weight="650" fill="#111827">${esc(object.category)}</text>`);
  svg.push(`<text x="${cx}" y="${cy + 23}" text-anchor="middle" font-size="12" fill="#6b7280">${esc(object.status)} · ${esc(object.candidateSource ?? '')}</text>`);
}
for (const object of result.objects ?? []) {
  if (!['rejected', 'merged'].includes(object.status) || !object.sourcePose) continue;
  const [cx, cy] = project(object.sourcePose.center);
  svg.push(`<text x="${cx}" y="${cy + 20}" text-anchor="middle" font-size="13" font-weight="700" fill="#b91c1c">${esc(object.status)}</text>`);
}

const summary = `valid=${result.validation?.valid} · accepted=${result.diagnostics?.acceptedObjectCount ?? 0} · rejected=${result.diagnostics?.rejectedObjectCount ?? 0} · merged=${result.diagnostics?.deduplicatedObjectCount ?? 0}`;
svg.push(`<rect x="20" y="18" width="${Math.min(W - 40, 610)}" height="38" rx="12" fill="#ffffff" stroke="#d4d4d8"/>`);
svg.push(`<text x="38" y="43" font-size="16" font-weight="650" fill="#111827">${esc(summary)}</text>`);
svg.push(`<g transform="translate(${W - 360},22)">`);
svg.push(`<line x1="0" y1="8" x2="42" y2="8" stroke="#dc2626" stroke-width="2" stroke-dasharray="8 6"/><text x="52" y="13" font-size="13" fill="#374151">raw RoomPlan box</text>`);
svg.push(`<rect x="185" y="0" width="42" height="16" fill="#fff" stroke="#374151" stroke-width="2"/><text x="237" y="13" font-size="13" fill="#374151">solved box</text>`);
svg.push(`</g>`);
svg.push(`</g></svg>`);

await writeFile(outputPath, `${svg.join('\n')}\n`, 'utf8');
console.error(`wrote ${outputPath}`);
