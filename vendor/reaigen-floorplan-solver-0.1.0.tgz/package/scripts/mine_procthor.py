#!/usr/bin/env python3
"""Mine semantic 2D layout priors from ProcTHOR-10K house JSON.

The script accepts the repository's *.jsonl.gz files or JSON exported by the
`prior` package. ProcTHOR house files do not always include asset extents; room
occupancy and pair statistics are still emitted, while wall-gap/size fields are
reported only when bounds are present in the chosen dataset revision.
"""

from __future__ import annotations

import argparse
import gzip
import json
import math
import statistics
from collections import Counter, defaultdict
from pathlib import Path
from typing import Any, Iterable, Iterator

KINDS = {
    "bed": ["bed"], "sofa": ["sofa", "couch"], "chair": ["chair", "stool"],
    "table": ["table", "desk"], "storage": ["cabinet", "storage", "shelf", "dresser", "wardrobe", "closet"],
    "refrigerator": ["fridge", "refrigerator"], "stove": ["stove", "cooktop"], "oven": ["oven"],
    "dishwasher": ["dishwasher"], "washerDryer": ["washer", "dryer", "washingmachine"],
    "sink": ["sink"], "toilet": ["toilet"], "bathtub": ["bathtub", "tub", "shower"],
    "fireplace": ["fireplace"], "television": ["television", "tv"], "stairs": ["stairs", "staircase"],
}
ROOM_TYPES = ["livingRoom", "bedroom", "bathroom", "kitchen", "diningRoom", "hallway", "office", "laundry", "storage", "unknown"]


def q(values: list[float], p: float) -> float | None:
    if not values:
        return None
    data = sorted(values)
    x = (len(data) - 1) * p
    lo = int(math.floor(x)); hi = int(math.ceil(x))
    if lo == hi: return data[lo]
    return data[lo] * (hi - x) + data[hi] * (x - lo)


def iter_records(path: Path) -> Iterator[dict[str, Any]]:
    opener = gzip.open if path.suffix == ".gz" else open
    with opener(path, "rt", encoding="utf-8") as handle:
        first = handle.read(1); handle.seek(0)
        if first == "[" or first == "{":
            try:
                value = json.load(handle)
                if isinstance(value, list):
                    yield from (x for x in value if isinstance(x, dict))
                elif isinstance(value, dict):
                    for key in ("train", "val", "test", "houses", "data"):
                        if isinstance(value.get(key), list):
                            yield from (x for x in value[key] if isinstance(x, dict)); return
                    yield value
                return
            except json.JSONDecodeError:
                handle.seek(0)
        for line in handle:
            line = line.strip()
            if line:
                value = json.loads(line)
                if isinstance(value, dict): yield value


def point(raw: Any) -> tuple[float, float] | None:
    if isinstance(raw, dict):
        try: return float(raw.get("x", 0)), float(raw.get("z", raw.get("y", 0)))
        except Exception: return None
    if isinstance(raw, (list, tuple)) and len(raw) >= 2:
        return float(raw[0]), float(raw[2] if len(raw) >= 3 else raw[1])
    return None


def room_type(raw: Any) -> str:
    text = str(raw or "").lower()
    if "living" in text: return "livingRoom"
    if "bed" in text: return "bedroom"
    if "bath" in text: return "bathroom"
    if "kitchen" in text: return "kitchen"
    if "dining" in text: return "diningRoom"
    if "hall" in text: return "hallway"
    if "office" in text: return "office"
    if "laundry" in text: return "laundry"
    if "storage" in text: return "storage"
    return "unknown"


def kind_of(obj: dict[str, Any]) -> str | None:
    text = " ".join(str(obj.get(k, "")) for k in ("objectType", "assetId", "id", "name", "type")).lower().replace("_", "")
    for kind, aliases in KINDS.items():
        if any(alias.replace("_", "") in text for alias in aliases): return kind
    return None


def polygon(raw: Any) -> list[tuple[float, float]]:
    if not isinstance(raw, list): return []
    return [p for item in raw if (p := point(item)) is not None]


def inside(p: tuple[float, float], poly: list[tuple[float, float]]) -> bool:
    if len(poly) < 3: return False
    x, y = p; result = False
    j = len(poly) - 1
    for i in range(len(poly)):
        xi, yi = poly[i]; xj, yj = poly[j]
        if ((yi > y) != (yj > y)) and x < (xj - xi) * (y - yi) / ((yj - yi) or 1e-12) + xi:
            result = not result
        j = i
    return result


def distance_segment(p: tuple[float, float], a: tuple[float, float], b: tuple[float, float]) -> float:
    px, py = p; ax, ay = a; bx, by = b
    dx, dy = bx - ax, by - ay; den = dx*dx + dy*dy
    t = 0 if den == 0 else max(0, min(1, ((px-ax)*dx + (py-ay)*dy)/den))
    return math.hypot(px-(ax+t*dx), py-(ay+t*dy))


def size_of(obj: dict[str, Any]) -> tuple[float, float] | None:
    candidates = [obj.get("dimensions"), obj.get("size")]
    for key in ("axisAlignedBoundingBox", "boundingBox", "objectOrientedBoundingBox"):
        value = obj.get(key)
        if isinstance(value, dict): candidates += [value.get("size"), value.get("dimensions")]
    for value in candidates:
        if isinstance(value, dict):
            try: return abs(float(value.get("x"))), abs(float(value.get("z", value.get("y"))))
            except Exception: pass
        if isinstance(value, (list, tuple)) and len(value) >= 2:
            try: return abs(float(value[0])), abs(float(value[2] if len(value) >= 3 else value[1]))
            except Exception: pass
    return None


def yaw_of(obj: dict[str, Any]) -> float:
    rotation = obj.get("rotation", {})
    if isinstance(rotation, dict): return math.radians(float(rotation.get("y", rotation.get("z", 0)) or 0))
    if isinstance(rotation, (int, float)): return math.radians(float(rotation))
    return 0.0


def flatten_objects(values: Any) -> Iterable[dict[str, Any]]:
    if not isinstance(values, list): return
    for obj in values:
        if not isinstance(obj, dict): continue
        yield obj
        yield from flatten_objects(obj.get("children"))


def rooms_of(house: dict[str, Any]) -> list[dict[str, Any]]:
    result = []
    for idx, room in enumerate(house.get("rooms", []) if isinstance(house.get("rooms"), list) else []):
        if not isinstance(room, dict): continue
        poly = polygon(room.get("floorPolygon") or room.get("polygon") or room.get("floor"))
        if len(poly) < 3: continue
        result.append({"id": str(room.get("id", idx)), "type": room_type(room.get("roomType") or room.get("type")), "polygon": poly})
    return result


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("input", type=Path)
    ap.add_argument("output", type=Path)
    ap.add_argument("--max-houses", type=int, default=0)
    args = ap.parse_args()

    kind_count = Counter(); room_count = Counter(); room_kind = defaultdict(Counter)
    wall_gaps = defaultdict(list); yaw_residual = defaultdict(list); widths = defaultdict(list); depths = defaultdict(list)
    pair_distances = defaultdict(list)
    houses = rooms_total = missing_size = 0

    for house in iter_records(args.input):
        if args.max_houses and houses >= args.max_houses: break
        houses += 1
        rooms = rooms_of(house); rooms_total += len(rooms)
        for room in rooms: room_count[room["type"]] += 1
        by_room: dict[str, list[tuple[str, tuple[float,float], float]]] = defaultdict(list)
        for obj in flatten_objects(house.get("objects")):
            kind = kind_of(obj); pos = point(obj.get("position"))
            if not kind or not pos: continue
            containing = next((r for r in rooms if inside(pos, r["polygon"])), None)
            if not containing: continue
            kind_count[kind] += 1; room_kind[kind][containing["type"]] += 1
            yaw = yaw_of(obj); by_room[containing["id"]].append((kind, pos, yaw))
            size = size_of(obj)
            if not size:
                missing_size += 1; continue
            w, d = sorted(size, reverse=True); widths[kind].append(w); depths[kind].append(d)
            poly = containing["polygon"]
            best_gap = float("inf"); best_edge_yaw = 0.0
            for i, a in enumerate(poly):
                b = poly[(i+1)%len(poly)]
                edge_yaw = math.atan2(b[1]-a[1], b[0]-a[0])
                normal = (-math.sin(edge_yaw), math.cos(edge_yaw))
                half_normal = abs(math.cos(yaw)*normal[0] + math.sin(yaw)*normal[1])*w/2 + abs(-math.sin(yaw)*normal[0] + math.cos(yaw)*normal[1])*d/2
                gap = distance_segment(pos, a, b) - half_normal
                if gap < best_gap: best_gap, best_edge_yaw = gap, edge_yaw
            wall_gaps[kind].append(best_gap)
            delta = abs(((yaw-best_edge_yaw + math.pi/4) % (math.pi/2)) - math.pi/4)
            yaw_residual[kind].append(math.degrees(delta))

        for entries in by_room.values():
            for i, (ka, pa, _) in enumerate(entries):
                for kb, pb, _ in entries[i+1:]:
                    pair = "|".join(sorted((ka, kb)))
                    if pair in {"chair|table", "sofa|television", "bed|table", "sofa|table"}:
                        pair_distances[pair].append(math.dist(pa, pb))

    result: dict[str, Any] = {
        "source": "ProcTHOR-10K", "houses": houses, "rooms": rooms_total,
        "objects": sum(kind_count.values()), "objectsMissingSize": missing_size,
        "kinds": {}, "pairs": {},
    }
    for kind in sorted(kind_count):
        gaps = wall_gaps[kind]
        total = kind_count[kind]
        room_probs = {rt: room_kind[kind][rt]/total for rt in ROOM_TYPES if room_kind[kind][rt]}
        result["kinds"][kind] = {
            "count": total,
            "wallAffinity": (sum(g <= 0.15 for g in gaps)/len(gaps)) if gaps else None,
            "backGapMedian": q([max(0,g) for g in gaps], .5),
            "backGapP90": q([max(0,g) for g in gaps], .9),
            "yawResidualP90Deg": q(yaw_residual[kind], .9),
            "widthMedian": q(widths[kind], .5), "depthMedian": q(depths[kind], .5),
            "roomProbability": room_probs,
        }
    for pair, values in sorted(pair_distances.items()):
        result["pairs"][pair] = {"count": len(values), "p10": q(values,.1), "median": q(values,.5), "p90": q(values,.9)}

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True), encoding="utf-8")
    print(f"wrote {args.output} from {houses} houses")
    return 0

if __name__ == "__main__": raise SystemExit(main())
