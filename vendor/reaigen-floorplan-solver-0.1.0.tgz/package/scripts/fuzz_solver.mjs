#!/usr/bin/env node

import { solveFloorplan } from "../dist/index.js";

const sceneCount = Math.max(1, Number(process.argv[2] ?? 500));
let seed = Number(process.argv[3] ?? 987654321) >>> 0;
const random = () => ((seed = (1664525 * seed + 1013904223) >>> 0) / 2 ** 32);
const kinds = ["storage", "table", "chair", "sofa", "bed", "refrigerator", "generic", "washerDryer", "sink"];
const stats = { scenes: 0, invalid: 0, accepted: 0, rejected: 0, merged: 0, maximumMs: 0 };

for (let sceneIndex = 0; sceneIndex < sceneCount; sceneIndex++) {
  const width = 2.6 + random() * 8;
  const depth = 2.6 + random() * 7;
  const room = { id: "room", polygon: [[0, 0], [width, 0], [width, depth], [0, depth]], type: "unknown", source: "manual" };
  const walls = [
    { id: "bottom", p1: [0, 0], p2: [width, 0] },
    { id: "right", p1: [width, 0], p2: [width, depth] },
    { id: "top", p1: [width, depth], p2: [0, depth] },
    { id: "left", p1: [0, depth], p2: [0, 0] },
  ];
  const side = Math.floor(random() * 4);
  let p1;
  let p2;
  if (side === 0) {
    const x = 0.4 + random() * Math.max(0.1, width - 1.3);
    p1 = [x, 0]; p2 = [Math.min(width - 0.05, x + 0.9), 0];
  } else if (side === 1) {
    const y = 0.4 + random() * Math.max(0.1, depth - 1.3);
    p1 = [width, y]; p2 = [width, Math.min(depth - 0.05, y + 0.9)];
  } else if (side === 2) {
    const x = 0.4 + random() * Math.max(0.1, width - 1.3);
    p1 = [x, depth]; p2 = [Math.min(width - 0.05, x + 0.9), depth];
  } else {
    const y = 0.4 + random() * Math.max(0.1, depth - 1.3);
    p1 = [0, y]; p2 = [0, Math.min(depth - 0.05, y + 0.9)];
  }

  const objectCount = 1 + Math.floor(random() * 16);
  const objects = Array.from({ length: objectCount }, (_, index) => {
    const kind = kinds[Math.floor(random() * kinds.length)];
    const angle = random() * Math.PI * 2;
    return {
      id: `object-${index}`,
      category: kind,
      kind,
      center: [-1 + random() * (width + 2), -1 + random() * (depth + 2)],
      axisW: [Math.cos(angle), Math.sin(angle)],
      axisD: [-Math.sin(angle), Math.cos(angle)],
      halfW: 0.12 + random() * 1.3,
      halfD: 0.12 + random() * 1.2,
      height: 0.2 + random() * 2.6,
      confidence: random(),
    };
  });

  const result = solveFloorplan({
    rooms: [room],
    walls,
    openings: [{ id: "door", kind: "door", p1, p2 }],
    objects,
    source: "canonical",
  });
  stats.scenes += 1;
  stats.accepted += result.diagnostics.acceptedObjectCount;
  stats.rejected += result.diagnostics.rejectedObjectCount;
  stats.merged += result.diagnostics.deduplicatedObjectCount;
  stats.maximumMs = Math.max(stats.maximumMs, result.diagnostics.elapsedMs);
  if (!result.validation.valid) {
    stats.invalid += 1;
    console.error(JSON.stringify({ sceneIndex, input: { room, walls, p1, p2, objects }, validation: result.validation }, null, 2));
    process.exitCode = 1;
    break;
  }
}

console.log(JSON.stringify(stats, null, 2));
