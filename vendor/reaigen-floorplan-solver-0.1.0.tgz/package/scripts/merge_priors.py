#!/usr/bin/env python3
"""Merge ProcTHOR and ARKitScenes statistics into a runtime SolverOptions override."""
from __future__ import annotations
import argparse,json
from pathlib import Path

def clamp(x,lo,hi):return max(lo,min(hi,x))
def main():
 ap=argparse.ArgumentParser();ap.add_argument("procthor",type=Path);ap.add_argument("arkitscenes",type=Path);ap.add_argument("output",type=Path);args=ap.parse_args()
 p=json.loads(args.procthor.read_text());a=json.loads(args.arkitscenes.read_text());kinds={}
 for kind in sorted(set(p.get("kinds",{}))|set(a.get("kinds",{}))):
  pk=p.get("kinds",{}).get(kind,{}) or {};ak=a.get("kinds",{}).get(kind,{}) or {};out={}
  if pk.get("wallAffinity") is not None:out["wallAffinity"]=round(pk["wallAffinity"],4)
  if pk.get("backGapMedian") is not None:out["backGap"]=round(clamp(pk["backGapMedian"],0,0.25),4)
  if ak.get("yawResidualP90Deg") is not None:out["yawSnapDeg"]=round(clamp(ak["yawResidualP90Deg"],4,15),2)
  for src,dst in [("widthP02","minWidth"),("widthP98","maxWidth"),("depthP02","minDepth"),("depthP98","maxDepth"),("heightP02","minHeight"),("heightP98","maxHeight")]:
   if ak.get(src) is not None:out[dst]=round(float(ak[src]),3)
  probs=pk.get("roomProbability",{}) or {}
  if probs:
   best=max(probs.values())
   out["roomWeights"]={room:round(clamp(0.25*best/max(prob,1e-5),0.25,5),3) for room,prob in probs.items()}
  kinds[kind]=out
 result={"kinds":kinds,"metadata":{"procthorHouses":p.get("houses"),"arkitScenes":a.get("scenes"),"generatedBy":"scripts/merge_priors.py"}}
 args.output.parent.mkdir(parents=True,exist_ok=True);args.output.write_text(json.dumps(result,indent=2,sort_keys=True));print(f"wrote {args.output}")
if __name__=="__main__":main()
