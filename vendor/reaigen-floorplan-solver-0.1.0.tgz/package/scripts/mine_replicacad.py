#!/usr/bin/env python3
"""Mine authored large-furniture layout priors from ReplicaCAD scene JSON."""

from __future__ import annotations

import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
from typing import Any


def percentile(values: list[float], fraction: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    index = (len(ordered) - 1) * fraction
    low, high = math.floor(index), math.ceil(index)
    if low == high:
        return ordered[low]
    return ordered[low] * (high - index) + ordered[high] * (index - low)


def summary(values: list[float]) -> dict[str, float | int | None]:
    return {
        "count": len(values),
        "p10": percentile(values, 0.10),
        "median": percentile(values, 0.50),
        "p75": percentile(values, 0.75),
        "p90": percentile(values, 0.90),
    }


def category(name: str) -> str | None:
    value = name.lower()
    if "chair" in value or "stool" in value or "beanbag" in value:
        return "chair"
    if "table" in value:
        return "table"
    if "sofa" in value:
        return "sofa"
    if "tv_screen" in value or "television" in value or "monitor" in value:
        return "television"
    if "cabinet" in value or "cupboard" in value or "drawer" in value or "tvstand" in value:
        return "storage"
    if "fridge" in value or "refrigerator" in value:
        return "refrigerator"
    return None


def yaw(rotation: list[float]) -> float:
    # Habitat scene-instance quaternions use [w, x, y, z]. Project the full
    # quaternion to rotation about the Y-up axis.
    w, x, y, z = (rotation + [0.0, 0.0, 0.0, 0.0])[:4]
    return math.atan2(2 * (w * y + x * z), 1 - 2 * (y * y + z * z))


def yaw_residual_degrees(value: float) -> float:
    quarter = math.pi / 2
    return abs(value - round(value / quarter) * quarter) * 180 / math.pi


def planar_distance(a: dict[str, Any], b: dict[str, Any]) -> float:
    return math.hypot(a["x"] - b["x"], a["z"] - b["z"])


def relative_axis_degrees(a: float, b: float) -> float:
    delta = abs((a - b) % math.pi)
    return min(delta, math.pi - delta) * 180 / math.pi


def instances(scene: dict[str, Any]) -> list[dict[str, Any]]:
    result: list[dict[str, Any]] = []
    for raw in [*scene.get("object_instances", []), *scene.get("articulated_object_instances", [])]:
        name = str(raw.get("template_name", ""))
        kind = category(name)
        translation = raw.get("translation", [0, 0, 0])
        rotation = raw.get("rotation", [1, 0, 0, 0])
        if not kind or len(translation) < 3:
            continue
        result.append({
            "name": name,
            "kind": kind,
            "x": float(translation[0]),
            "y": float(translation[1]),
            "z": float(translation[2]),
            "yaw": yaw([float(value) for value in rotation]),
        })
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path, help="Directory containing *.scene_instance.json")
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    paths = sorted(args.input.glob("*.scene_instance.json"))
    kind_counts: collections.Counter[str] = collections.Counter()
    template_counts: collections.Counter[str] = collections.Counter()
    yaw_residuals: dict[str, list[float]] = collections.defaultdict(list)
    pair_distances: dict[str, list[float]] = collections.defaultdict(list)
    pair_axis_deltas: dict[str, list[float]] = collections.defaultdict(list)
    digester = hashlib.sha256()

    pair_specs = [
        ("chair", "table"),
        ("table", "sofa"),
        ("sofa", "television"),
        ("television", "storage"),
    ]
    for path in paths:
        raw = path.read_bytes()
        digester.update(path.name.encode("utf-8"))
        digester.update(raw)
        scene = json.loads(raw)
        objects = instances(scene)
        by_kind: dict[str, list[dict[str, Any]]] = collections.defaultdict(list)
        for object_ in objects:
            by_kind[object_["kind"]].append(object_)
            kind_counts[object_["kind"]] += 1
            template_counts[object_["name"]] += 1
            yaw_residuals[object_["kind"]].append(yaw_residual_degrees(object_["yaw"]))
        for a_kind, b_kind in pair_specs:
            targets = by_kind[b_kind]
            for source in by_kind[a_kind]:
                if not targets:
                    continue
                target = min(targets, key=lambda value: (planar_distance(source, value), value["name"]))
                key = f"nearest{a_kind.title()}{b_kind.title()}"
                pair_distances[key].append(planar_distance(source, target))
                pair_axis_deltas[key].append(relative_axis_degrees(source["yaw"], target["yaw"]))

    output = {
        "schemaVersion": 1,
        "source": {
            "name": "ReplicaCAD Interactive",
            "url": "https://aihabitat.org/datasets/replica_cad/",
            "license": "CC-BY-4.0",
            "sceneCount": len(paths),
            "layoutSha256": digester.hexdigest(),
        },
        "scope": "Artist-authored large-furniture arrangements from one apartment family; use as composition evidence, not population statistics.",
        "kindCounts": dict(sorted(kind_counts.items())),
        "templateCounts": dict(sorted(template_counts.items())),
        "cardinalYawResidualDegrees": {
            kind: summary(values) for kind, values in sorted(yaw_residuals.items())
        },
        "nearestPairCenterDistanceMetres": {
            key: summary(values) for key, values in sorted(pair_distances.items())
        },
        "nearestPairAxisDifferenceDegrees": {
            key: summary(values) for key, values in sorted(pair_axis_deltas.items())
        },
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    print(f"wrote {args.output} from {len(paths)} artist-authored scenes")


if __name__ == "__main__":
    main()
