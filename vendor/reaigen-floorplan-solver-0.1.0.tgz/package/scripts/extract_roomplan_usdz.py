#!/usr/bin/env python3
"""Fallback RoomPlan USDZ -> canonical solver JSON extractor.

Use CapturedRoom/CapturedStructure Codable JSON whenever it is available. USDZ
is a render/interchange container and can omit semantic information depending
on export options. This utility uses Pixar USD (`pip install usd-core`) to group
RoomPlan-like prim names, project geometry to XZ, and recover approximate OBBs.

Output matches @reaigen/floorplan-solver's SolverInput shape.
"""

from __future__ import annotations

import argparse
import json
import math
import re
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable

try:
    from pxr import Gf, Usd, UsdGeom
except Exception as exc:  # pragma: no cover - environment-specific
    raise SystemExit(
        "Pixar USD Python bindings are required. Install a compatible `usd-core` "
        "wheel or run this script in an environment that ships `pxr`."
    ) from exc


FURNITURE_ALIASES = {
    "bed": ["bed"],
    "sofa": ["sofa", "couch"],
    "chair": ["chair", "stool"],
    "table": ["table", "desk"],
    "storage": ["storage", "cabinet", "wardrobe", "closet", "shelf"],
    "refrigerator": ["refrigerator", "fridge"],
    "stove": ["stove", "cooktop"],
    "oven": ["oven"],
    "dishwasher": ["dishwasher"],
    "washerDryer": ["washer", "dryer", "washingmachine"],
    "sink": ["sink"],
    "toilet": ["toilet", "wc"],
    "bathtub": ["bathtub", "tub", "shower"],
    "fireplace": ["fireplace"],
    "television": ["television", "tv"],
    "stairs": ["stairs", "staircase"],
}


def tokens(path: str) -> list[str]:
    return [t for t in re.split(r"[^a-z0-9]+", path.lower()) if t]


def semantic(path: str) -> tuple[str, str] | None:
    ts = tokens(path)
    joined = "".join(ts)
    for kind in ("door", "window", "opening", "wall"):
        if kind in ts or kind in joined:
            return (kind, kind)
    for kind, aliases in FURNITURE_ALIASES.items():
        if any(alias in ts or alias in joined for alias in aliases):
            return ("object", kind)
    return None


def nearest_semantic_ancestor(prim: Any) -> tuple[str, str, str] | None:
    current = prim
    while current and current.IsValid() and current.GetPath().pathString != "/":
        found = semantic(current.GetPath().pathString)
        if found:
            return current.GetPath().pathString, found[0], found[1]
        current = current.GetParent()
    return None


def world_points(mesh_prim: Any, cache: Any) -> Iterable[tuple[float, float, float]]:
    mesh = UsdGeom.Mesh(mesh_prim)
    values = mesh.GetPointsAttr().Get() or []
    transform = cache.GetLocalToWorldTransform(mesh_prim)
    for value in values:
        p = transform.Transform(Gf.Vec3d(float(value[0]), float(value[1]), float(value[2])))
        yield (float(p[0]), float(p[1]), float(p[2]))


def pca_obb_xz(points: list[tuple[float, float, float]]) -> dict[str, Any] | None:
    if len(points) < 2:
        return None
    xs = [p[0] for p in points]
    ys = [p[1] for p in points]
    zs = [p[2] for p in points]
    cx = sum(xs) / len(xs)
    cz = sum(zs) / len(zs)
    sxx = sum((x - cx) ** 2 for x in xs) / len(xs)
    szz = sum((z - cz) ** 2 for z in zs) / len(zs)
    sxz = sum((x - cx) * (z - cz) for x, z in zip(xs, zs)) / len(xs)
    theta = 0.5 * math.atan2(2 * sxz, sxx - szz)
    ux, uz = math.cos(theta), math.sin(theta)
    vx, vz = -uz, ux
    us = [(x - cx) * ux + (z - cz) * uz for x, z in zip(xs, zs)]
    vs = [(x - cx) * vx + (z - cz) * vz for x, z in zip(xs, zs)]
    u0, u1 = min(us), max(us)
    v0, v1 = min(vs), max(vs)
    center = [cx + ux * (u0 + u1) / 2 + vx * (v0 + v1) / 2,
              cz + uz * (u0 + u1) / 2 + vz * (v0 + v1) / 2]
    return {
        "center": center,
        "axisW": [ux, uz],
        "axisD": [vx, vz],
        "halfW": max((u1 - u0) / 2, 0.01),
        "halfD": max((v1 - v0) / 2, 0.01),
        "height": max(ys) - min(ys),
        "centerY": (max(ys) + min(ys)) / 2,
    }


def endpoint_surface(obb: dict[str, Any]) -> tuple[list[float], list[float]]:
    # Use the long floor axis as the wall/opening span.
    if obb["halfD"] > obb["halfW"]:
        axis = obb["axisD"]
        half = obb["halfD"]
    else:
        axis = obb["axisW"]
        half = obb["halfW"]
    c = obb["center"]
    return (
        [c[0] - axis[0] * half, c[1] - axis[1] * half],
        [c[0] + axis[0] * half, c[1] + axis[1] * half],
    )


def stable_id(path: str) -> str:
    value = path.strip("/").replace("/", "-").replace("_", "-").lower()
    return re.sub(r"[^a-z0-9-]+", "-", value) or "prim"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("usdz", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--pretty", action="store_true")
    args = parser.parse_args()

    stage = Usd.Stage.Open(str(args.usdz))
    if stage is None:
        raise SystemExit(f"Unable to open USD/USDZ stage: {args.usdz}")
    cache = UsdGeom.XformCache(Usd.TimeCode.Default())
    groups: dict[tuple[str, str, str], list[tuple[float, float, float]]] = defaultdict(list)

    for prim in stage.Traverse():
        if not prim.IsA(UsdGeom.Mesh):
            continue
        ancestor = nearest_semantic_ancestor(prim)
        if not ancestor:
            continue
        groups[ancestor].extend(world_points(prim, cache))

    walls: list[dict[str, Any]] = []
    openings: list[dict[str, Any]] = []
    objects: list[dict[str, Any]] = []
    for (path, group_type, kind), points in sorted(groups.items()):
        obb = pca_obb_xz(points)
        if not obb:
            continue
        item_id = stable_id(path)
        if group_type == "wall":
            p1, p2 = endpoint_surface(obb)
            walls.append({"id": item_id, "p1": p1, "p2": p2})
        elif group_type in {"door", "window", "opening"}:
            p1, p2 = endpoint_surface(obb)
            openings.append({"id": item_id, "kind": group_type, "p1": p1, "p2": p2})
        else:
            objects.append({
                "id": item_id,
                "category": kind,
                "kind": kind,
                **obb,
                "confidence": 0.45,
            })

    payload = {
        "source": "canonical",
        "metadata": {
            "extractedFrom": str(args.usdz),
            "warning": "Approximate USDZ geometry extraction; upload Codable RoomPlan JSON for authoritative semantics.",
        },
        "walls": walls,
        "openings": openings,
        "objects": objects,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(payload, indent=2 if args.pretty else None), encoding="utf-8")
    print(f"wrote {args.output}: {len(walls)} walls, {len(openings)} openings, {len(objects)} objects", file=sys.stderr)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
