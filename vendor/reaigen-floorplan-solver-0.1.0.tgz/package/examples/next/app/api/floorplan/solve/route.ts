import { NextResponse } from "next/server";
import {
  parseRoomPlanJSON,
  solveFloorplan,
  type SolverInput,
} from "@reaigen/floorplan-solver";

export const runtime = "nodejs";

/** Server alternative to the browser worker. POST canonical SolverInput JSON,
 * or append ?roomplan=1 and POST Codable CapturedRoom/CapturedStructure JSON. */
export async function POST(request: Request) {
  try {
    const payload: unknown = await request.json();
    const roomPlan = new URL(request.url).searchParams.get("roomplan") === "1";
    const input = roomPlan ? parseRoomPlanJSON(payload) : payload as SolverInput;
    const result = solveFloorplan(input, { strict: true, runNavigationRepair: true });
    return NextResponse.json(result, { status: result.validation.valid ? 200 : 422 });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    return NextResponse.json({ error: message }, { status: 400 });
  }
}
