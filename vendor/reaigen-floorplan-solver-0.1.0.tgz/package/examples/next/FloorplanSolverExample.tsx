"use client";

import { useMemo } from "react";
import { useFloorplanSolver } from "@reaigen/floorplan-solver/next";
import type { SolverInput } from "@reaigen/floorplan-solver";

export function FloorplanSolverExample({ input }: { input: SolverInput }) {
  // The hook is content-stable even when values are recreated. useMemo still
  // avoids serializing a large floorplan on unrelated component renders.
  const stableInput = useMemo(() => input, [input]);
  const { result, loading, error } = useFloorplanSolver(stableInput, {
    strict: true,
    runNavigationRepair: true,
  });

  if (loading) return <p>Solving floorplan…</p>;
  if (error) return <p role="alert">{error.message}</p>;
  if (!result) return null;

  return (
    <section>
      <p>
        Valid: {String(result.validation.valid)} · accepted {result.diagnostics.acceptedObjectCount} ·
        rejected {result.diagnostics.rejectedObjectCount} · merged {result.diagnostics.deduplicatedObjectCount}
      </p>
      <pre>{JSON.stringify(result.objects, null, 2)}</pre>
    </section>
  );
}
