import Foundation
import RoomPlan

/// Upload this bundle together. The JSON is the solver's canonical semantic
/// input; USDZ remains the visual/mesh asset and metadata preserves UUID maps.
@available(iOS 17.0, *)
public enum RoomPlanExportBundle {
    public struct URLs {
        public let json: URL
        public let usdz: URL
        public let metadata: URL
    }

    public static func write(
        structure: CapturedStructure,
        to directory: URL,
        baseName: String = "captured_structure"
    ) throws -> URLs {
        try FileManager.default.createDirectory(
            at: directory,
            withIntermediateDirectories: true
        )

        let jsonURL = directory.appendingPathComponent("\(baseName).json")
        let usdzURL = directory.appendingPathComponent("\(baseName).usdz")
        let metadataURL = directory.appendingPathComponent("\(baseName)_metadata.json")

        let encoder = JSONEncoder()
        encoder.outputFormatting = [.sortedKeys, .withoutEscapingSlashes]
        let data = try encoder.encode(structure)
        try data.write(to: jsonURL, options: [.atomic])

        try structure.export(
            to: usdzURL,
            metadataURL: metadataURL,
            modelProvider: nil,
            exportOptions: .mesh
        )

        return URLs(json: jsonURL, usdz: usdzURL, metadata: metadataURL)
    }
}
