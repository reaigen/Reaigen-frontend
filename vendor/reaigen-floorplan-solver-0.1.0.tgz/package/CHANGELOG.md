# Changelog

## 0.1.0 — 2026-08-05

- Added canonical RoomPlan/CapturedStructure JSON parser.
- Added floor-polygon and wall-face room construction.
- Added explicit door threshold, approach, swing, and sliding-track keep-outs.
- Added window reserves for tall furniture.
- Added category-specific observation conditioning and dimension guards.
- Added duplicate and front/back fragment merge.
- Added storage wall-interval packing that excludes openings.
- Added table-seat, satellite-table, and television-sofa candidates.
- Added deterministic bounded-width candidate search.
- Added cabinet/appliance operational-front constraints.
- Added room navigation analysis and repair.
- Added strict fail-closed final validator and per-object reasons.
- Added browser Worker, Next.js hook, CLI, Reaigen adapter, and migration guides.
- Added ProcTHOR/ARKitScenes mining scripts and approximate USDZ fallback extractor.
- Added regression fixtures and 14 automated tests.
- Verified strict output on 1,200 deterministic randomized scenes with zero invalid results.
- Added bounded local free-space candidates so valid freestanding furniture can clear fixture service zones instead of being unnecessarily rejected.
