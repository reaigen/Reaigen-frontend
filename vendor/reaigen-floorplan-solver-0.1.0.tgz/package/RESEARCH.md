# Research basis and coefficient policy

## Apple RoomPlan / CapturedStructure

Apple's RoomPlan API is the source schema for runtime input. The WWDC23 “Explore enhancements to RoomPlan” session documents that `CapturedStructure` contains rooms and merged walls, doors, windows, openings, objects, floors, and sections. The same session describes polygonal floors/walls, section labels, object attributes, parent identifiers, and a metadata mapping from USDZ node names to captured element UUIDs.

Official references:

- https://developer.apple.com/videos/play/wwdc2023/10192/
- https://developer.apple.com/documentation/roomplan/capturedstructure/export(to:metadataurl:modelprovider:exportoptions:)
- https://developer.apple.com/documentation/roomplan/capturedroom/usdexportoptions

Engineering consequence:

- Codable JSON is the authoritative semantic representation.
- USDZ and metadata are retained for visual verification and node lookup.
- Parent identifiers take precedence over heuristic category relations when present.
- Sections/floor polygons should define rooms before wall-graph fallback.

## ProcTHOR-10K

The official `allenai/procthor-10k` repository distributes the dataset through the `prior` Python package and includes the train/validation/test house files. ProcTHOR is suitable for semantic layout priors because its houses include room/object organization and procedurally generated furnished scenes.

Official repository:

- https://github.com/allenai/procthor-10k

The included `scripts/mine_procthor.py` estimates, where the selected dataset revision exposes enough fields:

- `P(kind | room type)`;
- wall-backed rate from object edge gap;
- back-edge gap quantiles;
- yaw residual to the nearest room-edge frame;
- selected pair-distance distributions;
- object footprint statistics.

ProcTHOR should not be used as a hard source of truth for an individual scanned apartment. It supplies soft candidate ranking and category conventions only.

## ARKitScenes

Apple describes ARKitScenes as a real-world indoor RGB-D dataset with 5,047 captures of 1,661 unique scenes and manually labeled oriented 3D boxes for a broad furniture taxonomy. The repository's data documentation describes the 3D object-detection assets and annotations.

Official references:

- https://github.com/apple/ARKitScenes
- https://github.com/apple/ARKitScenes/blob/main/DATA.md

The included `scripts/mine_arkitscenes.py` reads `*_3dod_annotation.json` files and uses fields such as label, axis lengths, centroid, and normalized axes to estimate:

- category footprint/height quantiles;
- yaw residual to a dominant 90-degree frame;
- same-label overlap frequency;
- high-containment cross-label pairs;
- selected pair-distance distributions.

ARKitScenes is useful for real size and orientation distributions. It is not a paired dataset of Apple RoomPlan output versus corrected floorplans, so it cannot directly learn your product's scan-error correction model.

## Reaigen correction dataset

The highest-value future dataset is product-native:

```text
raw CapturedRoom/CapturedStructure JSON
automatic solver output
human editor correction
final accepted plan
```

Capture per edit:

- object ID and category;
- source and corrected pose;
- source and corrected dimensions;
- assigned room and wall;
- reason for move/delete/merge;
- door/window conflict state;
- user acceptance or rollback;
- scanner/device/OS version;
- confidence and scan-quality metadata.

This supports learning:

- duplicate probability;
- false-positive probability;
- wall assignment probability;
- size correction distribution;
- candidate ranking;
- category-specific trust radius;
- when rejection is better than relocation.

The learned model should rank candidates. Hard architectural constraints must remain deterministic and non-negotiable.

## Hard constraints versus data priors

Dataset statistics are intentionally separated from physical validity.

Hard constraints:

```text
inside assigned room
not through walls
not through openings or door sweep
no illegal solid overlap
service front remains usable
window remains visible for tall furniture
```

Soft data priors:

```text
room compatibility
wall affinity
small yaw correction
preferred relation distance
facing/alignment
movement from detected pose
reject cost
```

No dataset frequency is allowed to legalize a wall penetration or blocked exit.

## Bootstrap coefficients

`src/priors/defaults.ts` contains conservative engineering defaults so the package works before a full licensed dataset run. They include category-specific yaw thresholds rather than a 45-degree threshold. A 45-degree nearest-cardinal gate accepts every possible orientation and therefore behaves as unconditional snapping.

The defaults are explicitly not a claim that the full ProcTHOR-10K and ARKitScenes collections were downloaded and mined while this package was assembled. Run the supplied scripts in the project's licensed data environment, inspect the output, freeze a priors version, and add regression tests before promotion.

## Merging generated priors

```bash
python scripts/merge_priors.py \
  data/generated/procthor.json \
  data/generated/arkitscenes.json \
  data/generated/runtime-priors.json
```

The merge currently uses:

- ProcTHOR wall affinity/back gap and room probabilities;
- ARKitScenes 2nd–98th percentile dimensions;
- ARKitScenes 90th percentile yaw residual clamped to a conservative range.

Generated JSON should be code-reviewed. Low-count categories should retain bootstrap defaults or use hierarchical/category-family smoothing.

## Licensing

No third-party data is shipped with this package. ProcTHOR's repository includes its license; ARKitScenes instructs users to consult its dataset license and provides a licensing contact. Commercial use, redistribution, and publication of derived statistics must follow the applicable terms and Reaigen's legal review.
