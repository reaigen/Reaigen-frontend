/**
 * Copy-ready adapter for the existing Reaigen floorplan-geometry.ts model.
 *
 * It deliberately consumes the CURRENT wall graph/openings. In FloorplanEditor
 * do not pass base.initialGraph or base.geom?.doors after the user has edited
 * the plan; pass graphSegs(graph), doors and windows from the live state.
 */
import {
  solveLegacyFloorplan,
  type DoorConfiguration,
  type LegacyObjectXZ,
  type LegacySurfaceXZ,
  type RoomObservation,
  type SolveResult,
  type SolverOptions,
  type Vec2,
} from "@reaigen/floorplan-solver";

export interface ReaigenObjectXZ extends LegacyObjectXZ {
  /** Existing renderer fields may be added here without changing the solver. */
  [key: string]: unknown;
}

export interface ReaigenRoomPolygon {
  id: string;
  polygon: Vec2[];
  type?: RoomObservation["type"];
}

export interface ReaigenSolveInput {
  walls: Array<[Vec2, Vec2]> | LegacySurfaceXZ[];
  doors?: LegacySurfaceXZ[];
  windows?: LegacySurfaceXZ[];
  objects: ReaigenObjectXZ[];
  doorConfigs?: Record<string, DoorConfiguration>;
  roomPolygons?: ReaigenRoomPolygon[];
  options?: SolverOptions;
}

export interface ReaigenSolveOutput {
  /** Objects safe to render. Rejected and merged observations are omitted. */
  objects: ReaigenObjectXZ[];
  result: SolveResult;
  rejectedIds: string[];
  mergedIds: string[];
}

function toRenderableObject(
  source: ReaigenObjectXZ,
  solved: SolveResult["objects"][number],
): ReaigenObjectXZ {
  return {
    ...source,
    center: [solved.center[0], solved.center[1]],
    axisW: [solved.axisW[0], solved.axisW[1]],
    axisD: [solved.axisD[0], solved.axisD[1]],
    halfW: solved.halfW,
    halfD: solved.halfD,
    ...(solved.height != null ? { height: solved.height } : {}),
  };
}

export function solveReaigenFloorplan(input: ReaigenSolveInput): ReaigenSolveOutput {
  const result = solveLegacyFloorplan(
    {
      walls: input.walls,
      objects: input.objects,
      ...(input.doors ? { doors: input.doors } : {}),
      ...(input.windows ? { windows: input.windows } : {}),
      ...(input.doorConfigs ? { doorConfigs: input.doorConfigs } : {}),
      ...(input.roomPolygons ? { roomPolygons: input.roomPolygons } : {}),
    },
    input.options,
  );

  const sourceById = new Map(input.objects.map((object) => [object.id.toLowerCase(), object]));
  const objects: ReaigenObjectXZ[] = [];
  const rejectedIds: string[] = [];
  const mergedIds: string[] = [];

  for (const solved of result.objects) {
    if (solved.status === "rejected") {
      rejectedIds.push(solved.id);
      continue;
    }
    if (solved.status === "merged") {
      mergedIds.push(solved.id);
      continue;
    }
    const source = sourceById.get(solved.id.toLowerCase());
    if (source) objects.push(toRenderableObject(source, solved));
  }

  return { objects, result, rejectedIds, mergedIds };
}
