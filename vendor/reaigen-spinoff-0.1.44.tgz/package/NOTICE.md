# Spinoff proprietary notice

Copyright (c) 2026 REAIGEN. All rights reserved.

Spinoff is proprietary software. No license is granted to copy, modify,
redistribute, sublicense, publish, or commercially exploit this package except
under a separate written agreement with REAIGEN.

The implementation is original and framework-independent. Its design is
informed by published Gaussian-splatting research listed in the repository
research notes. Research citations do not incorporate third-party source code
or change the proprietary status of this package.
