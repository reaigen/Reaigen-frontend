# @reaigen/spinoff

Spinoff is REAIGEN's proprietary, dependency-free browser Gaussian-splat
renderer. Its full-quality backend uses WebGPU and its reduced compatibility
backend uses WebGL2. The package is a regular ESM npm package and does not require
Three.js, PlayCanvas, React, or Next.js.

The initial backend reads bundled SOG v2 members through HTTP byte ranges,
decodes the WebP property planes directly into GPU textures, projects and
culls splats in a compute pass, groups visible splats into 65,536 logarithmic
depth bins with a hierarchical GPU prefix/scatter, and composites analytic
Gaussian alpha back-to-front in one indirect draw. The default path is
deterministic, so camera navigation does not expose temporal dither or
stochastic grain. A settled deterministic frame is left resident on the canvas
without duplicate RAF-driven GPU submissions; camera, transform, sky, or canvas
changes invalidate it, and `renderOnce()` always forces a real draw.

```ts
import {
  SpinoffFlyControls,
  SpinoffOrbitCamera,
  SpinoffRenderer
} from "@reaigen/spinoff";

const canvas = document.querySelector("canvas")!;
const camera = new SpinoffOrbitCamera();
const renderer = new SpinoffRenderer(canvas, {
  camera,
  backendPreference: "auto",
  sourceUpAxis: "z",
  // Spinoff world space is right-handed Y-up. Apply authored instance
  // orientation as a model transform, never as camera roll.
  modelRotationRadians: [-Math.PI / 2, 0, 0],
  renderMode: "deterministic",
  shDegree: 3,
  physicalSky: {
    civilTime: { year: 2026, month: 7, day: 26, hour: 15 },
    latitudeDegrees: 48.1486,
    longitudeDegrees: 17.1077,
    utcOffsetHours: 2,
    turbidity: 2.6
  }
});

await renderer.initialize();
new SpinoffFlyControls(camera, canvas, {
  movementSpeed: 4,
  boostMultiplier: 4,
  pointerLock: false
});
renderer.start();
await renderer.loadSog("/scene.sog");
```

Starting after `initialize()` is intentional: Spinoff renders its configured
background or physical sky even when no scene is resident, so a slow network
never leaves an initialized black canvas. Scene installation is atomic. A
second `loadSog()` keeps the current scene visible until every required plane
of the replacement has decoded and uploaded, which supports a preview-first
delivery pattern without a separate renderer:

```ts
renderer.start();
await renderer.loadSog("/scene-preview.sog", { shDegree: 0 });
await renderer.loadSog("/scene-full.sog");
```

Generate the preview offline with coverage-preserving merge decimation. Do not
use a source prefix or an uncompensated random subset: those create spatial
holes. For true camera-driven chunk residency, use a spatial multi-LOD format;
two-stage loading improves time to first content but is not a replacement for
streamed SOG nodes.

`SpinoffFlyControls` provides frame-rate-independent, right-handed Y-up
navigation without creating UI. `W`/`S` move along the current view direction,
`A`/`D` strafe, `Q` moves down, `E` moves up, and either Shift key applies the
configured boost. Primary-button drag performs in-place mouse-look; with
`pointerLock: true`, clicking the canvas captures unlimited mouse movement and
Escape releases it. Keep it false for ordinary click-drag look with no sticky
cursor capture. The wheel changes movement speed. Keyboard handling is
active only while the canvas has focus, and keys are cleared on blur or tab
visibility loss so a backgrounded page cannot continue moving.

The camera remains an ordinary `SpinoffOrbitCamera`: fly translation moves its
eye and target together, while `look()` rotates around the eye rather than
orbiting the scene target. `SpinoffOrbitControls` remains available as the
separate turntable/inspection controller.

`physicalSky` is renderer functionality, not a UI system. It ports the native
Spinoff Y-up Preetham/Perez daylight model, finite pixel-filtered solar disc,
and ground/horizon blend to both WebGPU and WebGL2. Geographic world space is
`+Y` up, `+Z` north, and `+X` east. Civil time, UTC offset, daylight saving,
latitude/longitude, north offset, turbidity, pressure, temperature, exposure,
ground albedo, and Sun/sky intensity can be authored once. Use
`renderer.setPhysicalSky(nextState)` to change daytime or location at runtime;
no controls or framework components are created by the package. The default
state is deterministic (Bratislava, 2026-07-26 15:00 UTC+2) so builds and image
regressions never change with the wall clock.

`calculateSpinoffSolarPosition()` is also exported for applications that need
the resolved azimuth, elevation, or Y-up direction. Its compact Meeus/NOAA
calculation matches the published NREL SPA reference case within 0.02 degrees.

`loadSog()` also accepts a browser `Blob` or `File`. Local sources are sliced
directly in memory and never pass through `fetch`, HTTP, a service worker, or a
server upload:

```ts
await renderer.loadSog(localSogFile);
```

The SOG HTTP origin must expose `Content-Length`, `Accept-Ranges: bytes`, and
single-range `206 Partial Content` responses. Bundled SOG ZIP members must use
ZIP method 0 (stored), which is the standard SOG layout and permits independent
range decoding.

SOG smallest-three quaternion payloads default to the WXYZ component layout
consumed by PlayCanvas and SuperSplat's composed GPU shader. An explicit
`asset.quaternionOrder` value of `"wxyz"` or `"xyzw"` takes precedence, so
transitional XYZW files remain readable and current producers can make their
layout unambiguous.

The deterministic and stochastic raster paths use the same finite normalized
Gaussian kernel as PlayCanvas: support ends at squared radius 8, the
`exp(-4)` edge value is removed, and the remaining kernel is normalized back
to one at its center. This prevents nonzero three-sigma tails from accumulating
as a translucent veil in dense scenes.

`probeSpinoffSupport()` performs a no-UI adapter/device probe and returns the
selected adapter profile, every attempted profile, adapter identity, baseline
limits, secure-context status, and a diagnostic reason when initialization is
not possible. Adapter creation tries the requested high-performance profile,
the same feature level without a power preference, the browser's zero-argument
default, and finally the WebGPU compatibility feature level. This handles
mobile/Safari implementations that reject a newer request dictionary or return
null for the high-performance hint.

With `backendPreference: "auto"` (the default), failure to obtain a WebGPU
adapter/device/context advances to the WebGL2 backend. WebGL2 range-loads the
five SH0 SOG planes directly into RGBA8 textures, renders deterministic
instanced Gaussian quads, and uses stable source-ID sampling plus logarithmic
far-to-near depth slices. Mobile defaults select up to 900,000 settled splats
and 200,000 while moving. This is a reduced-quality safety path, not a claim of
full WebGPU parity. Set `"webgpu"` or `"webgl2"` only when an application needs
to require a specific backend.

Automatic loss recovery is enabled by default. On WebGPU device loss, Spinoff
requests a fresh adapter and device; on WebGL2 context restoration, it rebuilds
all invalid resources. The last successfully loaded URL, `Blob`, or `File` is
loaded again and a previously running renderer resumes. Configure this with
`autoRecover`, `maxRecoveryAttempts` (default 2, bounded to 1-3), and
`recoveryDelayMilliseconds` (default 250). Recovery intentionally does not
reuse a caller's old `AbortSignal`. Applications can observe `device-lost`,
`recovery-start`, `recovery-attempt-failed`, `recovery-complete`, and
`recovery-error` events without adding UI to the renderer.

The default quality backend uses a portable 65,536-bin compute
histogram/hierarchical-prefix/scatter and one indirect draw. It stays on core
WebGPU and does not require the optional `indirect-first-instance` feature.
Projected ellipse axes are limited independently only at extreme
viewport-scale footprints, avoiding the former hard 40/96-pixel clipping
behavior. Set `renderMode: "stochastic"` only to exercise the legacy temporal
path.

For reconstruction pipelines that occasionally emit oversized, nearly
isotropic tail Gaussians, enable the opt-in presentation guard:

```ts
const renderer = new SpinoffRenderer(canvas, {
  reconstructionFogGuard: true
});
```

The guard smoothly limits only broad 3-sigma footprints once they become a
large fraction of the viewport. Thin anisotropic surface splats are left
alone, and neither SOG bytes nor lossless tensor values are mutated. The
object form exposes `strength`, `maxScreenFraction`, `minRadiusPixels`, and
`maxAnisotropy`. This is a reconstruction-compatibility presentation rule,
not part of the SOG v2 format and not a substitute for correcting training
geometry.

On desktop, Spinoff negotiates enough `maxBufferSize` and
`maxStorageBufferBindingSize` for as many as 10,000,000 projected records,
then allocates no more records than the loaded scene can contain. This avoids
arbitrarily retaining only the first 2,000,000 visible splats in wide views.
The normal mobile profile uses a 1,200,000-record projected cache; the
compatibility adapter profile uses 600,000. When a view has more candidates,
Spinoff calibrates a stable source-ID hash to 94% of capacity and applies a
bounded sublinear footprint/opacity reconstruction. The selection is stable
while navigating, so it does not create frame-varying pruning noise.

Mobile defaults also limit the canvas to one million internal pixels, request
SH0 only, and decode/upload at most two SOG textures concurrently. These are
monolithic-SOG safety measures, not a substitute for spatial streamed LOD.
`SpinoffStats` exposes candidate count, selected count/capacity, selection
probability, overflow, active adapter profile, and load/render diagnostics so
an incomplete frame cannot be mistaken for a valid render.

Exact tiled/radix sorting, planar per-fragment splat depth, spatially streamed
SOG LOD, physical cross-browser/device certification, and direct WebXR
presentation remain separate release gates rather than claims of this
prototype.

This package is `UNLICENSED`, published with restricted npm access, and is not
authorized for redistribution. See `NOTICE.md`.
